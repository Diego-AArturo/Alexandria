// ─── MY PROFILE SCREEN ───────────────────────────────────────────────────────

const LANGUAGES = ["English","Spanish","French","German","Japanese","Mandarin","Portuguese"];

const BADGES = [
  { emoji: "🚀", label: "First Course", earned: true },
  { emoji: "🔥", label: "3-Day Streak", earned: true },
  { emoji: "⚡", label: "100 XP", earned: true },
  { emoji: "🧠", label: "5 Lessons", earned: false },
  { emoji: "🏆", label: "First Perfect", earned: false },
  { emoji: "💎", label: "7-Day Streak", earned: false },
];

function ProfileScreen({ user, courses, onSave, snackbar, showSnackbar, streak, totalXP }) {
  const [editing, setEditing] = React.useState(false);
  const [username, setUsername] = React.useState(user.username || "");
  const [password, setPassword] = React.useState("");
  const [language, setLanguage] = React.useState(user.language || "English");
  const [saving, setSaving] = React.useState(false);
  const [langWarning, setLangWarning] = React.useState(false);

  const totalCourses = courses.length;
  const completedCourses = courses.filter(c => c.progress === 100).length;
  const inProgressCourses = courses.filter(c => c.progress > 0 && c.progress < 100).length;
  const xpLevel = Math.floor((totalXP || 0) / 100) + 1;
  const xpToNext = 100 - ((totalXP || 0) % 100);

  const handleSave = () => {
    setSaving(true);
    const didChangeLang = language !== user.language;
    setTimeout(() => {
      setSaving(false);
      setEditing(false);
      if (didChangeLang) setLangWarning(true);
      onSave({ username, language });
    }, 1100);
  };

  return (
    <Screen>
      {/* Hero banner */}
      <div style={{
        background: `linear-gradient(160deg, ${V.text} 0%, #312E81 100%)`,
        padding: "18px 20px 24px",
        position: "relative", overflow: "hidden"
      }}>
        {/* Background decoration */}
        <div style={{
          position: "absolute", top: -20, right: -20,
          width: 120, height: 120, borderRadius: "50%",
          background: "rgba(255,255,255,0.04)"
        }} />
        <div style={{
          position: "absolute", bottom: -30, left: -10,
          width: 80, height: 80, borderRadius: "50%",
          background: "rgba(255,255,255,0.04)"
        }} />

        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
          {/* Avatar */}
          <div style={{
            width: 60, height: 60, borderRadius: 20,
            background: `linear-gradient(135deg, ${V.violetLight}, #A855F7)`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, fontWeight: 900, color: "#fff",
            border: "3px solid rgba(255,255,255,0.25)",
            boxShadow: "0 4px 16px rgba(0,0,0,0.3)"
          }}>{user.avatar}</div>
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: 0, fontSize: 20, fontWeight: 900, color: "#fff", letterSpacing: "-0.01em" }}>
              {user.name}
            </h2>
            <p style={{ margin: "2px 0 0", fontSize: 13, color: "rgba(255,255,255,0.65)", fontWeight: 600 }}>
              {user.email}
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6 }}>
              <div style={{
                background: V.gold, borderRadius: 999, padding: "3px 10px",
                display: "flex", alignItems: "center", gap: 4
              }}>
                <span style={{ fontSize: 11, fontWeight: 900, color: "#fff" }}>Lvl {xpLevel}</span>
              </div>
              <StreakBadge streak={streak || 0} />
            </div>
          </div>
          {!editing && (
            <button onClick={() => setEditing(true)} style={{
              background: "rgba(255,255,255,0.12)", border: "2px solid rgba(255,255,255,0.2)",
              borderRadius: 12, padding: "8px 14px", cursor: "pointer",
              color: "#fff", fontWeight: 800, fontSize: 13, fontFamily: "inherit"
            }}>Edit</button>
          )}
        </div>

        {/* XP bar */}
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
            <span style={{ fontSize: 11, fontWeight: 800, color: "rgba(255,255,255,0.6)" }}>
              ⚡ {totalXP || 0} XP  ·  Level {xpLevel}
            </span>
            <span style={{ fontSize: 11, fontWeight: 800, color: "rgba(255,255,255,0.6)" }}>
              {xpToNext} XP to next
            </span>
          </div>
          <div style={{ background: "rgba(255,255,255,0.15)", borderRadius: 999, height: 10, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 999,
              background: `linear-gradient(90deg, ${V.gold}, #FDE68A)`,
              width: `${((totalXP || 0) % 100)}%`,
              transition: "width 0.8s cubic-bezier(0.34,1.2,0.64,1)"
            }} />
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "18px 18px 0" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

          {/* Edit mode */}
          {editing && (
            <div style={{
              background: V.card, borderRadius: 22,
              border: `2.5px solid ${V.violetBorder}`,
              padding: "18px 18px",
              boxShadow: `0 4px 0 ${V.violetBorder}`,
              animation: "slideUp 0.3s ease"
            }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 900, color: V.text }}>Edit Profile</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <InputField label="Username" value={username} onChange={setUsername} placeholder="username" />
                <InputField label="New Password" value={password} onChange={setPassword} type="password" placeholder="Leave blank to keep current" />
                <div>
                  <label style={{ fontSize: 11, fontWeight: 900, color: V.muted, textTransform: "uppercase", letterSpacing: "0.08em", display: "block", marginBottom: 8 }}>
                    Language
                  </label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {LANGUAGES.map(lang => (
                      <div key={lang} onClick={() => setLanguage(lang)} style={{
                        padding: "7px 14px", borderRadius: 999,
                        background: language === lang ? V.violet : V.offWhite,
                        border: `2px solid ${language === lang ? V.violet : V.border}`,
                        color: language === lang ? "#fff" : V.muted,
                        fontWeight: 800, fontSize: 12, cursor: "pointer",
                        transition: "all 0.18s cubic-bezier(0.34,1.2,0.64,1)",
                        transform: language === lang ? "scale(1.05)" : "scale(1)",
                        boxShadow: language === lang ? `0 3px 0 ${V.violetDark}` : "none"
                      }}>{lang}</div>
                    ))}
                  </div>
                </div>
                {langWarning && (
                  <div style={{
                    background: V.goldBg, border: `2px solid ${V.goldBorder}`,
                    borderRadius: 12, padding: "10px 14px",
                    fontSize: 13, color: "#92400E", fontWeight: 700,
                    display: "flex", alignItems: "center", gap: 8
                  }}>
                    <span>🔄</span> Language changed — restart to apply fully.
                  </div>
                )}
                <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                  <GhostButton label="Cancel" onPress={() => setEditing(false)} fullWidth />
                  <PrimaryButton label="Save" onPress={handleSave} loading={saving} fullWidth small />
                </div>
              </div>
            </div>
          )}

          {/* Stats grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[
              { icon: "📚", label: "Total Courses", value: totalCourses, color: V.violet, bg: V.violetBg, border: V.violetBorder },
              { icon: "🏆", label: "Completed", value: completedCourses, color: V.teal, bg: V.tealBg, border: V.tealBorder },
              { icon: "🔥", label: "Day Streak", value: streak || 0, color: "#F59E0B", bg: V.goldBg, border: V.goldBorder },
              { icon: "⚡", label: "Total XP", value: totalXP || 0, color: V.violetLight, bg: V.violetBg, border: V.violetBorder },
            ].map(s => (
              <div key={s.label} style={{
                background: s.bg, border: `2.5px solid ${s.border}`,
                borderRadius: 20, padding: "16px 14px",
                boxShadow: `0 3px 0 ${s.border}`, textAlign: "center"
              }}>
                <div style={{ fontSize: 24, marginBottom: 4 }}>{s.icon}</div>
                <div style={{ fontSize: 30, fontWeight: 900, color: s.color, letterSpacing: "-0.03em", lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: 11, fontWeight: 800, color: V.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* In progress big stat */}
          <div style={{
            background: `linear-gradient(135deg, ${V.violetBg} 0%, ${V.skyBg} 100%)`,
            border: `2.5px solid ${V.violetBorder}`,
            borderRadius: 20, padding: "16px 18px",
            display: "flex", alignItems: "center", gap: 16,
            boxShadow: `0 3px 0 ${V.violetBorder}`
          }}>
            <span style={{ fontSize: 40, lineHeight: 1 }}>📖</span>
            <div>
              <div style={{ fontSize: 36, fontWeight: 900, color: V.violet, letterSpacing: "-0.03em", lineHeight: 1 }}>{inProgressCourses}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: V.muted, marginTop: 2 }}>
                {inProgressCourses === 1 ? "course in progress" : "courses in progress"}
              </div>
            </div>
          </div>

          {/* Badges */}
          <div style={{
            background: V.card, border: `2px solid ${V.border}`,
            borderRadius: 20, padding: "16px 18px"
          }}>
            <h4 style={{ margin: "0 0 14px", fontSize: 14, fontWeight: 900, color: V.text, display: "flex", alignItems: "center", gap: 6 }}>
              🎖️ Badges
            </h4>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {BADGES.map((b, i) => (
                <div key={i} style={{
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                  background: b.earned ? V.violetBg : "#F9FAFB",
                  border: `2px solid ${b.earned ? V.violetBorder : "#E5E7EB"}`,
                  borderRadius: 16, padding: "12px 8px",
                  opacity: b.earned ? 1 : 0.5
                }}>
                  <span style={{ fontSize: 24, filter: b.earned ? "none" : "grayscale(1)" }}>{b.emoji}</span>
                  <span style={{ fontSize: 10, fontWeight: 800, color: b.earned ? V.violet : V.muted, textAlign: "center", lineHeight: 1.2 }}>{b.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Account */}
          <div style={{
            background: V.card, border: `2px solid ${V.border}`,
            borderRadius: 20, padding: "14px 18px",
            display: "flex", alignItems: "center", gap: 10
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: V.violetBg, display: "flex", alignItems: "center", justifyContent: "center"
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={V.violet} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
              </svg>
            </div>
            <span style={{ fontSize: 14, color: V.textMid, fontWeight: 700, flex: 1 }}>{user.email}</span>
          </div>

          {/* Sign out */}
          <button style={{
            background: "transparent", border: `2.5px solid ${V.errorBorder}`,
            borderRadius: 16, padding: "14px 24px", cursor: "pointer",
            color: V.error, fontWeight: 800, fontSize: 15, width: "100%",
            fontFamily: "inherit", transition: "all 0.15s ease"
          }}>Sign Out</button>

          <div style={{ height: 14 }} />
        </div>
      </div>
      <Snackbar message={snackbar.message} visible={snackbar.visible} onHide={snackbar.hide} />
    </Screen>
  );
}

Object.assign(window, { ProfileScreen });
