// ─── NAVIGATION SHELL + MAIN APP ─────────────────────────────────────────────

function TabBar({ activeTab, onTab }) {
  const tabs = [
    {
      id: "courses", label: "Learn",
      icon: (active) => (
        <svg width="22" height="22" viewBox="0 0 24 24">
          <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"
            fill={active ? V.violet : "none"}
            stroke={active ? V.violet : V.muted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"
            fill={active ? V.violet : "none"}
            stroke={active ? V.violet : V.muted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )
    },
    {
      id: "craft", label: "Craft",
      icon: (active) => (
        <svg width="22" height="22" viewBox="0 0 24 24">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
            fill={active ? V.violet : "none"}
            stroke={active ? V.violet : V.muted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )
    },
    {
      id: "profile", label: "Profile",
      icon: (active) => (
        <svg width="22" height="22" viewBox="0 0 24 24">
          <circle cx="12" cy="7" r="4"
            fill={active ? V.violet : "none"}
            stroke={active ? V.violet : V.muted} strokeWidth="2"/>
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
            fill="none" stroke={active ? V.violet : V.muted} strokeWidth="2" strokeLinecap="round"/>
        </svg>
      )
    }
  ];

  return (
    <div style={{
      display: "flex", background: V.card,
      borderTop: `2px solid ${V.border}`,
      paddingBottom: 6, flexShrink: 0,
      boxShadow: "0 -4px 20px rgba(79,70,229,0.08)"
    }}>
      {tabs.map(tab => {
        const active = activeTab === tab.id;
        return (
          <button key={tab.id} onClick={() => onTab(tab.id)} style={{
            flex: 1, display: "flex", flexDirection: "column",
            alignItems: "center", gap: 3, padding: "9px 4px 6px",
            background: "none", border: "none", cursor: "pointer",
            transition: "all 0.15s ease", position: "relative"
          }}>
            <div style={{
              width: 46, height: 34, borderRadius: 11,
              background: active ? V.violetBg : "transparent",
              display: "flex", alignItems: "center", justifyContent: "center",
              transition: "all 0.22s cubic-bezier(0.34,1.3,0.64,1)",
              transform: active ? "scale(1.1) translateY(-1px)" : "scale(1)"
            }}>
              {tab.icon(active)}
            </div>
            <span style={{
              fontSize: 10, fontWeight: active ? 900 : 700,
              color: active ? V.violet : V.muted,
              letterSpacing: "0.02em",
              transition: "all 0.2s ease"
            }}>{tab.label}</span>
            {/* Active indicator dot */}
            {active && (
              <div style={{
                position: "absolute", bottom: 2, left: "50%",
                transform: "translateX(-50%)",
                width: 4, height: 4, borderRadius: "50%",
                background: V.violet
              }} />
            )}
          </button>
        );
      })}
    </div>
  );
}

// Slide in from right for push navigation
function PushScreen({ screenKey, children }) {
  return (
    <div key={screenKey} style={{
      position: "absolute", inset: 0,
      animation: "slideFromRight 0.32s cubic-bezier(0.4,0,0.2,1)"
    }}>
      {children}
    </div>
  );
}

function TabScreen({ tabKey, children }) {
  return (
    <div key={tabKey} style={{
      position: "absolute", inset: 0,
      animation: "fadeScaleIn 0.22s cubic-bezier(0.4,0,0.2,1)"
    }}>
      {children}
    </div>
  );
}

function App() {
  const [authed, setAuthed] = React.useState(false);
  const [user, setUser] = React.useState(window.ALEXANDRIA_DATA.user);
  const [courses, setCourses] = React.useState(window.ALEXANDRIA_DATA.courses);
  const [activeTab, setActiveTab] = React.useState("courses");
  const [navStack, setNavStack] = React.useState([]);
  const [snackMsg, setSnackMsg] = React.useState("");
  const [snackVisible, setSnackVisible] = React.useState(false);
  const [tabAnimKey, setTabAnimKey] = React.useState(0);
  const [streak] = React.useState(7);
  const [totalXP, setTotalXP] = React.useState(240);

  const showSnackbar = (msg) => { setSnackMsg(msg); setSnackVisible(true); };
  const hideSnackbar = () => setSnackVisible(false);
  const snackbar = { message: snackMsg, visible: snackVisible, hide: hideSnackbar };

  const goToTab = (tab) => {
    setNavStack([]);
    setActiveTab(tab);
    setTabAnimKey(k => k + 1);
  };

  const push = (screen, props = {}) => setNavStack(s => [...s, { screen, props }]);
  const pop = () => setNavStack(s => s.slice(0, -1));

  const handleCourseCreated = (promptText) => {
    const title = promptText.length > 52 ? promptText.slice(0, 49) + "…" : promptText;
    const newCourse = {
      id: Date.now(), title,
      totalUnits: 4, currentUnit: 1, progress: 0,
      units: [
        {
          id: 1, title: "Introduction", description: "Core concepts and overview", state: "current",
          items: [
            { type: "concept", title: "Welcome to Your Course", body: "This course was crafted just for you by Alexandria AI.\n\n• Tailored to your exact prompt\n• Structured for progressive learning\n• Includes quizzes to reinforce concepts" },
            { type: "mc", question: "What makes AI-generated courses special?", options: ["They're generic", "They're personalized to your goals", "They have no quizzes", "They're very long"], correct: 1, explanation: "Alexandria courses are tailored to your prompt, background, and learning goals." },
            { type: "tf", question: "Alexandria courses adapt to your skill level and learning goals.", correct: true, explanation: "Yes — the AI uses your prompt to calibrate the right level, vocabulary, and depth." },
          ]
        },
        { id: 2, title: "Core Concepts", description: "Deep dive into fundamentals", state: "locked", items: [] },
        { id: 3, title: "Applications", description: "Real-world examples and practice", state: "locked", items: [] },
        { id: 4, title: "Mastery Check", description: "Review and assessment", state: "locked", items: [] },
      ]
    };
    setCourses(prev => [...prev, newCourse]);
    goToTab("courses");
    setTimeout(() => push("courseUnits", { course: newCourse }), 400);
  };

  if (!authed) {
    return (
      <div style={{ position: "absolute", inset: 0 }}>
        <AuthScreen onAuth={(u) => {
          setUser(prev => ({ ...prev, name: u.name, email: u.email, avatar: u.name.slice(0,2).toUpperCase() }));
          setAuthed(true);
        }} />
      </div>
    );
  }

  const topOfStack = navStack[navStack.length - 1];

  const renderTabContent = () => {
    if (activeTab === "courses") return (
      <MyCoursesScreen courses={courses} onCoursePress={c => push("courseUnits", { course: c })}
        onGoToCraft={() => goToTab("craft")} snackbar={snackbar} showSnackbar={showSnackbar}
        streak={streak} totalXP={totalXP} />
    );
    if (activeTab === "craft") return (
      <CraftCourseScreen courses={courses} onCourseCreated={handleCourseCreated}
        snackbar={snackbar} showSnackbar={showSnackbar} />
    );
    if (activeTab === "profile") return (
      <ProfileScreen user={user} courses={courses}
        onSave={updates => setUser(u => ({ ...u, ...updates }))}
        snackbar={snackbar} showSnackbar={showSnackbar}
        streak={streak} totalXP={totalXP} />
    );
  };

  const renderStackScreen = () => {
    if (!topOfStack) return null;
    const { screen, props } = topOfStack;
    if (screen === "courseUnits") return (
      <PushScreen screenKey={`units-${props.course.id}`}>
        <CourseUnitsScreen course={props.course} onBack={pop}
          onUnitPress={unit => {
            if (unit.items?.length > 0) push("lesson", { unit });
            else showSnackbar("No lessons yet for this unit.");
          }} />
      </PushScreen>
    );
    if (screen === "lesson") return (
      <PushScreen screenKey={`lesson-${props.unit.id}`}>
        <LessonScreen unit={props.unit} onBack={pop}
          onXPEarned={xp => setTotalXP(t => t + xp)} />
      </PushScreen>
    );
    return null;
  };

  return (
    <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", background: V.offWhite, overflow: "hidden" }}>
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        {/* Tab screen */}
        <TabScreen tabKey={`${activeTab}-${tabAnimKey}`}>
          {renderTabContent()}
        </TabScreen>
        {/* Stack overlay */}
        {topOfStack && renderStackScreen()}
      </div>
      {/* Tab bar hidden when stack screen showing */}
      {!topOfStack && <TabBar activeTab={activeTab} onTab={goToTab} />}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
