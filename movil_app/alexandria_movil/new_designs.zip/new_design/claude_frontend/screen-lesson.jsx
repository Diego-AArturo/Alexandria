// ─── LESSON SCREEN ───────────────────────────────────────────────────────────

// ── Concept Card ─────────────────────────────────────────────────────────────
function ConceptCard({ item }) {
  const lines = item.body.split("\n");
  return (
    <div style={{
      background: V.card, borderRadius: 24,
      border: `2.5px solid ${V.border}`,
      boxShadow: `0 4px 0 ${V.violetBorder}`,
      overflow: "hidden"
    }}>
      {/* Colored top strip */}
      <div style={{
        background: `linear-gradient(135deg, ${V.violetBg}, ${V.skyBg})`,
        padding: "20px 22px 18px",
        borderBottom: `2px solid ${V.border}`
      }}>
        <div style={{ fontSize: 32, marginBottom: 8 }}>💡</div>
        <h3 style={{ margin: 0, fontSize: 20, fontWeight: 900, color: V.text, letterSpacing: "-0.02em", lineHeight: 1.2 }}>
          {item.title}
        </h3>
      </div>
      <div style={{ padding: "18px 22px 22px" }}>
        {lines.map((line, i) => {
          if (!line.trim()) return <div key={i} style={{ height: 8 }} />;
          const isBullet = line.startsWith("•");
          return (
            <div key={i} style={{
              display: "flex", gap: isBullet ? 10 : 0,
              alignItems: "flex-start", marginBottom: 6
            }}>
              {isBullet && (
                <div style={{
                  width: 8, height: 8, minWidth: 8, borderRadius: "50%",
                  background: V.violet, marginTop: 7
                }} />
              )}
              <p style={{
                margin: 0, fontSize: 15, lineHeight: 1.65,
                color: isBullet ? V.textMid : V.muted,
                fontWeight: isBullet ? 700 : 500,
              }}>{isBullet ? line.slice(2) : line}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── MC Card ───────────────────────────────────────────────────────────────────
function MCCard({ item, selected, onSelect, submitted }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
      <div style={{
        background: V.card, borderRadius: "22px 22px 0 0",
        border: `2.5px solid ${V.border}`, borderBottom: "none",
        padding: "20px 20px 16px"
      }}>
        <p style={{ margin: 0, fontSize: 12, fontWeight: 800, color: V.violet, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>
          Multiple Choice
        </p>
        <p style={{ margin: 0, fontSize: 18, fontWeight: 900, color: V.text, lineHeight: 1.35, letterSpacing: "-0.01em" }}>
          {item.question}
        </p>
      </div>
      <div style={{
        background: "#F8F7FF", borderRadius: "0 0 22px 22px",
        border: `2.5px solid ${V.border}`, borderTop: "none",
        padding: "12px 16px 16px",
        display: "flex", flexDirection: "column", gap: 10
      }}>
        {item.options.map((opt, i) => {
          let bg = V.card, border = V.border, color = V.textMid, weight = 700;
          let iconEl = null, glow = false;

          if (submitted) {
            if (i === item.correct) {
              bg = V.tealBg; border = V.teal; color = V.teal; weight = 800;
              iconEl = (
                <div style={{
                  width: 26, height: 26, borderRadius: "50%",
                  background: V.teal, display: "flex", alignItems: "center", justifyContent: "center"
                }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                </div>
              );
            } else if (i === selected) {
              bg = V.errorBg; border = V.error; color = V.error; weight = 800;
              iconEl = (
                <div style={{
                  width: 26, height: 26, borderRadius: "50%",
                  background: V.error, display: "flex", alignItems: "center", justifyContent: "center"
                }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </div>
              );
            }
          } else if (i === selected) {
            bg = V.violetBg; border = V.violet; color = V.violet; weight = 800; glow = true;
          }

          return (
            <div key={i} onClick={() => !submitted && onSelect(i)} style={{
              background: bg, border: `2.5px solid ${border}`,
              borderRadius: 15, padding: "13px 15px",
              display: "flex", alignItems: "center", gap: 12,
              cursor: submitted ? "default" : "pointer",
              transition: "all 0.2s cubic-bezier(0.34,1.2,0.64,1)",
              transform: glow ? "scale(1.02)" : "scale(1)",
              boxShadow: glow ? `0 0 0 3px ${V.violetBg}, 0 3px 0 ${V.violetBorder}` : submitted && i === item.correct ? `0 3px 0 ${V.tealBorder}` : "none"
            }}>
              <div style={{
                width: 24, height: 24, minWidth: 24, borderRadius: "50%",
                border: `2.5px solid ${i === selected && !submitted ? V.violet : border}`,
                background: i === selected && !submitted ? V.violet : "transparent",
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "all 0.18s ease", flexShrink: 0
              }}>
                {i === selected && !submitted && (
                  <div style={{ width: 9, height: 9, borderRadius: "50%", background: "#fff" }} />
                )}
              </div>
              <span style={{ fontSize: 14, fontWeight: weight, color, flex: 1, lineHeight: 1.35 }}>{opt}</span>
              {iconEl}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── T/F Card ──────────────────────────────────────────────────────────────────
function TFCard({ item, selected, onSelect, submitted }) {
  const correctIdx = item.correct ? 0 : 1;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
      <div style={{
        background: V.card, borderRadius: "22px 22px 0 0",
        border: `2.5px solid ${V.border}`, borderBottom: "none",
        padding: "20px 20px 16px"
      }}>
        <p style={{ margin: 0, fontSize: 12, fontWeight: 800, color: "#F59E0B", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>
          True or False
        </p>
        <p style={{ margin: 0, fontSize: 18, fontWeight: 900, color: V.text, lineHeight: 1.35, letterSpacing: "-0.01em" }}>
          {item.question}
        </p>
      </div>
      <div style={{
        background: "#F8F7FF", borderRadius: "0 0 22px 22px",
        border: `2.5px solid ${V.border}`, borderTop: "none",
        padding: "16px 16px 18px", display: "flex", gap: 12
      }}>
        {["True", "False"].map((opt, i) => {
          const isSelected = selected === i;
          const isCorrectOpt = i === correctIdx;
          let bg = V.card, border = V.border, color = V.muted, shadow = "none";

          if (submitted) {
            if (isCorrectOpt) { bg = V.tealBg; border = V.teal; color = V.teal; shadow = `0 4px 0 ${V.tealBorder}`; }
            else if (isSelected) { bg = V.errorBg; border = V.error; color = V.error; shadow = `0 4px 0 ${V.errorBorder}`; }
          } else if (isSelected) {
            bg = V.violetBg; border = V.violet; color = V.violet;
            shadow = `0 4px 0 ${V.violetBorder}`;
          }

          const emoji = i === 0 ? "✅" : "❌";
          return (
            <div key={opt} onClick={() => !submitted && onSelect(i)} style={{
              flex: 1, background: bg, border: `2.5px solid ${border}`,
              borderRadius: 18, padding: "20px 14px",
              display: "flex", flexDirection: "column", alignItems: "center", gap: 10,
              cursor: submitted ? "default" : "pointer",
              transform: isSelected && !submitted ? "scale(1.04) translateY(-2px)" : "scale(1)",
              boxShadow: submitted ? shadow : isSelected ? shadow : "0 3px 0 #E0E7FF",
              transition: "all 0.2s cubic-bezier(0.34,1.3,0.64,1)"
            }}>
              <span style={{ fontSize: 32 }}>{emoji}</span>
              <span style={{ fontSize: 17, fontWeight: 900, color, letterSpacing: "0.01em" }}>{opt}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Fill in the Blank Card ────────────────────────────────────────────────────
function FITBCard({ item, filled, onChipTap, onSlotTap, submitted, isCorrect }) {
  const parts = item.stem.split("___");
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
      <div style={{
        background: V.card, borderRadius: "22px 22px 0 0",
        border: `2.5px solid ${V.border}`, borderBottom: "none",
        padding: "20px 20px 16px"
      }}>
        <p style={{ margin: 0, fontSize: 12, fontWeight: 800, color: V.sky, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>
          Fill in the Blank
        </p>
        <p style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: V.muted }}>{item.question}</p>
        {/* Stem with slots */}
        <div style={{ fontSize: 17, lineHeight: 2.2, color: V.text, fontWeight: 800 }}>
          {parts.map((part, i) => (
            <React.Fragment key={i}>
              <span>{part}</span>
              {i < parts.length - 1 && (
                <span
                  onClick={() => filled[i] && !submitted && onSlotTap(i)}
                  style={{
                    display: "inline-flex", alignItems: "center", justifyContent: "center",
                    minWidth: 90, padding: "2px 14px",
                    background: filled[i]
                      ? (submitted ? (isCorrect ? V.tealBg : V.errorBg) : V.violetBg)
                      : "transparent",
                    border: `2.5px ${filled[i] ? "solid" : "dashed"} ${
                      filled[i]
                        ? (submitted ? (isCorrect ? V.teal : V.error) : V.violet)
                        : V.muted
                    }`,
                    borderRadius: 10, margin: "0 4px",
                    color: filled[i]
                      ? (submitted ? (isCorrect ? V.teal : V.error) : V.violet)
                      : V.muted,
                    fontWeight: 900, fontSize: 15,
                    cursor: filled[i] && !submitted ? "pointer" : "default",
                    transition: "all 0.25s cubic-bezier(0.34,1.3,0.64,1)",
                    transform: filled[i] && !submitted ? "scale(1.06) translateY(-1px)" : "scale(1)",
                    boxShadow: filled[i] && !submitted ? `0 3px 0 ${V.violetBorder}` : "none"
                  }}>
                  {filled[i] || "···"}
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
      {/* Word chips */}
      <div style={{
        background: "#F8F7FF", borderRadius: "0 0 22px 22px",
        border: `2.5px solid ${V.border}`, borderTop: "none",
        padding: "14px 16px 18px"
      }}>
        <p style={{ margin: "0 0 10px", fontSize: 11, fontWeight: 800, color: V.muted, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          Choose words
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {item.choices.map((choice, i) => {
            const isUsed = filled.includes(choice);
            return (
              <div key={i} onClick={() => !isUsed && !submitted && onChipTap(choice)} style={{
                padding: "10px 18px", borderRadius: 12,
                background: isUsed ? "#F3F4F6" : V.card,
                border: `2.5px solid ${isUsed ? "#E5E7EB" : V.border}`,
                color: isUsed ? V.muted : V.textMid,
                fontWeight: 800, fontSize: 14,
                cursor: isUsed || submitted ? "default" : "pointer",
                opacity: isUsed ? 0.45 : 1,
                transition: "all 0.2s cubic-bezier(0.34,1.2,0.64,1)",
                transform: isUsed ? "scale(0.93)" : "scale(1)",
                boxShadow: isUsed ? "none" : "0 2px 0 #E0E7FF"
              }}>{choice}</div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Feedback Panel (slides up from bottom) ────────────────────────────────────
function FeedbackPanel({ correct, explanation, visible, onNext, isLast }) {
  if (!visible) return null;
  const bg = correct ? V.tealBg : V.errorBg;
  const border = correct ? V.teal : V.error;
  const btnColor = correct ? V.teal : V.error;
  const btnShadow = correct ? shadeColor(V.teal, -20) : shadeColor(V.error, -20);

  const messages = correct
    ? ["Nailed it! 🎯", "You're on fire! 🔥", "Brilliant! ✨", "That's right! 🌟", "Correct! Keep going 💪"]
    : ["Almost there! 💪", "Give it another shot", "You've got this! 🙌", "Don't worry — practice makes perfect", "Keep going! 💡"];
  const headline = messages[Math.floor(Math.random() * messages.length)];

  return (
    <div style={{
      position: "absolute", bottom: 0, left: 0, right: 0,
      background: bg,
      borderTop: `3px solid ${border}`,
      borderRadius: "24px 24px 0 0",
      padding: "20px 20px 28px",
      zIndex: 200,
      animation: "feedbackSlideUp 0.4s cubic-bezier(0.34,1.3,0.64,1)"
    }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 14 }}>
        <div style={{
          width: 40, height: 40, minWidth: 40, borderRadius: 14,
          background: border, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: `0 3px 0 ${btnShadow}`
        }}>
          {correct
            ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
            : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          }
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ margin: 0, fontSize: 17, fontWeight: 900, color: border, letterSpacing: "-0.01em" }}>{headline}</p>
          <p style={{ margin: "5px 0 0", fontSize: 13, color: V.textMid, lineHeight: 1.55, fontWeight: 600 }}>{explanation}</p>
        </div>
      </div>
      <button
        onClick={onNext}
        style={{
          width: "100%", background: border, border: "none",
          borderRadius: 16, padding: "15px 24px",
          color: "#fff", fontWeight: 900, fontSize: 17,
          cursor: "pointer", fontFamily: "inherit",
          boxShadow: `0 5px 0 ${btnShadow}`,
          letterSpacing: "0.01em",
          transition: "all 0.12s ease",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8
        }}>
        {isLast ? "🏁 Finish lesson" : correct ? "Next →" : "Try again →"}
      </button>
    </div>
  );
}

// ── Completion Modal ──────────────────────────────────────────────────────────
function CompletionModal({ xpEarned, correctCount, total, onBack }) {
  const [visible, setVisible] = React.useState(false);
  React.useEffect(() => { setTimeout(() => setVisible(true), 50); }, []);

  const pct = Math.round((correctCount / Math.max(total, 1)) * 100);
  const grade = pct === 100 ? "Perfect! 🌟" : pct >= 75 ? "Great work! 🎉" : pct >= 50 ? "Good effort! 💪" : "Keep practicing! 📚";

  return (
    <div style={{
      position: "absolute", inset: 0, zIndex: 800,
      background: "rgba(30, 27, 75, 0.7)",
      display: "flex", alignItems: "center", justifyContent: "center",
      backdropFilter: "blur(4px)"
    }}>
      <Confetti />
      <div style={{
        background: V.card, borderRadius: 28, margin: "0 20px",
        padding: "32px 24px 28px", textAlign: "center",
        border: `3px solid ${V.violetBorder}`,
        boxShadow: `0 8px 0 ${V.violetBorder}, 0 20px 60px rgba(79,70,229,0.3)`,
        transform: visible ? "scale(1) translateY(0)" : "scale(0.8) translateY(30px)",
        opacity: visible ? 1 : 0,
        transition: "all 0.5s cubic-bezier(0.34,1.3,0.64,1)"
      }}>
        <div style={{ fontSize: 64, marginBottom: 8, lineHeight: 1 }}>🏆</div>
        <h2 style={{ margin: "0 0 4px", fontSize: 26, fontWeight: 900, color: V.text, letterSpacing: "-0.02em" }}>
          Lesson Complete!
        </h2>
        <p style={{ margin: "0 0 24px", fontSize: 16, color: V.muted, fontWeight: 700 }}>{grade}</p>

        {/* Stats row */}
        <div style={{
          display: "flex", gap: 12, marginBottom: 24
        }}>
          {[
            { label: "XP Earned", value: `+${xpEarned}`, color: V.gold, bg: V.goldBg, border: V.goldBorder, icon: "⚡" },
            { label: "Accuracy", value: `${pct}%`, color: V.teal, bg: V.tealBg, border: V.tealBorder, icon: "🎯" },
            { label: "Correct", value: `${correctCount}/${total}`, color: V.violet, bg: V.violetBg, border: V.violetBorder, icon: "✓" },
          ].map(s => (
            <div key={s.label} style={{
              flex: 1, background: s.bg, border: `2px solid ${s.border}`,
              borderRadius: 16, padding: "12px 8px", textAlign: "center"
            }}>
              <div style={{ fontSize: 18, marginBottom: 4 }}>{s.icon}</div>
              <div style={{ fontSize: 18, fontWeight: 900, color: s.color, letterSpacing: "-0.02em" }}>{s.value}</div>
              <div style={{ fontSize: 10, fontWeight: 800, color: V.muted, textTransform: "uppercase", letterSpacing: "0.06em", marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        <PrimaryButton label="Continue 🚀" onPress={onBack} fullWidth />
      </div>
    </div>
  );
}

// ── Main Lesson Screen ────────────────────────────────────────────────────────
function LessonScreen({ unit, onBack, onXPEarned }) {
  const concepts = unit.items.filter(i => i.type === "concept");
  const questions = unit.items.filter(i => i.type !== "concept");
  const [sequence, setSequence] = React.useState([...concepts, ...questions]);
  const [idx, setIdx] = React.useState(0);
  const [selected, setSelected] = React.useState(null);
  const [filled, setFilled] = React.useState([]);
  const [submitted, setSubmitted] = React.useState(false);
  const [feedback, setFeedback] = React.useState(null);
  const [progressVal, setProgressVal] = React.useState(0);
  const [animKey, setAnimKey] = React.useState(0);
  const [hearts, setHearts] = React.useState(3);
  const [xpBurst, setXpBurst] = React.useState(false);
  const [xpBurstVal, setXpBurstVal] = React.useState(10);
  const [totalXP, setTotalXP] = React.useState(0);
  const [correctCount, setCorrectCount] = React.useState(0);
  const [questionCount, setQuestionCount] = React.useState(0);
  const [showCompletion, setShowCompletion] = React.useState(false);
  const [heartShake, setHeartShake] = React.useState(false);

  const item = sequence[idx];
  const total = sequence.length;
  const isConcept = item?.type === "concept";
  const isLast = idx === total - 1;

  React.useEffect(() => {
    setProgressVal(Math.round((idx / total) * 100));
  }, [idx, total]);

  React.useEffect(() => {
    if (item?.type === "fitb") setFilled(new Array(item.blanks.length).fill(null));
    else setFilled([]);
  }, [idx]);

  const isCorrect = () => {
    if (!item) return false;
    if (item.type === "mc") return selected === item.correct;
    if (item.type === "tf") return (selected === 0) === item.correct;
    if (item.type === "fitb") return JSON.stringify(filled.filter(Boolean)) === JSON.stringify(item.blanks);
    return false;
  };

  const canSubmit = () => {
    if (isConcept) return true;
    if (item?.type === "mc" || item?.type === "tf") return selected !== null;
    if (item?.type === "fitb") {
      const validFilled = filled.filter(Boolean);
      return validFilled.length === item.blanks.length;
    }
    return false;
  };

  const getLabel = () => {
    const orig = sequence.filter(i => !i._refresher);
    const refreshers = sequence.filter(i => i._refresher);
    if (item?.type === "concept") {
      const ci = sequence.slice(0, idx + 1).filter(i => i.type === "concept").length;
      return `Concept ${ci} of ${concepts.length}`;
    }
    if (item?._refresher) {
      const ri = sequence.slice(0, idx + 1).filter(i => i._refresher).length;
      return `Refresher ${ri} of ${refreshers.length}`;
    }
    const qi = sequence.slice(0, idx + 1).filter(i => i.type !== "concept" && !i._refresher).length;
    return `Question ${qi} of ${questions.length}`;
  };

  const triggerXPBurst = (xp) => {
    setXpBurstVal(xp);
    setXpBurst(true);
    setTimeout(() => setXpBurst(false), 1200);
  };

  const handleSubmit = () => {
    if (isConcept) { nextItem(); return; }
    const correct = isCorrect();
    setSubmitted(true);
    setFeedback({ correct, explanation: item.explanation });
    if (!isConcept) setQuestionCount(c => c + 1);
    if (correct) {
      const xp = item._refresher ? 5 : 10;
      setCorrectCount(c => c + 1);
      setTotalXP(x => x + xp);
      triggerXPBurst(xp);
    } else {
      setHearts(h => Math.max(0, h - 1));
      setHeartShake(true);
      setTimeout(() => setHeartShake(false), 600);
    }
  };

  const handleNext = () => {
    const correct = isCorrect();
    if (!correct && !isConcept) {
      setSequence(s => [...s, { ...item, _refresher: true }]);
    }
    nextItem();
  };

  const nextItem = () => {
    if (isLast) {
      setShowCompletion(true);
      if (onXPEarned) onXPEarned(totalXP);
      return;
    }
    setAnimKey(k => k + 1);
    setIdx(i => i + 1);
    setSelected(null);
    setFilled([]);
    setSubmitted(false);
    setFeedback(null);
  };

  const handleChipTap = (choice) => {
    const newFilled = [...filled];
    const firstEmpty = newFilled.findIndex(f => !f);
    if (firstEmpty !== -1) newFilled[firstEmpty] = choice;
    setFilled(newFilled);
  };

  const handleSlotTap = (slotIdx) => {
    const newFilled = [...filled];
    newFilled[slotIdx] = null;
    setFilled(newFilled);
  };

  if (!item) return null;

  const btnLabel = isConcept ? "Got it →" : "Check Answer";

  return (
    <Screen>
      {/* Header */}
      <div style={{
        padding: "10px 16px 12px",
        background: V.card,
        borderBottom: `2px solid ${V.border}`
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <BackButton onPress={onBack} />
          {/* Progress bar (wide) */}
          <div style={{ flex: 1, margin: "0 4px" }}>
            <ProgressBar value={progressVal} color={V.violet} height={12} animated showGlow />
          </div>
          {/* Hearts */}
          <div style={{
            transform: heartShake ? "scale(1.3)" : "scale(1)",
            transition: "transform 0.3s cubic-bezier(0.34,1.5,0.64,1)"
          }}>
            <Hearts count={hearts} />
          </div>
        </div>
        {/* Label */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingLeft: 8 }}>
          <span style={{ fontSize: 12, fontWeight: 800, color: V.muted }}>
            {unit.title}
          </span>
          <span style={{
            fontSize: 11, fontWeight: 900, color: V.violet,
            background: V.violetBg, padding: "3px 10px", borderRadius: 999
          }}>
            {getLabel()}
          </span>
        </div>
      </div>

      {/* XP burst overlay */}
      <XPBurst xp={xpBurstVal} visible={xpBurst} />

      {/* Content area */}
      <div style={{
        flex: 1, overflowY: submitted ? "hidden" : "auto",
        padding: "18px 16px",
        paddingBottom: submitted ? 200 : 18
      }}>
        <div key={animKey} style={{ animation: "slideFromRight 0.3s cubic-bezier(0.4,0,0.2,1)" }}>
          {item.type === "concept" && <ConceptCard item={item} />}
          {item.type === "mc" && (
            <MCCard item={item} selected={selected} onSelect={setSelected} submitted={submitted} />
          )}
          {item.type === "tf" && (
            <TFCard item={item} selected={selected} onSelect={setSelected} submitted={submitted} />
          )}
          {item.type === "fitb" && (
            <FITBCard item={item} filled={filled}
              onChipTap={handleChipTap} onSlotTap={handleSlotTap}
              submitted={submitted} isCorrect={isCorrect()} />
          )}
        </div>
      </div>

      {/* Bottom CTA — hidden when feedback panel is up */}
      {!submitted && (
        <div style={{ padding: "12px 16px 22px", background: V.card, borderTop: `2px solid ${V.border}` }}>
          <PrimaryButton
            label={btnLabel}
            onPress={handleSubmit}
            disabled={!canSubmit()}
            fullWidth
            style={{ fontSize: 17, padding: "16px 24px" }}
          />
        </div>
      )}

      {/* Feedback panel */}
      {submitted && feedback && (
        <FeedbackPanel
          correct={feedback.correct}
          explanation={feedback.explanation}
          visible={true}
          isLast={isLast}
          onNext={handleNext}
        />
      )}

      {/* Completion modal */}
      {showCompletion && (
        <CompletionModal
          xpEarned={totalXP}
          correctCount={correctCount}
          total={questionCount}
          onBack={onBack}
        />
      )}
    </Screen>
  );
}

Object.assign(window, { LessonScreen });
