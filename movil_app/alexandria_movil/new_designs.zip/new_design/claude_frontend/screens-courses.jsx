// ─── MY COURSES SCREEN ───────────────────────────────────────────────────────

function CourseCard({ course, onPress, sample }) {
  const [pressed, setPressed] = React.useState(false);
  const emoji = getCourseEmoji(course.title);
  const xp = Math.round(course.progress * 2.4);

  return (
    <div
      onClick={onPress}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        background: sample ? "#F9FAFB" : V.card,
        border: `2.5px solid ${sample ? V.locked : V.border}`,
        borderRadius: 22,
        cursor: "pointer",
        opacity: sample ? 0.65 : 1,
        transform: pressed ? "scale(0.972) translateY(3px)" : "scale(1) translateY(0)",
        boxShadow: pressed || sample ? "none" : `0 5px 0 ${V.violetBorder}, 0 8px 24px rgba(79,70,229,0.10)`,
        transition: "all 0.16s cubic-bezier(0.34,1.2,0.64,1)",
        overflow: "hidden",
      }}>
      {/* Top band */}
      <div style={{
        background: sample
          ? "linear-gradient(135deg, #F3F4F6, #E5E7EB)"
          : `linear-gradient(135deg, ${V.violet} 0%, ${V.violetLight} 100%)`,
        padding: "16px 18px 14px",
        display: "flex", alignItems: "flex-start", justifyContent: "space-between",
      }}>
        <div style={{
          width: 52, height: 52, borderRadius: 16,
          background: "rgba(255,255,255,0.2)",
          backdropFilter: "blur(4px)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 26, border: "2px solid rgba(255,255,255,0.25)"
        }}>{emoji}</div>
        {!sample && (
          <div style={{
            background: "rgba(255,255,255,0.2)", borderRadius: 999,
            padding: "4px 10px", border: "1.5px solid rgba(255,255,255,0.3)"
          }}>
            <span style={{ fontSize: 11, fontWeight: 800, color: "#fff" }}>⚡ {xp} XP</span>
          </div>
        )}
      </div>
      {/* Bottom content */}
      <div style={{ padding: "14px 18px 16px" }}>
        <h3 style={{
          margin: "0 0 10px", fontSize: 16, fontWeight: 900,
          color: sample ? V.muted : V.text,
          lineHeight: 1.25, letterSpacing: "-0.01em"
        }}>{course.title}</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: V.muted }}>
              Unit {course.currentUnit} of {course.totalUnits}
            </span>
            <span style={{
              fontSize: 12, fontWeight: 800,
              color: course.progress >= 100 ? V.teal : V.violet
            }}>{course.progress}%</span>
          </div>
          <ProgressBar
            value={course.progress}
            color={sample ? V.locked : course.progress >= 100 ? V.teal : V.violet}
            height={9} animated={!sample} showGlow={!sample} />
        </div>
        {course.progress >= 100 && (
          <div style={{
            marginTop: 10, display: "inline-flex", alignItems: "center", gap: 5,
            background: V.tealBg, borderRadius: 999, padding: "4px 12px",
            border: `1.5px solid ${V.tealBorder}`
          }}>
            <span style={{ fontSize: 11 }}>🏆</span>
            <span style={{ fontSize: 11, fontWeight: 800, color: V.teal }}>Completed!</span>
          </div>
        )}
      </div>
    </div>
  );
}

function MyCoursesScreen({ courses, onCoursePress, onGoToCraft, snackbar, showSnackbar, streak, totalXP }) {
  const isEmpty = !courses || courses.length === 0;

  return (
    <Screen>
      {/* Header */}
      <div style={{
        background: V.card, borderBottom: `2px solid ${V.border}`,
        padding: "14px 20px 14px",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 2 }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 24, fontWeight: 900, color: V.text, letterSpacing: "-0.02em" }}>
              My Courses
            </h1>
            {!isEmpty && (
              <p style={{ margin: "2px 0 0", fontSize: 13, color: V.muted, fontWeight: 600 }}>
                Keep the streak alive! 🔥
              </p>
            )}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <StreakBadge streak={streak || 0} />
            <div style={{
              display: "flex", alignItems: "center", gap: 4,
              background: V.violetBg, border: `2px solid ${V.violetBorder}`,
              borderRadius: 999, padding: "4px 10px"
            }}>
              <span style={{ fontSize: 13 }}>⚡</span>
              <span style={{ fontSize: 13, fontWeight: 800, color: V.violet }}>{totalXP || 0}</span>
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 18px 0" }}>
        {isEmpty ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 20, paddingTop: 8 }}>
            {/* Empty state hero */}
            <div style={{
              background: `linear-gradient(135deg, ${V.violetBg} 0%, ${V.skyBg} 100%)`,
              borderRadius: 24, padding: "28px 24px",
              textAlign: "center", border: `2px solid ${V.violetBorder}`
            }}>
              <div style={{ fontSize: 56, marginBottom: 12 }}>🧠</div>
              <h2 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 900, color: V.text }}>
                Your journey starts here
              </h2>
              <p style={{ margin: "0 0 20px", fontSize: 14, color: V.muted, lineHeight: 1.6, fontWeight: 600 }}>
                Craft your first AI-powered course and start earning XP!
              </p>
              <PrimaryButton label="✨ Craft my first course" onPress={onGoToCraft} fullWidth />
            </div>

            {/* Ghost preview card */}
            <div>
              <p style={{ fontSize: 12, fontWeight: 800, color: V.muted, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>
                Preview
              </p>
              <CourseCard sample
                course={{ title: "Your First Course Here", currentUnit: 1, totalUnits: 5, progress: 0 }}
                onPress={() => showSnackbar("✨ Go to Craft tab to create your first course!")} />
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Continue learning nudge */}
            {courses.some(c => c.progress > 0 && c.progress < 100) && (
              <div style={{
                background: `linear-gradient(135deg, ${V.goldBg}, #FFF7ED)`,
                border: `2px solid ${V.goldBorder}`,
                borderRadius: 18, padding: "12px 16px",
                display: "flex", alignItems: "center", gap: 12
              }}>
                <span style={{ fontSize: 24 }}>🔥</span>
                <div>
                  <p style={{ margin: 0, fontSize: 14, fontWeight: 900, color: "#92400E" }}>Don't break your streak!</p>
                  <p style={{ margin: 0, fontSize: 12, color: "#B45309", fontWeight: 600 }}>Pick up where you left off</p>
                </div>
              </div>
            )}
            {courses.map(course => (
              <CourseCard key={course.id} course={course} onPress={() => onCoursePress(course)} />
            ))}
            <div style={{ height: 8 }} />
          </div>
        )}
      </div>

      <Snackbar message={snackbar.message} visible={snackbar.visible} onHide={snackbar.hide} />
    </Screen>
  );
}

// ─── COURSE UNITS SCREEN ─────────────────────────────────────────────────────

function UnitPathNode({ unit, index, onPress, isLast }) {
  const [pressed, setPressed] = React.useState(false);
  const isLocked = unit.state === "locked";
  const isCompleted = unit.state === "completed";
  const isCurrent = unit.state === "current";

  // Connector line alignment: nodes alternate left/right for path feel
  const isLeft = index % 2 === 0;

  const nodeColor = isCompleted ? V.teal : isCurrent ? V.violet : V.locked;
  const nodeBg = isCompleted ? V.tealBg : isCurrent ? V.violetBg : "#F3F4F6";
  const borderColor = isCompleted ? V.tealBorder : isCurrent ? V.violetBorder : "#E5E7EB";

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", position: "relative" }}>
      {/* Connector line */}
      {!isLast && (
        <div style={{
          position: "absolute", top: "100%", left: "50%",
          width: 3, height: 28, marginLeft: -1.5,
          background: isCompleted ? `linear-gradient(${V.tealBorder}, ${V.violetBorder})` : "#E5E7EB",
          zIndex: 0
        }} />
      )}

      {/* Node card */}
      <div
        onClick={() => !isLocked && onPress(unit)}
        onMouseDown={() => !isLocked && setPressed(true)}
        onMouseUp={() => setPressed(false)}
        onMouseLeave={() => setPressed(false)}
        style={{
          width: "100%",
          background: isLocked ? "#F9FAFB" : V.card,
          border: `2.5px solid ${borderColor}`,
          borderRadius: 20,
          padding: "14px 16px",
          display: "flex", alignItems: "center", gap: 14,
          cursor: isLocked ? "default" : "pointer",
          opacity: isLocked ? 0.5 : 1,
          transform: pressed ? "scale(0.975) translateY(2px)" : isCurrent ? "scale(1.02)" : "scale(1)",
          boxShadow: pressed || isLocked ? "none"
            : isCurrent ? `0 5px 0 ${V.violetBorder}, 0 8px 20px rgba(79,70,229,0.15)`
            : `0 3px 0 ${borderColor}`,
          transition: "all 0.18s cubic-bezier(0.34,1.2,0.64,1)",
          position: "relative", zIndex: 1
        }}>

        {/* Big icon node */}
        <div style={{
          width: 52, height: 52, minWidth: 52, borderRadius: 16,
          background: nodeColor,
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: isLocked ? "none" : `0 4px 0 ${shadeColor(nodeColor, -30)}`,
          transition: "all 0.18s ease"
        }}>
          {isCompleted ? (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          ) : isCurrent ? (
            <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          ) : (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          )}
        </div>

        {/* Text */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
            <span style={{
              fontSize: 10, fontWeight: 900, letterSpacing: "0.08em", textTransform: "uppercase",
              color: nodeColor,
              background: isLocked ? "transparent" : (isCompleted ? V.tealBg : V.violetBg),
              padding: "2px 7px", borderRadius: 999
            }}>
              {isCompleted ? "✓ Done" : isCurrent ? "▶ Now" : "🔒 Locked"}
            </span>
          </div>
          <p style={{ margin: 0, fontSize: 15, fontWeight: 900, color: isLocked ? V.muted : V.text, lineHeight: 1.2 }}>
            {unit.title}
          </p>
          <p style={{ margin: "3px 0 0", fontSize: 12, color: V.muted, lineHeight: 1.35, fontWeight: 600 }}>
            {unit.description}
          </p>
        </div>

        {/* Chevron */}
        {!isLocked && (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
            stroke={isCurrent ? V.violet : V.teal} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 18l6-6-6-6"/>
          </svg>
        )}
      </div>

      {/* Spacer for connector */}
      {!isLast && <div style={{ height: 28 }} />}
    </div>
  );
}

function CourseUnitsScreen({ course, onBack, onUnitPress }) {
  const completedCount = course.units.filter(u => u.state === "completed").length;
  const overallProgress = Math.round((completedCount / course.units.length) * 100);
  const currentIdx = course.units.findIndex(u => u.state === "current");
  const emoji = getCourseEmoji(course.title);

  return (
    <Screen>
      {/* Hero header */}
      <div style={{
        background: `linear-gradient(160deg, ${V.violet} 0%, ${V.violetLight} 100%)`,
        padding: "14px 16px 20px",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 14 }}>
          <BackButton onPress={onBack} />
          <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 14, fontWeight: 700 }}>Back</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 18,
            background: "rgba(255,255,255,0.2)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 28, border: "2px solid rgba(255,255,255,0.3)"
          }}>{emoji}</div>
          <div style={{ flex: 1 }}>
            <h2 style={{
              margin: 0, fontSize: 18, fontWeight: 900, color: "#fff",
              lineHeight: 1.25, letterSpacing: "-0.01em",
              display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
              overflow: "hidden"
            }}>{course.title}</h2>
            <p style={{ margin: "4px 0 0", fontSize: 12, color: "rgba(255,255,255,0.75)", fontWeight: 700 }}>
              {completedCount} of {course.units.length} units complete
            </p>
          </div>
        </div>
        {/* Progress */}
        <div style={{ marginTop: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.75)" }}>Progress</span>
            <span style={{ fontSize: 12, fontWeight: 900, color: "#fff" }}>{overallProgress}%</span>
          </div>
          <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 999, height: 10, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 999,
              background: "linear-gradient(90deg, #fff, rgba(255,255,255,0.8))",
              width: `${overallProgress}%`,
              transition: "width 0.8s cubic-bezier(0.34,1.2,0.64,1)"
            }} />
          </div>
        </div>
      </div>

      {/* Unit path */}
      <div style={{ flex: 1, overflowY: "auto", padding: "24px 18px 20px" }}>
        <p style={{ margin: "0 0 16px", fontSize: 12, fontWeight: 800, color: V.muted, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          Your Learning Path
        </p>
        {course.units.map((unit, i) => (
          <UnitPathNode
            key={unit.id}
            unit={unit}
            index={i}
            onPress={onUnitPress}
            isLast={i === course.units.length - 1}
          />
        ))}
        <div style={{ height: 12 }} />
      </div>
    </Screen>
  );
}

Object.assign(window, { MyCoursesScreen, CourseUnitsScreen });
