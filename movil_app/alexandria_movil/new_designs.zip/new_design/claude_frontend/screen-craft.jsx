// ─── CRAFT COURSE SCREEN ─────────────────────────────────────────────────────

const CRAFT_STEPS = [
  { icon: "📋", text: "Queued…" },
  { icon: "🔍", text: "Analyzing your prompt…" },
  { icon: "🏗️", text: "Generating course structure…" },
  { icon: "✍️", text: "Writing lessons & questions…" },
  { icon: "🎉", text: "Course ready!" },
];

function CraftCourseScreen({ courses, onCourseCreated, snackbar, showSnackbar }) {
  const [prompt, setPrompt] = React.useState("");
  const [focused, setFocused] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [jobStep, setJobStep] = React.useState(-1);
  const [jobDone, setJobDone] = React.useState(false);
  const stepRef = React.useRef(0);
  const timerRef = React.useRef(null);

  const startJob = () => {
    setJobStep(0); stepRef.current = 0;
    timerRef.current = setInterval(() => {
      stepRef.current += 1;
      if (stepRef.current >= CRAFT_STEPS.length - 1) {
        clearInterval(timerRef.current);
        setJobStep(CRAFT_STEPS.length - 1);
        setJobDone(true);
        setSubmitting(false);
        setTimeout(() => onCourseCreated(prompt), 1600);
      } else {
        setJobStep(stepRef.current);
      }
    }, 2000);
  };

  React.useEffect(() => () => clearInterval(timerRef.current), []);

  const handleCreate = () => {
    if (!prompt.trim()) { showSnackbar("✏️ What do you want to learn today?"); return; }
    if (courses.length >= 3) { showSnackbar("🚦 Beta limit: 3 courses max. Delete one first!"); return; }
    setSubmitting(true);
    setJobDone(false);
    setJobStep(-1);
    setTimeout(startJob, 500);
  };

  const charCount = prompt.length;
  const goodLength = charCount >= 20 && charCount <= 300;

  return (
    <Screen>
      {/* Header */}
      <div style={{
        background: `linear-gradient(160deg, ${V.violet} 0%, #7C3AED 100%)`,
        padding: "16px 20px 22px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 44, height: 44, borderRadius: 14,
            background: "rgba(255,255,255,0.15)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, border: "2px solid rgba(255,255,255,0.25)"
          }}>✨</div>
          <div>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 900, color: "#fff", letterSpacing: "-0.02em" }}>
              Craft a Course
            </h1>
            <p style={{ margin: 0, fontSize: 13, color: "rgba(255,255,255,0.75)", fontWeight: 600 }}>
              Tell the AI what you want to master
            </p>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 18px 0" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

          {/* Prompt box */}
          <div style={{
            background: V.card,
            border: `2.5px solid ${focused ? V.violet : V.border}`,
            borderRadius: 22,
            overflow: "hidden",
            boxShadow: focused
              ? `0 0 0 4px ${V.violetBg}, 0 5px 0 ${V.violetBorder}`
              : `0 4px 0 ${V.border}`,
            transition: "all 0.2s ease"
          }}>
            <div style={{ padding: "14px 16px 0" }}>
              <label style={{
                fontSize: 11, fontWeight: 900, color: V.violet,
                textTransform: "uppercase", letterSpacing: "0.08em",
                display: "flex", alignItems: "center", gap: 5
              }}>
                <span>Your Topic</span>
              </label>
            </div>
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              disabled={submitting}
              placeholder={"e.g. 'Beginner Python for someone who knows JavaScript' or 'Conversational Spanish for a trip to Mexico City'"}
              rows={5}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              style={{
                width: "100%", border: "none", outline: "none",
                padding: "10px 16px 4px", fontSize: 14, lineHeight: 1.65,
                background: "transparent", color: V.text,
                fontFamily: "inherit", resize: "none",
                boxSizing: "border-box", fontWeight: 600
              }}
            />
            <div style={{
              padding: "8px 16px 14px",
              display: "flex", justifyContent: "space-between", alignItems: "center"
            }}>
              <span style={{
                fontSize: 11, fontWeight: 700,
                color: charCount > 300 ? V.error : charCount >= 20 ? V.teal : V.muted
              }}>
                {charCount > 0 && (charCount < 20 ? `${20 - charCount} more characters for best results` : charCount > 300 ? "Try to keep it under 300" : "✓ Good length")}
              </span>
              <span style={{ fontSize: 11, color: V.muted, fontWeight: 700 }}>{charCount}/300</span>
            </div>
          </div>

          {/* Create button */}
          <PrimaryButton
            label={submitting ? "AI is crafting…" : "✨ Craft My Course"}
            onPress={handleCreate}
            loading={submitting && jobStep < 0}
            disabled={submitting || jobDone}
            fullWidth
            style={{ fontSize: 18, padding: "18px 24px", letterSpacing: "0.01em" }}
          />

          {/* Job progress */}
          {jobStep >= 0 && (
            <div style={{
              background: V.card, border: `2.5px solid ${jobDone ? V.tealBorder : V.violetBorder}`,
              borderRadius: 22, overflow: "hidden",
              boxShadow: `0 4px 0 ${jobDone ? V.tealBorder : V.violetBorder}`,
              animation: "slideUp 0.4s cubic-bezier(0.34,1.3,0.64,1)"
            }}>
              {/* Steps */}
              <div style={{ padding: "16px 18px 12px" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {CRAFT_STEPS.map((step, i) => {
                    const isDone = i < jobStep;
                    const isCurrent = i === jobStep;
                    return (
                      <div key={i} style={{
                        display: "flex", alignItems: "center", gap: 10,
                        opacity: i > jobStep ? 0.3 : 1,
                        transition: "opacity 0.3s ease"
                      }}>
                        <div style={{
                          width: 32, height: 32, borderRadius: 10,
                          background: isDone ? V.tealBg : isCurrent ? V.violetBg : V.locked,
                          border: `2px solid ${isDone ? V.tealBorder : isCurrent ? V.violetBorder : "#E5E7EB"}`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: isDone ? 14 : 16,
                          transition: "all 0.3s ease"
                        }}>
                          {isDone ? (
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={V.teal} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                          ) : step.icon}
                        </div>
                        <span style={{
                          fontSize: 14, fontWeight: isCurrent ? 800 : 700,
                          color: isDone ? V.teal : isCurrent ? V.violet : V.muted
                        }}>
                          {step.text}
                          {isCurrent && !jobDone && (
                            <span style={{ display: "inline-flex", gap: 2, marginLeft: 4 }}>
                              {[0,1,2].map(d => (
                                <span key={d} style={{
                                  width: 4, height: 4, borderRadius: "50%",
                                  background: V.violet, display: "inline-block",
                                  animation: `dotBounce 1s ${d*0.2}s infinite`
                                }} />
                              ))}
                            </span>
                          )}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              {/* Progress bar */}
              <div style={{ padding: "0 18px 16px" }}>
                <ProgressBar
                  value={Math.round((jobStep / (CRAFT_STEPS.length - 1)) * 100)}
                  color={jobDone ? V.teal : V.violet}
                  height={8} animated showGlow />
              </div>
            </div>
          )}

          {/* Tips */}
          <div style={{
            background: V.goldBg, border: `2px solid ${V.goldBorder}`,
            borderRadius: 20, padding: "16px 18px",
            boxShadow: `0 3px 0 ${V.goldBorder}`
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
              <span style={{ fontSize: 18 }}>💡</span>
              <span style={{ fontSize: 14, fontWeight: 900, color: "#92400E" }}>Pro tips for great courses</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                { emoji: "🎯", tip: "State your goal, not just the topic", sub: "\"Pass a React interview\" beats \"learn React\"" },
                { emoji: "📊", tip: "Mention your current level", sub: "Beginner / intermediate / advanced changes everything" },
                { emoji: "🗺️", tip: "Add context about yourself", sub: "What you already know helps skip what you don't need" },
              ].map(({ emoji, tip, sub }, i) => (
                <div key={i} style={{ display: "flex", gap: 10 }}>
                  <span style={{ fontSize: 18, lineHeight: 1.2 }}>{emoji}</span>
                  <div>
                    <p style={{ margin: 0, fontSize: 13, fontWeight: 800, color: "#92400E" }}>{tip}</p>
                    <p style={{ margin: "2px 0 0", fontSize: 12, color: "#B45309", fontWeight: 600, fontStyle: "italic" }}>"{sub}"</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ height: 8 }} />
        </div>
      </div>
      <Snackbar message={snackbar.message} visible={snackbar.visible} onHide={snackbar.hide} />
    </Screen>
  );
}

Object.assign(window, { CraftCourseScreen });
