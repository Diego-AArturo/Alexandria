// ─── AUTH SCREEN ─────────────────────────────────────────────────────────────

function AuthScreen({ onAuth }) {
  const [mode, setMode] = React.useState("signin");
  const [email, setEmail] = React.useState("");
  const [name, setName] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [errors, setErrors] = React.useState({});
  const [loading, setLoading] = React.useState(false);
  const [animKey, setAnimKey] = React.useState(0);

  const switchMode = (m) => {
    setMode(m); setErrors({}); setAnimKey(k => k + 1);
  };

  const validate = () => {
    const e = {};
    if (!email.includes("@")) e.email = "Enter a valid email";
    if (password.length < 6) e.password = "At least 6 characters";
    if (mode === "signup" && !name.trim()) e.name = "Name is required";
    return e;
  };

  const handleSubmit = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onAuth({ name: name || email.split("@")[0], email });
    }, 1100);
  };

  return (
    <Screen style={{ justifyContent: "flex-end" }}>
      {/* Animated hero */}
      <div style={{
        flex: 1,
        background: `linear-gradient(160deg, ${V.text} 0%, #312E81 50%, ${V.violet} 100%)`,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        padding: "0 32px", position: "relative", overflow: "hidden"
      }}>
        {/* Decorative circles */}
        {[
          { size: 200, top: -60, left: -60, opacity: 0.06 },
          { size: 140, bottom: 20, right: -40, opacity: 0.08 },
          { size: 80, top: "30%", right: 30, opacity: 0.06 },
        ].map((c, i) => (
          <div key={i} style={{
            position: "absolute",
            width: c.size, height: c.size, borderRadius: "50%",
            background: "#fff", opacity: c.opacity,
            top: c.top, bottom: c.bottom, left: c.left, right: c.right
          }} />
        ))}

        {/* Logo */}
        <div style={{
          width: 80, height: 80, borderRadius: 26,
          background: "rgba(255,255,255,0.12)",
          border: "2px solid rgba(255,255,255,0.2)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 38, marginBottom: 16,
          boxShadow: "0 8px 32px rgba(0,0,0,0.2)"
        }}>🧠</div>

        <h1 style={{
          color: "#fff", fontSize: 36, fontWeight: 900,
          margin: "0 0 8px", letterSpacing: "-0.03em", textAlign: "center"
        }}>Alexandria</h1>
        <p style={{
          color: "rgba(255,255,255,0.7)", fontSize: 15, margin: 0,
          fontWeight: 700, textAlign: "center"
        }}>Learn anything. Master everything.</p>

        {/* Feature pills */}
        <div style={{ display: "flex", gap: 8, marginTop: 20, flexWrap: "wrap", justifyContent: "center" }}>
          {["✨ AI-crafted courses", "🔥 Daily streaks", "⚡ Earn XP"].map(f => (
            <div key={f} style={{
              background: "rgba(255,255,255,0.12)",
              border: "1.5px solid rgba(255,255,255,0.18)",
              borderRadius: 999, padding: "5px 12px",
              fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.9)"
            }}>{f}</div>
          ))}
        </div>
      </div>

      {/* Form sheet */}
      <div style={{
        background: V.card,
        borderRadius: "28px 28px 0 0",
        padding: "24px 22px 32px",
        boxShadow: "0 -8px 40px rgba(79,70,229,0.18)"
      }}>
        {/* Mode switcher */}
        <div style={{
          display: "flex", background: V.offWhite,
          borderRadius: 14, padding: 4, marginBottom: 22, gap: 4,
          border: `2px solid ${V.border}`
        }}>
          {["signin", "signup"].map(m => (
            <button key={m} onClick={() => switchMode(m)} style={{
              flex: 1, padding: "10px 0", borderRadius: 10, border: "none",
              fontWeight: 800, fontSize: 14, cursor: "pointer",
              background: mode === m ? V.violet : "transparent",
              color: mode === m ? "#fff" : V.muted,
              transition: "all 0.2s cubic-bezier(0.34,1.2,0.64,1)",
              transform: mode === m ? "scale(1.02)" : "scale(1)",
              boxShadow: mode === m ? `0 3px 0 ${V.violetDark}` : "none",
              fontFamily: "inherit"
            }}>
              {m === "signin" ? "Sign In" : "Create Account"}
            </button>
          ))}
        </div>

        {/* Fields */}
        <div key={animKey} style={{
          display: "flex", flexDirection: "column", gap: 12,
          animation: "slideUp 0.28s ease"
        }}>
          <InputField label="Email" value={email} onChange={setEmail}
            type="email" placeholder="you@example.com" error={errors.email} autoFocus />
          {mode === "signup" && (
            <InputField label="Name" value={name} onChange={setName}
              placeholder="Your full name" error={errors.name} />
          )}
          <InputField label="Password" value={password} onChange={setPassword}
            type="password" placeholder="••••••••" error={errors.password} />
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 11, marginTop: 20 }}>
          <PrimaryButton
            label={mode === "signin" ? "Let's go! 🚀" : "Create Account 🎉"}
            onPress={handleSubmit} loading={loading} fullWidth />
          {mode === "signin" && (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ flex: 1, height: 1.5, background: V.border }} />
                <span style={{ fontSize: 12, color: V.muted, fontWeight: 700 }}>or</span>
                <div style={{ flex: 1, height: 1.5, background: V.border }} />
              </div>
              <GoogleButton onPress={() => onAuth({ name: "Google User", email: "user@gmail.com" })} />
            </>
          )}
        </div>
      </div>
    </Screen>
  );
}

Object.assign(window, { AuthScreen });
