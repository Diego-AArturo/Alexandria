// Mock data for Alexandria app
window.ALEXANDRIA_DATA = {
  user: {
    name: "Alex Rivera",
    email: "alex@example.com",
    username: "alexrivera",
    language: "English",
    avatar: "AR"
  },
  courses: [
    {
      id: 1,
      title: "Introduction to Machine Learning",
      totalUnits: 5,
      currentUnit: 2,
      progress: 40,
      units: [
        {
          id: 1, title: "What is ML?", description: "Core concepts and history of machine learning",
          state: "completed",
          items: [
            { type: "concept", title: "Machine Learning Defined", body: "Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed.\n\n• Learns from data patterns\n• Improves over time automatically\n• Powers recommendations, search, translation" },
            { type: "concept", title: "Types of ML", body: "There are three main paradigms:\n\n• Supervised Learning — labeled training data\n• Unsupervised Learning — find hidden patterns\n• Reinforcement Learning — learn by reward signals" },
            { type: "mc", question: "Which type of ML uses labeled training data?", options: ["Unsupervised Learning", "Supervised Learning", "Reinforcement Learning", "Deep Learning"], correct: 1, explanation: "Supervised learning trains on labeled examples, mapping inputs to known outputs." },
            { type: "tf", question: "Machine learning systems must be explicitly programmed for every task they perform.", correct: false, explanation: "ML systems learn from data, so they don't need explicit programming for every task — that's the key distinction." },
          ]
        },
        {
          id: 2, title: "Data & Features", description: "How data shapes what your model learns",
          state: "current",
          items: [
            { type: "concept", title: "What is Training Data?", body: "Training data is the collection of examples your model learns from. The quality and quantity of this data directly determines how well your model performs.\n\n• More diverse data → better generalization\n• Noisy or biased data → poor results\n• Data preprocessing is critical" },
            { type: "concept", title: "Features vs Labels", body: "Every training example has two parts:\n\n• Features — the input variables (e.g. age, height, color)\n• Labels — the target output you want to predict (e.g. \"spam\" or \"not spam\")" },
            { type: "mc", question: "What do we call the input variables used to train a model?", options: ["Labels", "Weights", "Features", "Epochs"], correct: 2, explanation: "Features are the measurable properties used as inputs. Labels are what we're trying to predict." },
            { type: "fitb", question: "Complete the sentence:", stem: "In supervised learning, the model learns to map ___ to ___.", blanks: ["features", "labels"], choices: ["labels", "features", "weights", "epochs"], explanation: "Supervised learning maps input features to target labels using the patterns learned from training data." },
          ]
        },
        {
          id: 3, title: "Model Training", description: "The mechanics of training and optimization",
          state: "locked",
          items: []
        },
        {
          id: 4, title: "Evaluation", description: "Measuring model performance accurately",
          state: "locked",
          items: []
        },
        {
          id: 5, title: "Deployment", description: "Taking models from lab to production",
          state: "locked",
          items: []
        }
      ]
    },
    {
      id: 2,
      title: "Spanish for Beginners",
      totalUnits: 4,
      currentUnit: 4,
      progress: 75,
      units: [
        { id: 1, title: "Greetings", description: "Say hello and introduce yourself", state: "completed", items: [] },
        { id: 2, title: "Numbers", description: "Count and use numbers in conversation", state: "completed", items: [] },
        { id: 3, title: "Colors & Adjectives", description: "Describe the world around you", state: "completed", items: [] },
        { id: 4, title: "Food & Dining", description: "Order food and talk about cuisine", state: "current", items: [
          { type: "concept", title: "Food Vocabulary", body: "Essential food words:\n\n• el desayuno — breakfast\n• el almuerzo — lunch\n• la cena — dinner\n• la comida — food / meal" },
          { type: "mc", question: "How do you say 'lunch' in Spanish?", options: ["la cena", "el desayuno", "el almuerzo", "la comida"], correct: 2, explanation: "El almuerzo means lunch. La cena is dinner, el desayuno is breakfast." },
          { type: "tf", question: "'La cena' means breakfast in Spanish.", correct: false, explanation: "La cena means dinner. Breakfast is el desayuno." },
        ]},
      ]
    }
  ]
};
