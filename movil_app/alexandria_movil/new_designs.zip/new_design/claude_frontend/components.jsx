// ─── SHARED COMPONENTS ───────────────────────────────────────────────────────

const V = {
  violet: "#4F46E5",
  violetDark: "#3730A3",
  violetLight: "#6366F1",
  violetBg: "#EEF2FF",
  violetBorder: "#C7D2FE",
  teal: "#059669",
  tealLight: "#10B981",
  tealBg: "#D1FAE5",
  tealBorder: "#6EE7B7",
  gold: "#F59E0B",
  goldLight: "#FBBF24",
  goldBg: "#FEF3C7",
  goldBorder: "#FCD34D",
  error: "#EF4444",
  errorDark: "#DC2626",
  errorBg: "#FEE2E2",
  errorBorder: "#FCA5A5",
  offWhite: "#F8F7FF",
  card: "#FFFFFF",
  border: "#E0E7FF",
  text: "#1E1B4B",
  textMid: "#374151",
  muted: "#9CA3AF",
  locked: "#E5E7EB",
  lockedText: "#9CA3AF",
  coral: "#FF6B6B",
  coralBg: "#FFF0F0",
  sky: "#0EA5E9",
  skyBg: "#E0F2FE",
  lime: "#84CC16",
  limeBg: "#F7FEE7",
};

// ─── Snackbar ────────────────────────────────────────────────────────────────
function Snackbar({ message, visible, onHide }) {
  React.useEffect(() => {
    if (visible) { const t = setTimeout(onHide, 2800); return () => clearTimeout(t); }
  }, [visible, onHide]);
  return (
    <div style={{
      position: "absolute", bottom: 96, left: 16, right: 16, zIndex: 1200,
      background: V.text, color: "#fff", borderRadius: 16, padding: "14px 20px",
      fontSize: 14, fontWeight: 700, textAlign: "center",
      transform: visible ? "translateY(0) scale(1)" : "translateY(20px) scale(0.96)",
      opacity: visible ? 1 : 0,
      transition: "all 0.35s cubic-bezier(0.34,1.56,0.64,1)",
      pointerEvents: visible ? "auto" : "none",
      boxShadow: "0 8px 32px rgba(0,0,0,0.22)"
    }}>{message}</div>
  );
}

// ─── XP Burst ────────────────────────────────────────────────────────────────
function XPBurst({ xp, visible }) {
  if (!visible) return null;
  return (
    <div style={{
      position: "absolute", top: "30%", left: "50%",
      transform: "translateX(-50%)",
      zIndex: 1100, pointerEvents: "none",
      animation: "xpBurst 1.2s cubic-bezier(0.34,1.56,0.64,1) forwards"
    }}>
      <div style={{
        background: V.gold, color: "#fff",
        padding: "10px 22px", borderRadius: 999,
        fontSize: 20, fontWeight: 900,
        boxShadow: `0 4px 0 ${V.goldBorder}, 0 8px 24px rgba(245,158,11,0.4)`,
        display: "flex", alignItems: "center", gap: 6
      }}>
        ⚡ +{xp} XP
      </div>
    </div>
  );
}

// ─── Confetti ────────────────────────────────────────────────────────────────
function Confetti() {
  const pieces = React.useMemo(() => {
    const colors = [V.gold, V.violet, V.tealLight, V.coral, "#A855F7", "#EC4899"];
    return Array.from({ length: 28 }, (_, i) => ({
      id: i,
      color: colors[i % colors.length],
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 0.5}s`,
      size: Math.random() * 8 + 6,
      shape: Math.random() > 0.5 ? "circle" : "rect",
      rotate: Math.random() * 360,
    }));
  }, []);
  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden", zIndex: 500 }}>
      {pieces.map(p => (
        <div key={p.id} style={{
          position: "absolute", top: -20, left: p.left,
          width: p.size, height: p.shape === "circle" ? p.size : p.size * 0.6,
          background: p.color,
          borderRadius: p.shape === "circle" ? "50%" : 2,
          transform: `rotate(${p.rotate}deg)`,
          animation: `confettiFall 1.8s ${p.delay} cubic-bezier(0.23,1,0.32,1) forwards`,
          opacity: 0
        }} />
      ))}
    </div>
  );
}

// ─── Hearts ──────────────────────────────────────────────────────────────────
function Hearts({ count, max = 3 }) {
  return (
    <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
      {Array.from({ length: max }).map((_, i) => (
        <svg key={i} width="20" height="20" viewBox="0 0 24 24">
          <path
            d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"
            fill={i < count ? V.coral : "#E5E7EB"}
            stroke={i < count ? V.coral : "#D1D5DB"}
            strokeWidth="1.5"
          />
        </svg>
      ))}
    </div>
  );
}

// ─── Streak Badge ─────────────────────────────────────────────────────────────
function StreakBadge({ streak }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 4,
      background: streak > 0 ? V.goldBg : V.locked,
      border: `2px solid ${streak > 0 ? V.goldBorder : "#E5E7EB"}`,
      borderRadius: 999, padding: "4px 10px"
    }}>
      <span style={{ fontSize: 14 }}>🔥</span>
      <span style={{ fontSize: 13, fontWeight: 800, color: streak > 0 ? V.gold : V.muted }}>{streak}</span>
    </div>
  );
}

// ─── Progress Bar ─────────────────────────────────────────────────────────────
function ProgressBar({ value, color, height = 10, animated = false, rounded = true, showGlow }) {
  const [display, setDisplay] = React.useState(animated ? 0 : value);
  React.useEffect(() => {
    if (animated) { const t = setTimeout(() => setDisplay(value), 80); return () => clearTimeout(t); }
    else setDisplay(value);
  }, [value, animated]);
  return (
    <div style={{
      background: "#E0E7FF", borderRadius: rounded ? 999 : 4, height,
      overflow: "hidden", position: "relative"
    }}>
      <div style={{
        width: `${Math.max(display, 0)}%`, height: "100%",
        background: color || V.violet, borderRadius: rounded ? 999 : 4,
        transition: animated ? "width 0.7s cubic-bezier(0.34,1.2,0.64,1)" : "none",
        boxShadow: showGlow ? `0 0 8px ${color || V.violet}60` : "none",
        position: "relative"
      }}>
        {showGlow && display > 5 && (
          <div style={{
            position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)",
            width: 8, height: 8, borderRadius: "50%",
            background: "#fff", opacity: 0.7
          }} />
        )}
      </div>
    </div>
  );
}

// ─── Back Button ─────────────────────────────────────────────────────────────
function BackButton({ onPress }) {
  const [pressed, setPressed] = React.useState(false);
  return (
    <button onClick={onPress}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)} onMouseLeave={() => setPressed(false)}
      style={{
        width: 40, height: 40, borderRadius: 12,
        background: pressed ? V.violetBg : "transparent",
        border: "none", cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
        transform: pressed ? "scale(0.9)" : "scale(1)",
        transition: "all 0.15s ease"
      }}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={V.muted} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 12H5M12 5l-7 7 7 7" />
      </svg>
    </button>
  );
}

// ─── Chunky Primary Button (3D Duolingo style) ───────────────────────────────
function PrimaryButton({ label, onPress, disabled, loading, fullWidth, style: extStyle, color, small }) {
  const [pressed, setPressed] = React.useState(false);
  const bg = disabled ? "#C7D2FE" : (color || V.violet);
  const shadow = disabled ? "#A5B4FC" : (color ? shadeColor(color, -20) : V.violetDark);
  return (
    <button
      onClick={!disabled && !loading ? onPress : undefined}
      onMouseDown={() => !disabled && setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        background: bg,
        border: "none",
        borderRadius: small ? 14 : 16,
        padding: small ? "11px 20px" : "16px 24px",
        cursor: disabled ? "not-allowed" : "pointer",
        color: "#fff",
        fontWeight: 800,
        fontSize: small ? 14 : 17,
        width: fullWidth ? "100%" : "auto",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        transform: pressed && !disabled ? "translateY(3px)" : "translateY(0)",
        boxShadow: pressed || disabled ? "none" : `0 5px 0 ${shadow}, 0 8px 20px ${bg}50`,
        transition: "all 0.12s cubic-bezier(0.34,1.2,0.64,1)",
        letterSpacing: "0.02em",
        fontFamily: "inherit",
        ...extStyle
      }}>
      {loading ? (
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{
            width: 18, height: 18, border: "2.5px solid rgba(255,255,255,0.35)",
            borderTop: "2.5px solid #fff", borderRadius: "50%",
            animation: "spin 0.7s linear infinite", display: "inline-block"
          }} />
          {label}
        </span>
      ) : label}
    </button>
  );
}

// helper
function shadeColor(hex, pct) {
  const n = parseInt(hex.replace("#",""),16);
  const r = Math.min(255, Math.max(0, (n>>16) + pct*2));
  const g = Math.min(255, Math.max(0, ((n>>8)&0xff) + pct*2));
  const b = Math.min(255, Math.max(0, (n&0xff) + pct*2));
  return "#"+[r,g,b].map(x=>x.toString(16).padStart(2,"0")).join("");
}

// ─── Ghost / Outline Button ───────────────────────────────────────────────────
function GhostButton({ label, onPress, color, fullWidth, small }) {
  const [pressed, setPressed] = React.useState(false);
  const c = color || V.violet;
  return (
    <button onClick={onPress}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)} onMouseLeave={() => setPressed(false)}
      style={{
        background: pressed ? V.violetBg : "transparent",
        border: `2.5px solid ${V.border}`,
        borderRadius: small ? 12 : 16, padding: small ? "10px 18px" : "14px 22px",
        cursor: "pointer", color: c, fontWeight: 800,
        fontSize: small ? 13 : 15,
        width: fullWidth ? "100%" : "auto",
        display: "flex", alignItems: "center", justifyContent: "center",
        transition: "all 0.15s ease", fontFamily: "inherit"
      }}>{label}</button>
  );
}

// ─── Google Button ────────────────────────────────────────────────────────────
function GoogleButton({ onPress }) {
  const [pressed, setPressed] = React.useState(false);
  return (
    <button onClick={onPress}
      onMouseDown={() => setPressed(true)} onMouseUp={() => setPressed(false)} onMouseLeave={() => setPressed(false)}
      style={{
        background: "#fff", border: `2.5px solid ${V.border}`,
        borderRadius: 16, padding: "14px 24px", cursor: "pointer", width: "100%",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
        fontWeight: 700, fontSize: 15, color: V.text,
        transform: pressed ? "scale(0.97) translateY(1px)" : "scale(1)",
        transition: "all 0.15s ease",
        boxShadow: pressed ? "none" : "0 3px 0 #E0E7FF",
        fontFamily: "inherit"
      }}>
      <svg width="18" height="18" viewBox="0 0 48 48">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.35-8.16 2.35-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      </svg>
      Continue with Google
    </button>
  );
}

// ─── Input Field ──────────────────────────────────────────────────────────────
function InputField({ label, value, onChange, type = "text", placeholder, error, autoFocus }) {
  const [focused, setFocused] = React.useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
      {label && (
        <label style={{ fontSize: 12, fontWeight: 800, color: V.muted, letterSpacing: "0.08em", textTransform: "uppercase" }}>
          {label}
        </label>
      )}
      <input
        type={type} value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder} autoFocus={autoFocus}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
        style={{
          border: `2.5px solid ${error ? V.error : focused ? V.violet : V.border}`,
          borderRadius: 14, padding: "13px 16px", fontSize: 15,
          background: "#fff", color: V.text, outline: "none",
          transition: "border-color 0.2s ease", fontFamily: "inherit",
          boxShadow: focused ? `0 0 0 3px ${V.violetBg}` : "none"
        }}
      />
      {error && (
        <span style={{ fontSize: 12, color: V.error, fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill={V.error}><circle cx="12" cy="12" r="10"/><path d="M12 8v4m0 4h.01" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
          {error}
        </span>
      )}
    </div>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────
function Screen({ children, style }) {
  return (
    <div style={{
      position: "absolute", inset: 0,
      background: V.offWhite,
      display: "flex", flexDirection: "column",
      overflow: "hidden",
      ...style
    }}>{children}</div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
function Card({ children, style, onPress, noPad }) {
  const [pressed, setPressed] = React.useState(false);
  const clickable = !!onPress;
  return (
    <div
      onClick={onPress}
      onMouseDown={() => clickable && setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        background: V.card, borderRadius: 20,
        padding: noPad ? 0 : 20,
        cursor: clickable ? "pointer" : "default",
        transform: clickable && pressed ? "scale(0.975) translateY(2px)" : "scale(1)",
        transition: "all 0.16s cubic-bezier(0.34,1.2,0.64,1)",
        border: `2px solid ${V.border}`,
        boxShadow: clickable && !pressed ? "0 4px 0 #C7D2FE" : "none",
        ...style
      }}>{children}</div>
  );
}

// Subject emoji map
const SUBJECT_EMOJI = {
  "machine learning": "🤖", "ml": "🤖", "ai": "🤖",
  "spanish": "🇪🇸", "french": "🇫🇷", "german": "🇩🇪",
  "japanese": "🇯🇵", "portuguese": "🇵🇹", "chinese": "🇨🇳",
  "python": "🐍", "javascript": "💛", "programming": "💻",
  "math": "📐", "science": "🔬", "history": "📜",
  "music": "🎵", "art": "🎨", "cooking": "👨‍🍳",
  "business": "💼", "finance": "💰", "quantum": "⚛️",
};
function getCourseEmoji(title) {
  const t = title.toLowerCase();
  for (const [k, v] of Object.entries(SUBJECT_EMOJI)) {
    if (t.includes(k)) return v;
  }
  return "📚";
}

Object.assign(window, {
  V, shadeColor, Snackbar, XPBurst, Confetti, Hearts, StreakBadge,
  ProgressBar, BackButton, PrimaryButton, GhostButton,
  GoogleButton, InputField, Screen, Card, getCourseEmoji
});
