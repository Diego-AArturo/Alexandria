// Lesson screen — concept cards + 3 exercise types + reinforcement + completion.

const { useState: uS_L, useEffect: uE_L, useRef: uR_L, useMemo: uM_L } = React;

function ScreenLesson({ theme, onExit, onComplete }) {
  const t = theme;
  // Build the active queue. Wrong answers get pushed to the end as "refuerzo".
  const initialQueue = uM_L(() => ALEX_LESSON_STEPS.map((s, i) => ({ ...s, _key: `s${i}` })), []);
  const [queue, setQueue] = uS_L(initialQueue);
  const [pos, setPos] = uS_L(0);
  const [hearts] = uS_L(5); // visual only for "no lives" simplified gamification, but still nice
  const [xpGained, setXpGained] = uS_L(0);
  const [feedback, setFeedback] = uS_L(null); // { ok: bool, text }
  const [reinforceBanner, setReinforceBanner] = uS_L(false);
  const [done, setDone] = uS_L(false);
  const [answered, setAnswered] = uS_L(false);
  const [streakCorrect, setStreakCorrect] = uS_L(0);

  const total = queue.length;
  const step = queue[pos];

  function handleAnswer(isCorrect, currentStep) {
    if (answered) return;
    setAnswered(true);
    if (isCorrect) {
      setXpGained(x => x + 10);
      setStreakCorrect(s => s + 1);
      setFeedback({ ok: true, text: pickPraise() });
    } else {
      setStreakCorrect(0);
      setFeedback({ ok: false, text: 'Casi…', explain: currentStep.explain });
      // requeue at the end as a reinforcement
      setQueue(q => [...q, { ...currentStep, _isReinforce: true, _key: currentStep._key + 'r' + pos }]);
    }
  }

  function next() {
    setAnswered(false);
    const wasReinforce = !!queue[pos]._isReinforce;
    if (pos + 1 >= queue.length) {
      setDone(true);
      setFeedback(null);
      return;
    }
    // show banner if we're entering reinforcement section
    const nextStep = queue[pos + 1];
    if (nextStep._isReinforce && !wasReinforce && !reinforceBanner) {
      setReinforceBanner(true);
      setFeedback(null);
      return;
    }
    setFeedback(null);
    setPos(p => p + 1);
  }

  function dismissReinforce() {
    setReinforceBanner(false);
    setPos(p => p + 1);
  }

  function continueConcept() {
    next();
  }

  if (done) {
    return <LessonComplete theme={t} xpGained={xpGained} streak={ALEX_USER.streak + 1} onClose={onComplete}/>;
  }

  if (reinforceBanner) {
    return <ReinforceBanner theme={t} onContinue={dismissReinforce} count={queue.length - pos - 1}/>;
  }

  const progressValue = pos / total;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      {/* top bar: exit, progress, hearts */}
      <div style={{ padding: '60px 16px 12px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onExit} className="alex-tap" style={{
          width: 36, height: 36, borderRadius: 12, border: 'none', background: 'transparent', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <XIcon size={22} color={t.inkMute} stroke={3}/>
        </button>
        <div style={{ flex: 1 }}>
          <AlexProgress value={progressValue} theme={t} color={t.success} height={14}/>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <FlameIcon size={20} color={t.danger}/>
          <span style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 16, color: t.danger }}>{streakCorrect}</span>
        </div>
      </div>

      {/* step content */}
      <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '8px 20px 20px' }}>
        {step.type === 'concept' && <ConceptCard step={step} theme={t}/>}
        {step.type === 'multi' && <MultiChoice step={step} theme={t} answered={answered} onAnswer={(ok) => handleAnswer(ok, step)}/>}
        {step.type === 'tf' && <TrueFalse step={step} theme={t} answered={answered} onAnswer={(ok) => handleAnswer(ok, step)}/>}
        {step.type === 'fill' && <FillInBlank step={step} theme={t} answered={answered} onAnswer={(ok) => handleAnswer(ok, step)}/>}
      </div>

      {/* footer feedback / continue button */}
      <LessonFooter
        theme={t}
        step={step}
        answered={answered}
        feedback={feedback}
        onContinue={step.type === 'concept' ? continueConcept : next}
      />
    </div>
  );
}

const PRAISES = ['¡Genial!', '¡Perfecto!', '¡Bien hecho!', '¡Excelente!', '¡Eso es!'];
function pickPraise() { return PRAISES[Math.floor(Math.random() * PRAISES.length)]; }

// ──────────────────────────────────────────────────────────────
// CONCEPT CARD
// ──────────────────────────────────────────────────────────────
function ConceptCard({ step, theme }) {
  const t = theme;
  return (
    <div className="alex-fade-up">
      <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1.4, color: t.accent, textTransform: 'uppercase' }}>{step.eyebrow || 'Concepto'}</div>
      <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 30, fontWeight: 800, color: t.ink, letterSpacing: -1, marginTop: 6, lineHeight: 1.05 }}>{step.title}</div>
      <div style={{ marginTop: 18 }}>
        <AlexPlaceholder theme={t} label={step.image} height={150} color={t.primarySoft}/>
      </div>
      <div style={{ marginTop: 18, fontFamily: ALEX_FONT_UI, fontSize: 17, color: t.ink, fontWeight: 500, lineHeight: 1.5 }}>{step.body}</div>
      {step.fact && (
        <div style={{
          marginTop: 18, padding: 16,
          background: t.accentSoft, borderRadius: 18,
          border: `2px solid ${t.accent}`,
          display: 'flex', gap: 12, alignItems: 'flex-start',
        }}>
          <SparkleIcon size={22} color={t.accentInk}/>
          <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, fontWeight: 600, color: t.accentInk, lineHeight: 1.4 }}>
            <span style={{ fontWeight: 800, textTransform: 'uppercase', fontSize: 11, letterSpacing: 0.8 }}>Sabías que…</span>
            <div style={{ marginTop: 4, fontSize: 15 }}>{step.fact}</div>
          </div>
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// MULTIPLE CHOICE
// ──────────────────────────────────────────────────────────────
function MultiChoice({ step, theme, answered, onAnswer }) {
  const t = theme;
  const [picked, setPicked] = uS_L(null);
  uE_L(() => { setPicked(null); }, [step._key]);

  function pick(o) {
    if (answered) return;
    setPicked(o.id);
  }
  function check() {
    if (picked == null) return;
    const o = step.options.find(o => o.id === picked);
    onAnswer(o.correct);
  }

  return (
    <div className="alex-fade-up">
      <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1.4, color: t.accent, textTransform: 'uppercase' }}>Selecciona la respuesta</div>
      <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 26, fontWeight: 800, color: t.ink, letterSpacing: -0.6, marginTop: 6, lineHeight: 1.15 }}>{step.prompt}</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 22 }}>
        {step.options.map(o => {
          const isPicked = picked === o.id;
          let bg = t.bgRaised, border = t.border, edge = t.border, color = t.ink;
          if (answered) {
            if (o.correct) { bg = t.successSoft; border = t.success; edge = t.success; color = t.successInk; }
            else if (isPicked) { bg = t.dangerSoft; border = t.danger; edge = t.danger; color = t.dangerInk; }
          } else if (isPicked) {
            bg = t.primarySoft; border = t.primary; edge = t.primary;
          }
          return (
            <button key={o.id} onClick={() => pick(o)} className="alex-tap"
              style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '16px 18px', width: '100%', textAlign: 'left',
                border: `2.5px solid ${border}`, background: bg,
                boxShadow: `0 4px 0 0 ${edge}`,
                borderRadius: 18, cursor: answered ? 'default' : 'pointer',
                fontFamily: ALEX_FONT_UI, fontSize: 17, fontWeight: 700, color,
              }}>
              <div style={{
                width: 30, height: 30, flexShrink: 0,
                borderRadius: 10, border: `2.5px solid ${border}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, color, background: 'transparent',
                fontSize: 14,
              }}>{o.id.toUpperCase()}</div>
              <span style={{ flex: 1 }}>{o.label}</span>
              {answered && o.correct && <CheckIcon size={22} color={t.success} stroke={3.5}/>}
              {answered && !o.correct && isPicked && <XIcon size={22} color={t.danger} stroke={3.5}/>}
            </button>
          );
        })}
      </div>

      {!answered && picked != null && (
        <div style={{ marginTop: 18 }}>
          <AlexButton theme={t} full onClick={check}>Comprobar</AlexButton>
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// TRUE / FALSE
// ──────────────────────────────────────────────────────────────
function TrueFalse({ step, theme, answered, onAnswer }) {
  const t = theme;
  const [picked, setPicked] = uS_L(null);
  uE_L(() => { setPicked(null); }, [step._key]);

  function pick(v) {
    if (answered) return;
    setPicked(v);
    setTimeout(() => onAnswer(v === step.answer), 250);
  }

  const chip = (label, val, color, edge, ink) => {
    const isPicked = picked === val;
    let bg = color, ed = edge, c = ink;
    if (answered) {
      const correct = step.answer === val;
      if (correct) { bg = t.success; ed = t.successDark; c = '#fff'; }
      else if (isPicked) { bg = t.danger; ed = t.dangerDark; c = '#fff'; }
      else { bg = t.bgSunken; ed = t.border; c = t.inkMute; }
    } else if (isPicked) {
      bg = t.primary; ed = t.primaryDark; c = '#fff';
    }
    return (
      <button key={label} onClick={() => pick(val)} className="alex-tap"
        style={{
          flex: 1, padding: '32px 12px',
          background: bg, color: c, border: 'none',
          borderRadius: 26, boxShadow: `0 6px 0 0 ${ed}`,
          fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 28, letterSpacing: -0.4,
          cursor: answered ? 'default' : 'pointer',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
        }}>
        <div style={{
          width: 56, height: 56, borderRadius: '50%',
          background: 'rgba(255,255,255,0.18)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {val ? <CheckIcon size={32} color={c} stroke={3.5}/> : <XIcon size={30} color={c} stroke={3.5}/>}
        </div>
        {label}
      </button>
    );
  };

  return (
    <div className="alex-fade-up">
      <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1.4, color: t.accent, textTransform: 'uppercase' }}>Verdadero o falso</div>
      <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 24, fontWeight: 800, color: t.ink, letterSpacing: -0.5, marginTop: 6, lineHeight: 1.2 }}>{step.prompt}</div>
      <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
        {chip('Verdadero', true, t.successSoft, t.success, t.successInk)}
        {chip('Falso', false, t.dangerSoft, t.danger, t.dangerInk)}
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// FILL-IN-THE-BLANK — chips fly into the blanks
// ──────────────────────────────────────────────────────────────
function FillInBlank({ step, theme, answered, onAnswer }) {
  const t = theme;
  // assignments[blankIdx] = wordIdx (in bank) | null
  const [assignments, setAssignments] = uS_L([]);
  const [shake, setShake] = uS_L(false);
  uE_L(() => {
    setAssignments(step.blanks.map(() => null));
    setShake(false);
  }, [step._key]);

  // build sentence with blanks
  let blankCounter = -1;
  const sentence = step.sentence;

  const isWordUsed = (wordIdx) => assignments.includes(wordIdx);

  function tapWord(wordIdx) {
    if (answered) return;
    if (isWordUsed(wordIdx)) return;
    // fill the next empty blank
    const nextBlank = assignments.findIndex(a => a == null);
    if (nextBlank === -1) return;
    const next = assignments.slice();
    next[nextBlank] = wordIdx;
    setAssignments(next);
  }

  function clearBlank(blankIdx) {
    if (answered) return;
    if (assignments[blankIdx] == null) return;
    const next = assignments.slice();
    next[blankIdx] = null;
    setAssignments(next);
  }

  function check() {
    const ok = step.blanks.every((b, i) => {
      const wIdx = assignments[i];
      return wIdx != null && step.bank[wIdx] === b.correct;
    });
    if (!ok) {
      setShake(true);
      setTimeout(() => setShake(false), 460);
    }
    onAnswer(ok);
  }

  const allFilled = assignments.every(a => a != null);
  const accent = t.accent;

  return (
    <div className="alex-fade-up">
      <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1.4, color: accent, textTransform: 'uppercase' }}>Completa los espacios</div>
      <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 22, fontWeight: 800, color: t.ink, letterSpacing: -0.4, marginTop: 6, lineHeight: 1.2 }}>{step.prompt}</div>

      {/* Sentence area */}
      <div className={shake ? 'alex-shake' : ''} style={{
        marginTop: 24, padding: 22,
        background: t.bgRaised, border: `2.5px solid ${t.border}`,
        borderRadius: 22,
        boxShadow: `0 4px 0 0 ${t.border}`,
        display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8,
        fontFamily: ALEX_FONT_DISPLAY, fontWeight: 700, fontSize: 22, color: t.ink, lineHeight: 1.5, letterSpacing: -0.3,
      }}>
        {sentence.map((part, i) => {
          if (part === null) {
            blankCounter += 1;
            const bIdx = blankCounter;
            const wordIdx = assignments[bIdx];
            const filled = wordIdx != null;
            const correctWord = step.blanks[bIdx].correct;
            const usedWord = filled ? step.bank[wordIdx] : null;
            const isCorrect = answered && filled && usedWord === correctWord;
            const isWrong = answered && filled && usedWord !== correctWord;

            const blankBg = isCorrect ? t.successSoft : isWrong ? t.dangerSoft : t.primarySoft;
            const blankEdge = isCorrect ? t.success : isWrong ? t.danger : t.primary;
            const blankColor = isCorrect ? t.successInk : isWrong ? t.dangerInk : t.primary;

            return (
              <span key={i} onClick={() => clearBlank(bIdx)}
                className={filled ? 'alex-pop' : ''}
                style={{
                  display: 'inline-block',
                  minWidth: 88,
                  padding: '6px 14px',
                  background: filled ? blankBg : 'transparent',
                  border: `2.5px ${filled ? 'solid' : 'dashed'} ${filled ? blankEdge : t.borderStrong}`,
                  borderBottom: !filled ? `3px solid ${t.borderStrong}` : `2.5px solid ${blankEdge}`,
                  borderRadius: 12,
                  textAlign: 'center',
                  color: filled ? blankColor : 'transparent',
                  cursor: filled && !answered ? 'pointer' : 'default',
                  transition: 'all 180ms ease',
                  boxShadow: filled ? `0 3px 0 0 ${blankEdge}` : 'none',
                  fontWeight: 800,
                }}>
                {filled ? usedWord : '\u00A0\u00A0\u00A0\u00A0\u00A0'}
              </span>
            );
          }
          return <span key={i}>{part}</span>;
        })}
      </div>

      {/* Word bank */}
      <div style={{
        marginTop: 18, display: 'flex', flexWrap: 'wrap', gap: 10,
        justifyContent: 'center',
      }}>
        {step.bank.map((w, idx) => {
          const used = isWordUsed(idx);
          return (
            <button key={idx} onClick={() => tapWord(idx)} className="alex-tap"
              disabled={used || answered}
              style={{
                padding: '12px 18px',
                background: used ? t.bgSunken : t.bgRaised,
                color: used ? 'transparent' : t.ink,
                border: `2.5px solid ${used ? t.border : t.borderStrong}`,
                borderRadius: 14,
                boxShadow: used ? 'none' : `0 4px 0 0 ${t.borderStrong}`,
                fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 17, letterSpacing: -0.2,
                cursor: used ? 'default' : 'pointer',
                opacity: used ? 0.5 : 1,
                transition: 'opacity 200ms',
                visibility: used ? 'hidden' : 'visible',
              }}>
              {w}
            </button>
          );
        })}
      </div>

      {!answered && allFilled && (
        <div style={{ marginTop: 16 }}>
          <AlexButton theme={t} full onClick={check}>Comprobar</AlexButton>
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Footer / feedback
// ──────────────────────────────────────────────────────────────
function LessonFooter({ theme, step, answered, feedback, onContinue }) {
  const t = theme;
  if (step.type === 'concept') {
    return (
      <div style={{ padding: '12px 20px 24px', background: t.bg, borderTop: `1px solid ${t.border}` }}>
        <AlexButton theme={t} full onClick={onContinue}>Continuar</AlexButton>
      </div>
    );
  }
  if (!answered) {
    return <div style={{ height: 24 }}/>;
  }
  const ok = feedback?.ok;
  return (
    <div className="alex-fly" style={{
      background: ok ? t.successSoft : t.dangerSoft,
      borderTop: `2px solid ${ok ? t.success : t.danger}`,
      padding: '16px 20px 24px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 48, height: 48, borderRadius: '50%',
          background: ok ? t.success : t.danger,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          {ok ? <CheckIcon size={28} color="#fff" stroke={3.5}/> : <XIcon size={28} color="#fff" stroke={3.5}/>}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 22, letterSpacing: -0.4, color: ok ? t.successInk : t.dangerInk }}>
            {ok ? feedback.text : 'Casi…'}
          </div>
          {!ok && step.explain && (
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 13, fontWeight: 600, color: t.dangerInk, lineHeight: 1.35, marginTop: 2 }}>{step.explain}</div>
          )}
          {ok && step.explain && (
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 13, fontWeight: 600, color: t.successInk, lineHeight: 1.35, marginTop: 2 }}>{step.explain}</div>
          )}
        </div>
      </div>
      <div style={{ marginTop: 12 }}>
        <AlexButton theme={t} variant={ok ? 'success' : 'danger'} full onClick={onContinue}>Continuar</AlexButton>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Reinforcement banner
// ──────────────────────────────────────────────────────────────
function ReinforceBanner({ theme, onContinue, count }) {
  const t = theme;
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg, padding: '60px 24px 24px' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div className="alex-pop">
          <div style={{
            width: 110, height: 110, borderRadius: '50%', background: t.gold,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 6px 0 0 ${t.goldDark}`,
          }}>
            <BoltIcon size={54} color="#fff"/>
          </div>
        </div>
        <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 32, fontWeight: 800, color: t.ink, letterSpacing: -1, marginTop: 24, lineHeight: 1.05 }}>Refuerzo</div>
        <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 16, color: t.inkSoft, fontWeight: 600, marginTop: 6, maxWidth: 280 }}>
          Vamos a repasar las {count} {count === 1 ? 'pregunta' : 'preguntas'} que fallaste para que se queden contigo.
        </div>
      </div>
      <AlexButton theme={t} full onClick={onContinue}>Vamos</AlexButton>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Lesson complete — celebration screen
// ──────────────────────────────────────────────────────────────
function LessonComplete({ theme, xpGained, streak, onClose }) {
  const t = theme;
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      {/* confetti area */}
      <div style={{ position: 'relative', height: 220, overflow: 'hidden', flexShrink: 0 }}>
        {Array.from({ length: 24 }).map((_, i) => {
          const colors = [t.primary, t.accent, t.gold, t.success, t.danger];
          const c = colors[i % colors.length];
          const left = (i * 17) % 100;
          const delay = (i % 6) * 0.15;
          const dur = 2.2 + (i % 4) * 0.3;
          return (
            <div key={i} style={{
              position: 'absolute', left: `${left}%`, top: -12,
              width: 10, height: 14, background: c, borderRadius: 2,
              animation: `alex-confetti ${dur}s linear ${delay}s infinite`,
            }}/>
          );
        })}
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
          paddingBottom: 12,
        }}>
          <div className="alex-pop">
            <AlexMascot size={140} mood="celebrating" theme={t}/>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, padding: '8px 24px 24px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 36, fontWeight: 800, color: t.ink, letterSpacing: -1.2, textAlign: 'center', lineHeight: 1.05 }}>
          ¡Lección completa!
        </div>
        <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 16, color: t.inkSoft, fontWeight: 600, textAlign: 'center', marginTop: 6 }}>
          Miguel Ángel ahora vive en tu cabeza.
        </div>

        <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
          <RewardCard theme={t} icon={<BoltIcon size={26} color={t.gold}/>}
            value={`+${xpGained}`} label="XP ganado" color={t.goldSoft} edge={t.gold} ink={t.goldInk}/>
          <RewardCard theme={t} icon={<FlameIcon size={26} color={t.danger}/>}
            value={streak} label="días seguidos" color={t.dangerSoft} edge={t.danger} ink={t.dangerInk}/>
        </div>

        <div style={{
          marginTop: 16, padding: 16,
          background: t.bgRaised, border: `2px solid ${t.border}`, borderRadius: 18,
          boxShadow: `0 3px 0 0 ${t.border}`,
        }}>
          <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, color: t.inkMute, textTransform: 'uppercase', letterSpacing: 1 }}>Precisión</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
            <span style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 32, color: t.success, letterSpacing: -1 }}>83%</span>
            <span style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, color: t.inkSoft, fontWeight: 700 }}>· tres veces casi perfecto</span>
          </div>
          <div style={{ marginTop: 8 }}>
            <AlexProgress value={0.83} theme={t} color={t.success} height={12}/>
          </div>
        </div>

        <div style={{ marginTop: 'auto', paddingTop: 22 }}>
          <AlexButton theme={t} full onClick={onClose}>Continuar</AlexButton>
        </div>
      </div>
    </div>
  );
}

function RewardCard({ theme, icon, value, label, color, edge, ink }) {
  const t = theme;
  return (
    <div style={{
      flex: 1, padding: 16, borderRadius: 18,
      background: color, border: `2px solid ${edge}`,
      boxShadow: `0 4px 0 0 ${edge}`,
    }}>
      <div style={{
        width: 38, height: 38, borderRadius: 12, background: t.bgRaised,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{icon}</div>
      <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 28, color: ink, letterSpacing: -0.6, marginTop: 6 }}>{value}</div>
      <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 12, color: ink, opacity: 0.8, textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
    </div>
  );
}

Object.assign(window, {
  ScreenLesson,
});
