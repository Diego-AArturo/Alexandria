// Atomic UI components for Alexandria.

const { useState, useEffect, useRef, useMemo } = React;

// ──────────────────────────────────────────────────────────────
// Mascot — abstract geometric "curious eye"
// A pill with two circular eyes + a teal arc for a mouth.
// Reacts via `mood`: happy | thinking | celebrating | sleeping
// ──────────────────────────────────────────────────────────────
function AlexMascot({ size = 96, mood = 'happy', theme }) {
  const t = theme;
  const w = size;
  const h = size * 1.05;
  const blink = mood === 'sleeping';
  const eyeY = mood === 'thinking' ? 0.46 : 0.50;
  const pupilOff = mood === 'thinking' ? -size * 0.03 : 0;
  const mouth = (() => {
    if (mood === 'celebrating') return `M ${w*0.30} ${h*0.70} Q ${w*0.50} ${h*0.86}, ${w*0.70} ${h*0.70}`;
    if (mood === 'thinking')    return `M ${w*0.34} ${h*0.74} Q ${w*0.50} ${h*0.74}, ${w*0.66} ${h*0.74}`;
    if (mood === 'sleeping')    return `M ${w*0.36} ${h*0.74} Q ${w*0.50} ${h*0.78}, ${w*0.64} ${h*0.74}`;
    return `M ${w*0.34} ${h*0.72} Q ${w*0.50} ${h*0.80}, ${w*0.66} ${h*0.72}`;
  })();
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {/* head — capsule */}
      <rect x={w*0.10} y={h*0.10} width={w*0.80} height={h*0.78}
            rx={w*0.30} ry={w*0.30}
            fill={t.primary}/>
      {/* highlight */}
      <ellipse cx={w*0.32} cy={h*0.28} rx={w*0.08} ry={h*0.04} fill={t.primaryInk} opacity="0.25" />
      {/* tuft / antenna */}
      <circle cx={w*0.50} cy={h*0.06} r={w*0.05} fill={t.accent} />
      <line x1={w*0.50} y1={h*0.10} x2={w*0.50} y2={h*0.18}
            stroke={t.accent} strokeWidth={w*0.025} strokeLinecap="round" />

      {/* eyes */}
      {blink ? (
        <>
          <line x1={w*0.30} y1={h*eyeY} x2={w*0.42} y2={h*eyeY} stroke={t.primaryInk} strokeWidth={w*0.04} strokeLinecap="round"/>
          <line x1={w*0.58} y1={h*eyeY} x2={w*0.70} y2={h*eyeY} stroke={t.primaryInk} strokeWidth={w*0.04} strokeLinecap="round"/>
        </>
      ) : (
        <>
          <circle cx={w*0.36} cy={h*eyeY} r={w*0.08} fill={t.primaryInk} />
          <circle cx={w*0.64} cy={h*eyeY} r={w*0.08} fill={t.primaryInk} />
          <circle cx={w*0.36 + pupilOff} cy={h*eyeY - h*0.01} r={w*0.025} fill={t.bg} />
          <circle cx={w*0.64 + pupilOff} cy={h*eyeY - h*0.01} r={w*0.025} fill={t.bg} />
        </>
      )}

      {/* mouth */}
      <path d={mouth} stroke={t.accent} strokeWidth={w*0.05} fill="none" strokeLinecap="round" />

      {/* cheek dots */}
      {(mood === 'celebrating' || mood === 'happy') && (
        <>
          <circle cx={w*0.20} cy={h*0.62} r={w*0.04} fill={t.accent} opacity="0.6" />
          <circle cx={w*0.80} cy={h*0.62} r={w*0.04} fill={t.accent} opacity="0.6" />
        </>
      )}
    </svg>
  );
}

// ──────────────────────────────────────────────────────────────
// Chunky tap button — 3D bottom edge ("Duolingo-style" but original)
// ──────────────────────────────────────────────────────────────
function AlexButton({
  children, onClick, theme, variant = 'primary',
  full = false, size = 'lg', disabled = false, style = {},
}) {
  const t = theme;
  const palette = (() => {
    if (variant === 'primary') return { bg: t.primary, edge: t.primaryDark, ink: '#fff' };
    if (variant === 'accent')  return { bg: t.accent,  edge: t.accentDark,  ink: t.accentInk };
    if (variant === 'success') return { bg: t.success, edge: t.successDark, ink: '#fff' };
    if (variant === 'danger')  return { bg: t.danger,  edge: t.dangerDark,  ink: '#fff' };
    if (variant === 'ghost')   return { bg: 'transparent', edge: 'transparent', ink: t.inkSoft };
    if (variant === 'outline') return { bg: t.bgRaised, edge: t.borderStrong, ink: t.ink };
    return { bg: t.primary, edge: t.primaryDark, ink: '#fff' };
  })();
  const sizes = {
    lg: { pad: '18px 22px', font: 18, radius: 18, edge: 5 },
    md: { pad: '12px 18px', font: 16, radius: 14, edge: 4 },
    sm: { pad: '8px 14px',  font: 14, radius: 12, edge: 3 },
  };
  const s = sizes[size];
  const [pressed, setPressed] = useState(false);
  const release = () => setPressed(false);
  return (
    <button
      onClick={disabled ? undefined : onClick}
      onPointerDown={() => !disabled && setPressed(true)}
      onPointerUp={release}
      onPointerLeave={release}
      onPointerCancel={release}
      disabled={disabled}
      className="alex-tap"
      style={{
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center', justifyContent: 'center', gap: 8,
        padding: s.pad,
        background: palette.bg,
        color: palette.ink,
        border: variant === 'outline' ? `2px solid ${palette.edge}` : 'none',
        borderRadius: s.radius,
        fontFamily: ALEX_FONT_UI,
        fontWeight: 800,
        fontSize: s.font,
        letterSpacing: 0.3,
        textTransform: 'uppercase',
        boxShadow: variant === 'ghost' || variant === 'outline'
          ? 'none'
          : `0 ${pressed ? 1 : s.edge}px 0 0 ${palette.edge}`,
        transform: pressed ? `translateY(${s.edge - 1}px)` : 'translateY(0)',
        transition: 'transform 80ms ease, box-shadow 80ms ease',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        width: full ? '100%' : undefined,
        ...style,
      }}>
      {children}
    </button>
  );
}

// ──────────────────────────────────────────────────────────────
// Progress bar — chunky, animated
// ──────────────────────────────────────────────────────────────
function AlexProgress({ value, theme, color, height = 14 }) {
  const t = theme;
  const fill = color || t.accent;
  const v = Math.max(0, Math.min(1, value));
  return (
    <div style={{
      height, width: '100%',
      background: t.bgSunken,
      border: `2px solid ${t.border}`,
      borderRadius: height,
      overflow: 'hidden',
      position: 'relative',
    }}>
      <div style={{
        height: '100%', width: `${v * 100}%`,
        background: fill,
        borderRadius: height,
        transition: 'width 0.5s cubic-bezier(.2,.7,.3,1)',
        position: 'relative',
      }}>
        {v > 0.05 && (
          <div style={{
            position: 'absolute', top: 2, left: 4, right: 4,
            height: Math.max(2, height/4),
            borderRadius: height,
            background: 'rgba(255,255,255,0.4)',
          }} />
        )}
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// XP & Streak chips
// ──────────────────────────────────────────────────────────────
function AlexChip({ icon, label, color, theme, big = false }) {
  const t = theme;
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: big ? 8 : 6,
      padding: big ? '10px 16px' : '6px 12px',
      borderRadius: 999,
      background: t.bgRaised,
      border: `2px solid ${t.border}`,
      fontFamily: ALEX_FONT_UI,
      fontWeight: 800,
      fontSize: big ? 18 : 15,
      color: color || t.ink,
      letterSpacing: 0.2,
    }}>
      <span style={{ fontSize: big ? 22 : 18, lineHeight: 1 }}>{icon}</span>
      {label}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// "Streak flame" SVG — abstract, no emoji
// ──────────────────────────────────────────────────────────────
function FlameIcon({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 2.5 C 9 6, 6 7.5, 6 13 C 6 17.5, 9 21, 12 21 C 15 21, 18 17.5, 18 13 C 18 9.5, 16 8, 14.5 6 C 13.5 4.5, 12.8 3.5, 12 2.5 Z"
            fill={color}/>
      <path d="M12 9.5 C 10.5 11.5, 9.5 13, 9.5 15.5 C 9.5 18, 10.8 19.5, 12 19.5 C 13.2 19.5, 14.5 18, 14.5 15.5 C 14.5 14, 13.8 13, 13 12 C 12.5 11, 12.2 10.3, 12 9.5 Z"
            fill="white" opacity="0.45"/>
    </svg>
  );
}
function BoltIcon({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M13 2 L4 14 H10 L8 22 L18 9 H12 L13 2 Z" fill={color} stroke={color} strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  );
}
function CheckIcon({ size = 22, color = '#fff', stroke = 3 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 12 L10 17 L19 7" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function XIcon({ size = 22, color = '#fff', stroke = 3 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M6 6 L18 18 M18 6 L6 18" stroke={color} strokeWidth={stroke} strokeLinecap="round"/>
    </svg>
  );
}
function LockIcon({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="5" y="11" width="14" height="10" rx="2.5" fill={color}/>
      <path d="M8 11 V 8 a4 4 0 0 1 8 0 V 11" stroke={color} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
    </svg>
  );
}
function StarIcon({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3 L14.6 9.2 L21.5 9.8 L16.2 14.2 L17.9 21 L12 17.3 L6.1 21 L7.8 14.2 L2.5 9.8 L9.4 9.2 Z"
            fill={color}/>
    </svg>
  );
}
function PlusIcon({ size = 22, color, stroke = 3 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 4 V 20 M4 12 H 20" stroke={color} strokeWidth={stroke} strokeLinecap="round"/>
    </svg>
  );
}
function ChevronIcon({ dir = 'right', size = 18, color, stroke = 2.6 }) {
  const map = { right: 'M9 6 L15 12 L9 18', left: 'M15 6 L9 12 L15 18', down: 'M6 9 L12 15 L18 9', up: 'M6 15 L12 9 L18 15' };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d={map[dir]} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function SparkleIcon({ size = 22, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3 L13.5 9 L19 10.5 L13.5 12 L12 18 L10.5 12 L5 10.5 L10.5 9 Z" fill={color}/>
      <path d="M19 16 L19.7 18.3 L22 19 L19.7 19.7 L19 22 L18.3 19.7 L16 19 L18.3 18.3 Z" fill={color}/>
    </svg>
  );
}

// ──────────────────────────────────────────────────────────────
// "Tap card" — reusable big rounded card with chunky 3D edge
// ──────────────────────────────────────────────────────────────
function AlexCard({ children, theme, color, edge, onClick, style = {}, padding = 18, radius = 22, edgeSize = 5, animateTap = true }) {
  const t = theme;
  const bg = color || t.bgRaised;
  const ed = edge || t.border;
  const [pressed, setPressed] = useState(false);
  const release = () => setPressed(false);
  return (
    <div
      onClick={onClick}
      onPointerDown={() => onClick && setPressed(true)}
      onPointerUp={release}
      onPointerLeave={release}
      onPointerCancel={release}
      style={{
        background: bg,
        border: `2px solid ${ed}`,
        borderRadius: radius,
        padding,
        boxShadow: animateTap ? `0 ${pressed ? 1 : edgeSize}px 0 0 ${ed}` : 'none',
        transform: pressed ? `translateY(${edgeSize - 1}px)` : 'translateY(0)',
        transition: 'transform 80ms ease, box-shadow 80ms ease',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}>
      {children}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// In-app top header (replaces iOS NavBar): back/title/right
// ──────────────────────────────────────────────────────────────
function AlexHeader({ left, title, right, theme, transparent = false }) {
  const t = theme;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 16px',
      background: transparent ? 'transparent' : t.bg,
      minHeight: 52,
    }}>
      <div style={{ width: 44, display: 'flex', justifyContent: 'flex-start' }}>{left}</div>
      <div style={{
        flex: 1, textAlign: 'center',
        fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800,
        fontSize: 18, color: t.ink, letterSpacing: -0.3,
      }}>{title}</div>
      <div style={{ width: 44, display: 'flex', justifyContent: 'flex-end' }}>{right}</div>
    </div>
  );
}

function AlexIconButton({ children, onClick, theme, style = {} }) {
  const t = theme;
  return (
    <button
      onClick={onClick}
      className="alex-tap"
      style={{
        width: 44, height: 44, borderRadius: 14,
        background: t.bgRaised,
        border: `2px solid ${t.border}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer',
        ...style,
      }}>
      {children}
    </button>
  );
}

// ──────────────────────────────────────────────────────────────
// Image placeholder (subtle stripes + monospace label)
// ──────────────────────────────────────────────────────────────
function AlexPlaceholder({ label = 'image', theme, height = 120, color, radius = 18, style = {} }) {
  const t = theme;
  const c = color || t.primarySoft;
  const ink = t.inkMute;
  return (
    <div style={{
      width: '100%', height, borderRadius: radius,
      background: `repeating-linear-gradient(135deg, ${c} 0 8px, ${t.bgSunken} 8px 16px)`,
      border: `2px dashed ${t.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: ALEX_FONT_MONO, fontSize: 12, color: ink,
      ...style,
    }}>
      {label}
    </div>
  );
}

Object.assign(window, {
  AlexMascot, AlexButton, AlexProgress, AlexChip,
  FlameIcon, BoltIcon, CheckIcon, XIcon, LockIcon, StarIcon, PlusIcon, ChevronIcon, SparkleIcon,
  AlexCard, AlexHeader, AlexIconButton, AlexPlaceholder,
});
