// Theme tokens for Alexandria.
// Uses oklch for the palette so light/dark stay harmonic.

const ALEX_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": false
}/*EDITMODE-END*/;

const ALEX_LIGHT = {
  bg:        'oklch(0.985 0.005 90)',         // off-white
  bgRaised:  'oklch(1 0 0)',                   // pure white card
  bgSunken:  'oklch(0.96 0.008 285)',          // soft violet-tinged
  ink:       'oklch(0.18 0.02 285)',           // near-black, violet tint
  inkSoft:   'oklch(0.42 0.02 285)',
  inkMute:   'oklch(0.62 0.015 285)',
  border:    'oklch(0.92 0.01 285)',
  borderStrong: 'oklch(0.85 0.015 285)',

  primary:   'oklch(0.42 0.18 285)',           // deep violet
  primaryInk:'oklch(0.985 0.005 285)',
  primarySoft:'oklch(0.93 0.05 285)',
  primaryDark:'oklch(0.32 0.16 285)',          // pressed/shadow

  accent:    'oklch(0.72 0.13 195)',           // teal
  accentInk: 'oklch(0.18 0.04 195)',
  accentSoft:'oklch(0.93 0.05 195)',
  accentDark:'oklch(0.58 0.13 195)',

  success:   'oklch(0.7 0.16 150)',
  successSoft:'oklch(0.93 0.06 150)',
  successDark:'oklch(0.55 0.15 150)',
  successInk:'oklch(0.22 0.08 150)',

  danger:    'oklch(0.65 0.20 25)',
  dangerSoft:'oklch(0.94 0.05 25)',
  dangerDark:'oklch(0.5 0.18 25)',
  dangerInk: 'oklch(0.3 0.1 25)',

  gold:      'oklch(0.78 0.15 75)',
  goldSoft:  'oklch(0.94 0.07 75)',
  goldDark:  'oklch(0.62 0.14 75)',
  goldInk:   'oklch(0.32 0.08 75)',
};

const ALEX_DARK = {
  bg:        'oklch(0.13 0.015 285)',
  bgRaised:  'oklch(0.20 0.02 285)',
  bgSunken:  'oklch(0.10 0.012 285)',
  ink:       'oklch(0.97 0.005 90)',
  inkSoft:   'oklch(0.78 0.01 285)',
  inkMute:   'oklch(0.55 0.015 285)',
  border:    'oklch(0.28 0.02 285)',
  borderStrong: 'oklch(0.36 0.025 285)',

  primary:   'oklch(0.68 0.18 285)',
  primaryInk:'oklch(0.12 0.02 285)',
  primarySoft:'oklch(0.28 0.08 285)',
  primaryDark:'oklch(0.52 0.18 285)',

  accent:    'oklch(0.78 0.13 195)',
  accentInk: 'oklch(0.12 0.04 195)',
  accentSoft:'oklch(0.26 0.06 195)',
  accentDark:'oklch(0.62 0.13 195)',

  success:   'oklch(0.78 0.16 150)',
  successSoft:'oklch(0.26 0.07 150)',
  successDark:'oklch(0.6 0.15 150)',
  successInk:'oklch(0.95 0.04 150)',

  danger:    'oklch(0.72 0.20 25)',
  dangerSoft:'oklch(0.28 0.08 25)',
  dangerDark:'oklch(0.55 0.18 25)',
  dangerInk: 'oklch(0.95 0.05 25)',

  gold:      'oklch(0.84 0.15 75)',
  goldSoft:  'oklch(0.28 0.08 75)',
  goldDark:  'oklch(0.68 0.14 75)',
  goldInk:   'oklch(0.95 0.06 75)',
};

const ALEX_FONT_DISPLAY = "'Bricolage Grotesque', system-ui, sans-serif";
const ALEX_FONT_UI = "'Nunito', system-ui, sans-serif";
const ALEX_FONT_MONO = "'JetBrains Mono', ui-monospace, monospace";

function useAlexTheme(dark) {
  return dark ? ALEX_DARK : ALEX_LIGHT;
}

Object.assign(window, {
  ALEX_DEFAULTS, ALEX_LIGHT, ALEX_DARK, useAlexTheme,
  ALEX_FONT_DISPLAY, ALEX_FONT_UI, ALEX_FONT_MONO,
});
