// Screen components for Alexandria.
// Auth, Courses, Unit Map, AI Create, Profile.

const { useState: uS_S, useEffect: uE_S, useRef: uR_S } = React;

// ──────────────────────────────────────────────────────────────
// SCREEN: Auth (login + signup toggle)
// ──────────────────────────────────────────────────────────────
function ScreenAuth({ theme, onComplete }) {
  const t = theme;
  const [mode, setMode] = uS_S('login'); // 'login' | 'signup'
  const [email, setEmail] = uS_S('sofia@alexandria.app');
  const [password, setPassword] = uS_S('••••••••');
  const [name, setName] = uS_S('Sofía');

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg, padding: '60px 24px 24px' }}>
      {/* hero */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 12 }}>
        <div className="alex-fly">
          <AlexMascot size={108} mood="happy" theme={t} />
        </div>
        <div style={{
          fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 44,
          color: t.ink, marginTop: 16, letterSpacing: -1.4,
        }}>Alexandria</div>
        <div style={{
          fontFamily: ALEX_FONT_UI, fontSize: 16, color: t.inkSoft,
          marginTop: 4, fontWeight: 600, textAlign: 'center', maxWidth: 280,
        }}>Aprende lo que sea, una pieza pequeña a la vez.</div>
      </div>

      {/* segmented control */}
      <div style={{
        marginTop: 36,
        display: 'flex', padding: 4, borderRadius: 16,
        background: t.bgSunken, border: `2px solid ${t.border}`,
      }}>
        {['login', 'signup'].map(m => (
          <button key={m} onClick={() => setMode(m)} className="alex-tap"
            style={{
              flex: 1, padding: '12px 0', borderRadius: 12,
              border: 'none',
              background: mode === m ? t.bgRaised : 'transparent',
              boxShadow: mode === m ? `0 2px 0 0 ${t.border}` : 'none',
              fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 14,
              letterSpacing: 0.4, textTransform: 'uppercase',
              color: mode === m ? t.primary : t.inkMute, cursor: 'pointer',
            }}>
            {m === 'login' ? 'Iniciar Sesión' : 'Registrarse'}
          </button>
        ))}
      </div>

      {/* form */}
      <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {mode === 'signup' && (
          <AuthInput theme={t} label="Nombre" value={name} onChange={setName} />
        )}
        <AuthInput theme={t} label="Email" value={email} onChange={setEmail} />
        <AuthInput theme={t} label="Contraseña" value={password} onChange={setPassword} secure />
        {mode === 'login' && (
          <div style={{ textAlign: 'right' }}>
            <span style={{ fontFamily: ALEX_FONT_UI, fontSize: 13, fontWeight: 700, color: t.primary, cursor: 'pointer' }}>
              ¿Olvidaste tu contraseña?
            </span>
          </div>
        )}
      </div>

      <div style={{ marginTop: 'auto' }}>
        <AlexButton theme={t} full onClick={onComplete}>
          {mode === 'login' ? 'Entrar' : 'Crear cuenta'}
        </AlexButton>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '18px 4px' }}>
          <div style={{ flex: 1, height: 2, background: t.border, borderRadius: 2 }}/>
          <span style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 700, color: t.inkMute, letterSpacing: 1 }}>O CON</span>
          <div style={{ flex: 1, height: 2, background: t.border, borderRadius: 2 }}/>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <AlexButton theme={t} variant="outline" full size="md" onClick={onComplete}>Google</AlexButton>
          <AlexButton theme={t} variant="outline" full size="md" onClick={onComplete}>Apple</AlexButton>
        </div>
      </div>
    </div>
  );
}

function AuthInput({ theme, label, value, onChange, secure }) {
  const t = theme;
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 0.8, color: t.inkSoft, textTransform: 'uppercase' }}>{label}</span>
      <input
        type={secure ? 'password' : 'text'}
        value={value}
        onChange={e => onChange(e.target.value)}
        style={{
          background: t.bgRaised, border: `2px solid ${t.border}`, borderRadius: 14,
          padding: '14px 16px', fontFamily: ALEX_FONT_UI, fontSize: 16, fontWeight: 600,
          color: t.ink, outline: 'none', boxShadow: `0 2px 0 0 ${t.border}`,
        }}
        onFocus={e => e.target.style.borderColor = t.primary}
        onBlur={e => e.target.style.borderColor = t.border}
      />
    </label>
  );
}

// ──────────────────────────────────────────────────────────────
// SCREEN: Mis Cursos (Home)
// ──────────────────────────────────────────────────────────────
function ScreenCourses({ theme, onOpenCourse, onCreate, onProfile, user }) {
  const t = theme;
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      <div style={{ padding: '60px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, fontWeight: 700, color: t.inkMute, letterSpacing: 0.4, textTransform: 'uppercase' }}>Hola, {user.name.split(' ')[0]}</div>
            <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 30, fontWeight: 800, color: t.ink, letterSpacing: -1 }}>Mis cursos</div>
          </div>
          <button onClick={onProfile} className="alex-tap"
            style={{
              width: 52, height: 52, borderRadius: 18, border: `2px solid ${t.border}`,
              background: t.primarySoft, padding: 0, cursor: 'pointer', overflow: 'hidden',
              boxShadow: `0 3px 0 0 ${t.border}`,
            }}>
            <AlexMascot size={48} mood="happy" theme={t} />
          </button>
        </div>

        {/* stats row */}
        <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
          <StatPill theme={t} icon={<FlameIcon size={20} color={t.danger} />} label={user.streak} sub="días" />
          <StatPill theme={t} icon={<BoltIcon size={20} color={t.gold} />} label={user.xp.toLocaleString()} sub="XP" />
          <StatPill theme={t} icon={<StarIcon size={20} color={t.accent} />} label={`Nv. ${user.level}`} sub="nivel" />
        </div>
      </div>

      {/* courses list */}
      <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '20px 20px 36px', marginTop: 12 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {ALEX_COURSES.map(c => (
            <CourseCard key={c.id} course={c} theme={t} onClick={() => onOpenCourse(c.id)} />
          ))}
          {/* create card */}
          <div onClick={onCreate} className="alex-tap" style={{
            border: `2.5px dashed ${t.borderStrong}`, borderRadius: 22, padding: 22,
            display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer',
            background: 'transparent',
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: 18, background: t.accent,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: `0 3px 0 0 ${t.accentDark}`,
            }}>
              <SparkleIcon size={28} color={t.accentInk} />
            </div>
            <div>
              <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 18, fontWeight: 800, color: t.ink, letterSpacing: -0.4 }}>Crear curso con IA</div>
              <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, color: t.inkSoft, fontWeight: 600, marginTop: 2 }}>Describe un tema y generamos lecciones</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatPill({ theme, icon, label, sub }) {
  const t = theme;
  return (
    <div style={{
      flex: 1, display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px',
      background: t.bgRaised, borderRadius: 16, border: `2px solid ${t.border}`,
    }}>
      {icon}
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.05 }}>
        <span style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 18, color: t.ink, letterSpacing: -0.3 }}>{label}</span>
        <span style={{ fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 11, color: t.inkMute, textTransform: 'uppercase', letterSpacing: 0.8 }}>{sub}</span>
      </div>
    </div>
  );
}

function CourseCard({ course, theme, onClick }) {
  const t = theme;
  const c = course;
  return (
    <AlexCard theme={t} onClick={onClick} padding={0} radius={22}
      color={t.bgRaised} edge={t.border}>
      <div style={{ display: 'flex', gap: 14, padding: 16 }}>
        {/* art block */}
        <div style={{
          width: 72, height: 72, flexShrink: 0,
          borderRadius: 18, background: c.color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 4px 0 0 ${c.edge}`,
        }}>
          <CourseGlyph kind={c.icon} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 19, color: t.ink, letterSpacing: -0.4, lineHeight: 1.15 }}>{c.title}</div>
          <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 13, color: t.inkSoft, fontWeight: 600, marginTop: 2 }}>{c.subtitle}</div>
          <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <AlexProgress value={c.progress} theme={t} color={c.color} height={10}/>
            </div>
            <span style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, color: t.inkSoft, minWidth: 38, textAlign: 'right' }}>
              {c.completedUnits}/{c.units}
            </span>
          </div>
        </div>
      </div>
    </AlexCard>
  );
}

function CourseGlyph({ kind }) {
  // simple geometric glyphs
  if (kind === 'painting') return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <rect x="6" y="8" width="28" height="22" rx="2" fill="#fff"/>
      <circle cx="14" cy="16" r="3" fill="oklch(0.78 0.15 75)"/>
      <path d="M9 26 L16 19 L22 24 L34 14 V30 H6 Z" fill="oklch(0.7 0.16 150)"/>
    </svg>
  );
  if (kind === 'pot') return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <rect x="8" y="14" width="24" height="18" rx="4" fill="#fff"/>
      <rect x="6" y="11" width="28" height="5" rx="2" fill="#fff"/>
      <circle cx="20" cy="9" r="2" fill="#fff"/>
    </svg>
  );
  if (kind === 'coin') return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <circle cx="20" cy="20" r="14" fill="#fff"/>
      <text x="20" y="26" textAnchor="middle" fontFamily="Bricolage Grotesque" fontSize="18" fontWeight="800" fill="oklch(0.58 0.13 195)">$</text>
    </svg>
  );
  if (kind === 'planet') return (
    <svg width="40" height="40" viewBox="0 0 40 40">
      <circle cx="20" cy="20" r="9" fill="#fff"/>
      <ellipse cx="20" cy="20" rx="16" ry="5" fill="none" stroke="#fff" strokeWidth="2"/>
    </svg>
  );
  return null;
}

// ──────────────────────────────────────────────────────────────
// SCREEN: Unit Map (vertical winding path)
// ──────────────────────────────────────────────────────────────
function ScreenUnitMap({ theme, onBack, onStartLesson, course }) {
  const t = theme;
  const c = course;
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      {/* hero header */}
      <div style={{
        background: c.color, color: '#fff',
        padding: '60px 20px 24px',
        borderBottomLeftRadius: 32, borderBottomRightRadius: 32,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={onBack} className="alex-tap"
            style={{
              width: 40, height: 40, borderRadius: 14, border: 'none',
              background: 'rgba(255,255,255,0.2)', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
            <ChevronIcon dir="left" color="#fff" size={22}/>
          </button>
          <div style={{ flex: 1 }}/>
          <AlexChip theme={t} icon={<FlameIcon size={16} color="#fff"/>} label="12" big={false}
            color="#fff"
          />
        </div>
        <div style={{ marginTop: 16, fontFamily: ALEX_FONT_UI, fontSize: 13, fontWeight: 800, letterSpacing: 1.4, textTransform: 'uppercase', opacity: 0.85 }}>UNIDAD 3 · ALTO RENACIMIENTO</div>
        <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 28, letterSpacing: -0.8, marginTop: 4, lineHeight: 1.1 }}>Leonardo, Miguel Ángel y Rafael</div>
        <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{
              height: 12, borderRadius: 12, background: 'rgba(255,255,255,0.2)',
              overflow: 'hidden', position: 'relative',
            }}>
              <div style={{
                width: '40%', height: '100%', background: '#fff', borderRadius: 12,
              }}/>
            </div>
          </div>
          <span style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 13 }}>2/6</span>
        </div>
      </div>

      {/* lesson path */}
      <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '20px 20px 60px' }}>
        {ALEX_UNIT3_LESSONS.map((l, i) => {
          const sideOffset = [0, 60, 100, 60, 0, -40, -80][i % 7] || 0;
          return (
            <LessonNode key={l.id} lesson={l} theme={t} index={i}
              offset={sideOffset}
              courseColor={c.color} courseEdge={c.edge}
              onStart={() => l.status === 'current' && onStartLesson()}
              isLast={i === ALEX_UNIT3_LESSONS.length - 1}
            />
          );
        })}

        {/* unit summary */}
        <div style={{ marginTop: 28 }}>
          <div style={{
            fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800,
            letterSpacing: 1.4, textTransform: 'uppercase', color: t.inkMute, textAlign: 'center', marginBottom: 12,
          }}>Próximas unidades</div>
          {ALEX_UNITS.slice(3,5).map(u => (
            <div key={u.id} style={{
              border: `2px solid ${t.border}`, borderRadius: 18, padding: 14,
              marginBottom: 10, display: 'flex', alignItems: 'center', gap: 12,
              background: t.bgSunken, opacity: 0.9,
            }}>
              <LockIcon size={22} color={t.inkMute}/>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 16, color: t.ink, letterSpacing: -0.3 }}>{u.title}</div>
                <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, color: t.inkSoft, fontWeight: 600 }}>{u.subtitle} · {u.lessons} lecciones</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LessonNode({ lesson, theme, index, offset = 0, courseColor, courseEdge, onStart, isLast }) {
  const t = theme;
  const isDone = lesson.status === 'done';
  const isCurrent = lesson.status === 'current';
  const isLocked = lesson.status === 'locked';
  const isPractice = lesson.type === 'practice';

  const bg = isDone ? t.success : isCurrent ? courseColor : t.bgSunken;
  const edge = isDone ? t.successDark : isCurrent ? courseEdge : t.border;

  return (
    <div style={{
      position: 'relative',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      marginBottom: isLast ? 0 : 24,
    }}>
      <div style={{ transform: `translateX(${offset * 0.5}px)`, position: 'relative' }}>
        {isCurrent && (
          <div style={{
            position: 'absolute', inset: -8, borderRadius: 999,
            border: `3px dashed ${courseColor}`, animation: 'alex-spin 14s linear infinite',
            pointerEvents: 'none',
          }} />
        )}
        <button onClick={onStart} disabled={!isCurrent} className="alex-tap"
          style={{
            width: 84, height: 84, borderRadius: '50%',
            background: bg, border: 'none',
            boxShadow: isLocked ? 'none' : `0 6px 0 0 ${edge}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: isCurrent ? 'pointer' : 'default',
            color: '#fff',
          }}>
          {isDone && <CheckIcon size={36} color="#fff" stroke={3.5}/>}
          {isLocked && <LockIcon size={32} color={t.inkMute}/>}
          {isCurrent && (isPractice ? <BoltIcon size={36} color="#fff"/> : <StarIcon size={36} color="#fff"/>)}
        </button>
        {isCurrent && (
          <div style={{
            position: 'absolute', top: -38, left: '50%', transform: 'translateX(-50%)',
            background: t.bgRaised, color: t.ink,
            padding: '6px 12px', borderRadius: 10, border: `2px solid ${t.border}`,
            fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 12,
            whiteSpace: 'nowrap', boxShadow: `0 3px 0 0 ${t.border}`,
            letterSpacing: 0.4, textTransform: 'uppercase',
          }}>
            ¡Empieza!
            <div style={{
              position: 'absolute', bottom: -7, left: '50%', transform: 'translateX(-50%) rotate(45deg)',
              width: 12, height: 12, background: t.bgRaised,
              borderRight: `2px solid ${t.border}`, borderBottom: `2px solid ${t.border}`,
            }} />
          </div>
        )}
      </div>
      <div style={{
        fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 14,
        color: isLocked ? t.inkMute : t.ink, marginTop: 8, textAlign: 'center',
      }}>
        {isPractice && '★ '}{lesson.title}
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// SCREEN: Crear Curso con IA — multi-step
// ──────────────────────────────────────────────────────────────
function ScreenCreate({ theme, onBack, onComplete }) {
  const t = theme;
  const [step, setStep] = uS_S(0); // 0 prompt, 1 config, 2 generating, 3 review
  const [prompt, setPrompt] = uS_S('Historia del jazz: orígenes, grandes músicos y géneros principales');
  const [level, setLevel] = uS_S('intermedio');
  const [duration, setDuration] = uS_S(4);
  const [genProgress, setGenProgress] = uS_S(0);
  const [units, setUnits] = uS_S([]);

  // Mock AI generation animation
  uE_S(() => {
    if (step !== 2) return;
    setGenProgress(0); setUnits([]);
    const items = [
      { name: 'Orígenes del jazz en Nueva Orleans', lessons: 4 },
      { name: 'La era del swing y las big bands', lessons: 5 },
      { name: 'Bebop: Charlie Parker y Dizzy Gillespie', lessons: 4 },
      { name: 'Cool jazz y hard bop', lessons: 4 },
      { name: 'Free jazz y fusión', lessons: 5 },
    ];
    let i = 0;
    const id = setInterval(() => {
      setGenProgress(p => Math.min(1, p + 0.025));
      if (i < items.length && Math.random() > 0.3) {
        setUnits(u => [...u, items[i]]);
        i++;
      }
    }, 140);
    const finish = setTimeout(() => {
      clearInterval(id);
      setUnits(items);
      setGenProgress(1);
      setTimeout(() => setStep(3), 700);
    }, 4500);
    return () => { clearInterval(id); clearTimeout(finish); };
  }, [step]);

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      <AlexHeader theme={t}
        left={step > 0 && step < 2 ? <AlexIconButton theme={t} onClick={() => setStep(s => Math.max(0, s-1))}>
          <ChevronIcon dir="left" color={t.inkSoft}/></AlexIconButton> : <AlexIconButton theme={t} onClick={onBack}><XIcon color={t.inkSoft} stroke={2.5}/></AlexIconButton>}
        title={['Nuevo curso', 'Configurar', 'Generando…', 'Revisar'][step]}
      />
      <div style={{ padding: '0 20px 8px' }}>
        <div style={{ display: 'flex', gap: 6 }}>
          {[0,1,2,3].map(i => (
            <div key={i} style={{
              flex: 1, height: 6, borderRadius: 6,
              background: i <= step ? t.primary : t.border,
              transition: 'background 0.3s ease',
            }}/>
          ))}
        </div>
      </div>

      {step === 0 && (
        <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
            <AlexMascot size={64} mood="thinking" theme={t}/>
            <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 22, fontWeight: 800, color: t.ink, letterSpacing: -0.6, lineHeight: 1.2 }}>
              ¿Qué quieres aprender?
            </div>
          </div>
          <div style={{ marginTop: 18 }}>
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)}
              placeholder="Describe un tema, una habilidad, un libro…"
              style={{
                width: '100%', minHeight: 140,
                background: t.bgRaised, border: `2px solid ${t.border}`, borderRadius: 18,
                padding: 16, fontFamily: ALEX_FONT_UI, fontSize: 16, fontWeight: 600, color: t.ink,
                outline: 'none', resize: 'none', boxShadow: `0 3px 0 0 ${t.border}`,
              }}/>
          </div>
          <div style={{ marginTop: 16, fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Sugerencias</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
            {['Mitología griega', 'Vinos del mundo', 'Anatomía humana', 'Photoshop básico', 'Fotografía analógica'].map(s => (
              <button key={s} onClick={() => setPrompt(s)} className="alex-tap"
                style={{
                  background: t.bgRaised, border: `2px solid ${t.border}`,
                  borderRadius: 999, padding: '8px 14px', cursor: 'pointer',
                  fontFamily: ALEX_FONT_UI, fontSize: 14, fontWeight: 700, color: t.inkSoft,
                }}>{s}</button>
            ))}
          </div>
          <div style={{ marginTop: 'auto', paddingTop: 24 }}>
            <AlexButton theme={t} full onClick={() => setStep(1)} disabled={prompt.trim().length < 4}>
              Continuar
            </AlexButton>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 20px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Nivel</div>
          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            {[
              { id: 'principiante', label: 'Principiante', sub: 'Sin conocimiento previo' },
              { id: 'intermedio',   label: 'Intermedio',   sub: 'Algunos conceptos básicos' },
              { id: 'avanzado',     label: 'Avanzado',     sub: 'Profundizar y conectar' },
            ].map(o => (
              <button key={o.id} onClick={() => setLevel(o.id)} className="alex-tap"
                style={{
                  flex: 1, padding: '14px 10px', textAlign: 'center', cursor: 'pointer',
                  border: `2px solid ${level === o.id ? t.primary : t.border}`,
                  background: level === o.id ? t.primarySoft : t.bgRaised,
                  boxShadow: `0 3px 0 0 ${level === o.id ? t.primary : t.border}`,
                  borderRadius: 16,
                  fontFamily: ALEX_FONT_UI,
                }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: t.ink }}>{o.label}</div>
                <div style={{ fontWeight: 600, fontSize: 11, color: t.inkSoft, marginTop: 4, lineHeight: 1.3 }}>{o.sub}</div>
              </button>
            ))}
          </div>

          <div style={{ marginTop: 22, fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Duración estimada</div>
          <div style={{ marginTop: 10, padding: 18, border: `2px solid ${t.border}`, borderRadius: 18, background: t.bgRaised }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 44, color: t.primary, letterSpacing: -1.2, lineHeight: 1 }}>{duration}</span>
              <span style={{ fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 16, color: t.inkSoft }}>{duration === 1 ? 'unidad' : 'unidades'} · ~{duration*4} lecciones</span>
            </div>
            <input type="range" min="2" max="8" value={duration}
              onChange={e => setDuration(parseInt(e.target.value))}
              style={{ width: '100%', marginTop: 12, accentColor: t.primary }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: ALEX_FONT_UI, fontSize: 11, fontWeight: 700, color: t.inkMute, marginTop: -2 }}>
              <span>Corto</span><span>Profundo</span>
            </div>
          </div>

          <div style={{ marginTop: 22, fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Formatos</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
            {[
              { id: 'multi', label: 'Opción múltiple' },
              { id: 'tf',    label: 'Verdadero / Falso' },
              { id: 'fill',  label: 'Completar la frase' },
            ].map(o => (
              <div key={o.id} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 14px', border: `2px solid ${t.border}`, background: t.bgRaised,
                borderRadius: 14,
              }}>
                <div style={{
                  width: 24, height: 24, borderRadius: 8, background: t.success,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <CheckIcon size={16} color="#fff" stroke={3.5}/>
                </div>
                <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 15, color: t.ink }}>{o.label}</div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 'auto', paddingTop: 24 }}>
            <AlexButton theme={t} full onClick={() => setStep(2)}>
              <SparkleIcon size={20} color="#fff"/> Generar curso
            </AlexButton>
          </div>
        </div>
      )}

      {step === 2 && (
        <div style={{ flex: 1, padding: '20px 20px 24px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 16 }}>
            <div style={{ position: 'relative' }}>
              <div style={{
                position: 'absolute', inset: -10, borderRadius: '50%',
                border: `3px dashed ${t.accent}`, animation: 'alex-spin 4s linear infinite',
              }}/>
              <AlexMascot size={96} mood="thinking" theme={t}/>
            </div>
            <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontSize: 22, fontWeight: 800, color: t.ink, letterSpacing: -0.5, marginTop: 18 }}>Diseñando tu curso…</div>
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, color: t.inkSoft, fontWeight: 600, marginTop: 4 }}>Un momento, esto vale la pena</div>
          </div>
          <div style={{ marginTop: 22 }}>
            <AlexProgress value={genProgress} theme={t} color={t.primary} height={14}/>
            <div style={{ marginTop: 6, fontFamily: ALEX_FONT_MONO, fontSize: 12, color: t.inkMute, textAlign: 'right' }}>
              {Math.round(genProgress * 100)}%
            </div>
          </div>
          <div style={{ flex: 1, marginTop: 14, overflow: 'hidden' }}>
            {units.map((u, i) => (
              <div key={i} className="alex-fade-up" style={{
                display: 'flex', gap: 10, alignItems: 'center', padding: '10px 12px',
                border: `2px solid ${t.border}`, background: t.bgRaised,
                borderRadius: 14, marginBottom: 8,
              }}>
                <div style={{
                  width: 26, height: 26, borderRadius: 8, background: t.successSoft,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <CheckIcon size={14} color={t.successDark} stroke={3.5}/>
                </div>
                <div style={{ flex: 1, fontFamily: ALEX_FONT_UI, fontSize: 14, fontWeight: 700, color: t.ink }}>{u.name}</div>
                <span style={{ fontFamily: ALEX_FONT_MONO, fontSize: 11, color: t.inkMute }}>{u.lessons} lecciones</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 24px' }}>
          <div style={{
            background: 'oklch(0.42 0.18 285)', color: '#fff', padding: 20,
            borderRadius: 22, boxShadow: `0 5px 0 0 oklch(0.32 0.16 285)`,
          }}>
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1.4, opacity: 0.85 }}>TU NUEVO CURSO</div>
            <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 26, letterSpacing: -0.6, marginTop: 4, lineHeight: 1.15 }}>Historia del Jazz</div>
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 14, fontWeight: 600, opacity: 0.9, marginTop: 4 }}>{units.length} unidades · {units.reduce((s,u)=>s+u.lessons,0)} lecciones · nivel intermedio</div>
          </div>
          <div style={{ marginTop: 18, fontFamily: ALEX_FONT_UI, fontSize: 12, fontWeight: 800, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Unidades · toca para editar</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 10 }}>
            {units.map((u, i) => (
              <div key={i} className="alex-tap" style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: 14,
                border: `2px solid ${t.border}`, background: t.bgRaised, borderRadius: 16,
                cursor: 'pointer', boxShadow: `0 2px 0 0 ${t.border}`,
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 12, background: t.primary,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#fff', fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800,
                }}>{i+1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 15, color: t.ink }}>{u.name}</div>
                  <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 12, color: t.inkSoft, fontWeight: 600 }}>{u.lessons} lecciones</div>
                </div>
                <ChevronIcon dir="right" color={t.inkMute} size={20}/>
              </div>
            ))}
          </div>
          <div style={{ paddingTop: 20 }}>
            <AlexButton theme={t} full onClick={onComplete}>
              <CheckIcon size={20} color="#fff"/> Empezar curso
            </AlexButton>
          </div>
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// SCREEN: Profile
// ──────────────────────────────────────────────────────────────
function ScreenProfile({ theme, onBack, user, onLogout, onToggleDark, dark }) {
  const t = theme;
  const stats = [
    { label: 'Días seguidos', value: user.streak, icon: <FlameIcon size={22} color={t.danger}/>, color: t.dangerSoft, edge: t.danger },
    { label: 'XP totales',    value: user.xp.toLocaleString(), icon: <BoltIcon size={22} color={t.gold}/>, color: t.goldSoft, edge: t.gold },
    { label: 'Lecciones',     value: user.lessonsDone, icon: <StarIcon size={22} color={t.accent}/>, color: t.accentSoft, edge: t.accent },
    { label: 'Récord',        value: `${user.longestStreak}d`, icon: <CheckIcon size={22} color={t.successDark} stroke={3}/>, color: t.successSoft, edge: t.success },
  ];
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: t.bg }}>
      <AlexHeader theme={t}
        left={<AlexIconButton theme={t} onClick={onBack}><ChevronIcon dir="left" color={t.inkSoft}/></AlexIconButton>}
        title="Mi perfil"/>
      <div className="alex-scroll" style={{ flex: 1, overflowY: 'auto', padding: '4px 20px 28px' }}>
        {/* hero card */}
        <div style={{
          background: t.primary, color: '#fff', borderRadius: 24,
          padding: 20, display: 'flex', alignItems: 'center', gap: 16,
          boxShadow: `0 5px 0 0 ${t.primaryDark}`,
        }}>
          <div style={{
            width: 80, height: 80, borderRadius: 24, background: 'rgba(255,255,255,0.18)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <AlexMascot size={68} mood="celebrating" theme={t}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 24, letterSpacing: -0.5 }}>{user.name}</div>
            <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 14, opacity: 0.9 }}>{user.handle} · Nivel {user.level}</div>
            <div style={{
              marginTop: 10, height: 8, borderRadius: 8, background: 'rgba(255,255,255,0.25)', position: 'relative',
            }}>
              <div style={{ width: '64%', height: '100%', background: '#fff', borderRadius: 8 }}/>
            </div>
            <div style={{ fontFamily: ALEX_FONT_UI, fontSize: 11, fontWeight: 700, marginTop: 4, opacity: 0.85 }}>360 XP para Nivel {user.level + 1}</div>
          </div>
        </div>

        {/* stats grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 16 }}>
          {stats.map((s, i) => (
            <div key={i} style={{
              padding: 14, borderRadius: 18, border: `2px solid ${t.border}`,
              background: t.bgRaised, display: 'flex', flexDirection: 'column', gap: 4,
              boxShadow: `0 3px 0 0 ${t.border}`,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 12, background: s.color,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{s.icon}</div>
              <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 24, color: t.ink, letterSpacing: -0.5, marginTop: 6 }}>{s.value}</div>
              <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 12, color: t.inkSoft, textTransform: 'uppercase', letterSpacing: 0.6 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* daily goal */}
        <div style={{
          marginTop: 16, padding: 16, borderRadius: 18, border: `2px solid ${t.border}`,
          background: t.bgRaised, boxShadow: `0 3px 0 0 ${t.border}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 12, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase' }}>Meta diaria</div>
              <div style={{ fontFamily: ALEX_FONT_DISPLAY, fontWeight: 800, fontSize: 20, color: t.ink, letterSpacing: -0.4 }}>{user.goalDone} / {user.goal} min</div>
            </div>
            <DailyGoalRing pct={user.goalDone / user.goal} theme={t}/>
          </div>
          <div style={{ marginTop: 10 }}>
            <AlexProgress value={user.goalDone / user.goal} theme={t} color={t.accent} height={10}/>
          </div>
        </div>

        {/* settings list */}
        <div style={{ marginTop: 16 }}>
          <div style={{ fontFamily: ALEX_FONT_UI, fontWeight: 800, fontSize: 12, letterSpacing: 1, color: t.inkMute, textTransform: 'uppercase', marginBottom: 8, paddingLeft: 4 }}>Cuenta</div>
          <SettingRow theme={t} label="Editar perfil" right={<ChevronIcon dir="right" color={t.inkMute}/>}/>
          <SettingRow theme={t} label="Modo oscuro"
            right={<ToggleSwitch on={dark} theme={t} onChange={onToggleDark}/>}
            last/>
        </div>
        <div style={{ marginTop: 14 }}>
          <AlexButton theme={t} variant="outline" full onClick={onLogout}>Cerrar sesión</AlexButton>
        </div>
      </div>
    </div>
  );
}

function DailyGoalRing({ pct, theme }) {
  const t = theme;
  const r = 22, c = 2 * Math.PI * r;
  return (
    <svg width="56" height="56" viewBox="0 0 56 56">
      <circle cx="28" cy="28" r={r} fill="none" stroke={t.border} strokeWidth="6"/>
      <circle cx="28" cy="28" r={r} fill="none" stroke={t.accent} strokeWidth="6"
        strokeDasharray={c} strokeDashoffset={c * (1 - pct)}
        strokeLinecap="round" transform="rotate(-90 28 28)"/>
      <text x="28" y="32" textAnchor="middle" fontFamily="Bricolage Grotesque" fontWeight="800" fontSize="13" fill={t.ink}>{Math.round(pct*100)}%</text>
    </svg>
  );
}

function SettingRow({ theme, label, right, last }) {
  const t = theme;
  return (
    <div style={{
      padding: '14px 16px',
      background: t.bgRaised,
      borderTop: `2px solid ${t.border}`,
      borderLeft: `2px solid ${t.border}`,
      borderRight: `2px solid ${t.border}`,
      borderBottom: last ? `2px solid ${t.border}` : 'none',
      borderTopLeftRadius: last ? 0 : 16,
      borderTopRightRadius: last ? 0 : 16,
      borderBottomLeftRadius: last ? 16 : 0,
      borderBottomRightRadius: last ? 16 : 0,
      display: 'flex', alignItems: 'center', gap: 12,
      fontFamily: ALEX_FONT_UI, fontWeight: 700, fontSize: 15, color: t.ink,
    }}>
      <span style={{ flex: 1 }}>{label}</span>
      {right}
    </div>
  );
}

function ToggleSwitch({ on, theme, onChange }) {
  const t = theme;
  return (
    <button onClick={() => onChange(!on)} className="alex-tap"
      style={{
        width: 52, height: 30, borderRadius: 30,
        background: on ? t.primary : t.border, border: 'none',
        position: 'relative', cursor: 'pointer', padding: 0, transition: 'background 0.2s',
      }}>
      <div style={{
        position: 'absolute', top: 3, left: on ? 25 : 3,
        width: 24, height: 24, borderRadius: '50%', background: '#fff',
        transition: 'left 0.2s ease', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
      }}/>
    </button>
  );
}

Object.assign(window, {
  ScreenAuth, ScreenCourses, ScreenUnitMap, ScreenCreate, ScreenProfile,
});
