// Alexandria — main app shell. Routes between screens, manages global state, wraps in iPhone frame.

const { useState: uS_A, useEffect: uE_A } = React;

function AlexandriaApp() {
  // Tweaks: just dark mode for now
  const [tweaks, setTweak] = useTweaks(ALEX_DEFAULTS);
  const dark = !!tweaks.dark;
  const theme = useAlexTheme(dark);

  // body class drives the gradient bg behind the phone
  uE_A(() => {
    document.body.classList.toggle('alex-dark', dark);
  }, [dark]);

  const [screen, setScreen] = uS_A('auth'); // auth | courses | unitMap | lesson | create | profile
  const [activeCourseId, setActiveCourseId] = uS_A('renacimiento');
  const activeCourse = ALEX_COURSES.find(c => c.id === activeCourseId) || ALEX_COURSES[0];

  // dynamic-scaled iPhone frame to fit viewport
  const FRAME_W = 402, FRAME_H = 874;
  const [scale, setScale] = uS_A(1);
  uE_A(() => {
    function compute() {
      const margin = 80;
      const sw = (window.innerWidth - margin) / FRAME_W;
      const sh = (window.innerHeight - margin) / FRAME_H;
      setScale(Math.min(1.05, Math.min(sw, sh)));
    }
    compute();
    window.addEventListener('resize', compute);
    return () => window.removeEventListener('resize', compute);
  }, []);

  function go(s) { setScreen(s); }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
      <div style={{ transform: `scale(${scale})`, transformOrigin: 'center center' }}>
        <IOSDevice width={FRAME_W} height={FRAME_H} dark={dark}>
          <div data-screen-label={`Screen: ${screen}`} style={{ height: '100%', width: '100%', position: 'relative' }}>
            {screen === 'auth' && (
              <ScreenAuth theme={theme} onComplete={() => go('courses')}/>
            )}
            {screen === 'courses' && (
              <ScreenCourses theme={theme} user={ALEX_USER}
                onOpenCourse={(id) => { setActiveCourseId(id); go('unitMap'); }}
                onCreate={() => go('create')}
                onProfile={() => go('profile')}/>
            )}
            {screen === 'unitMap' && (
              <ScreenUnitMap theme={theme} course={activeCourse}
                onBack={() => go('courses')}
                onStartLesson={() => go('lesson')}/>
            )}
            {screen === 'lesson' && (
              <ScreenLesson theme={theme}
                onExit={() => go('unitMap')}
                onComplete={() => go('unitMap')}/>
            )}
            {screen === 'create' && (
              <ScreenCreate theme={theme}
                onBack={() => go('courses')}
                onComplete={() => go('courses')}/>
            )}
            {screen === 'profile' && (
              <ScreenProfile theme={theme} user={ALEX_USER} dark={dark}
                onToggleDark={(v) => setTweak('dark', v)}
                onBack={() => go('courses')}
                onLogout={() => go('auth')}/>
            )}
          </div>
        </IOSDevice>
      </div>

      {/* Floating screen-jump dock — hover/show on tap. Helps the user navigate. */}
      <ScreenDock current={screen} go={go} dark={dark} theme={theme}/>
    </div>
  );
}

function ScreenDock({ current, go, dark, theme }) {
  const [open, setOpen] = uS_A(false);
  const t = theme;
  const items = [
    { id: 'auth',     label: 'Auth' },
    { id: 'courses',  label: 'Cursos' },
    { id: 'unitMap',  label: 'Unidades' },
    { id: 'lesson',   label: 'Lección' },
    { id: 'create',   label: 'Crear' },
    { id: 'profile',  label: 'Perfil' },
  ];
  return (
    <div style={{
      position: 'fixed', left: 24, bottom: 24, zIndex: 100,
      display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 8,
      fontFamily: ALEX_FONT_UI,
    }}>
      {open && (
        <div style={{
          background: dark ? 'rgba(28,28,32,0.92)' : 'rgba(255,255,255,0.92)',
          backdropFilter: 'blur(10px)',
          border: `1.5px solid ${dark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'}`,
          borderRadius: 18, padding: 8,
          boxShadow: '0 8px 30px rgba(0,0,0,0.18)',
          display: 'flex', flexDirection: 'column', gap: 4, minWidth: 180,
        }}>
          <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: 1.2,
            color: dark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.45)',
            padding: '6px 10px 2px', textTransform: 'uppercase' }}>Saltar a pantalla</div>
          {items.map(it => (
            <button key={it.id} onClick={() => { go(it.id); setOpen(false); }}
              style={{
                background: it.id === current ? t.primary : 'transparent',
                color: it.id === current ? '#fff' : (dark ? '#fff' : '#222'),
                border: 'none', textAlign: 'left',
                padding: '8px 12px', borderRadius: 12, cursor: 'pointer',
                fontSize: 13, fontWeight: 700, letterSpacing: 0.2,
              }}>
              {it.label}
            </button>
          ))}
        </div>
      )}
      <button onClick={() => setOpen(v => !v)}
        style={{
          width: 44, height: 44, borderRadius: 22,
          background: dark ? 'rgba(28,28,32,0.92)' : 'rgba(255,255,255,0.92)',
          backdropFilter: 'blur(10px)',
          border: `1.5px solid ${dark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'}`,
          color: dark ? '#fff' : '#222', cursor: 'pointer',
          fontSize: 20, fontWeight: 800,
          boxShadow: '0 4px 14px rgba(0,0,0,0.12)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
        {open ? '×' : '☰'}
      </button>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<AlexandriaApp/>);
