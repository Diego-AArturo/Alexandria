// Mock content for Alexandria — Renaissance Art course + others.

const ALEX_COURSES = [
  {
    id: 'renacimiento',
    title: 'Arte del Renacimiento',
    subtitle: 'De Florencia a Roma',
    color: 'oklch(0.42 0.18 285)',
    edge:  'oklch(0.32 0.16 285)',
    progress: 0.42,
    units: 6,
    completedUnits: 2,
    icon: 'painting',
  },
  {
    id: 'cocina',
    title: 'Cocina Italiana',
    subtitle: 'Pasta, salsas y técnica',
    color: 'oklch(0.65 0.18 25)',
    edge:  'oklch(0.5 0.18 25)',
    progress: 0.18,
    units: 5,
    completedUnits: 1,
    icon: 'pot',
  },
  {
    id: 'finanzas',
    title: 'Finanzas Personales',
    subtitle: 'Interés compuesto, ahorro',
    color: 'oklch(0.72 0.13 195)',
    edge:  'oklch(0.58 0.13 195)',
    progress: 0.72,
    units: 4,
    completedUnits: 3,
    icon: 'coin',
  },
  {
    id: 'astronomia',
    title: 'Sistema Solar',
    subtitle: 'Planetas, lunas y más',
    color: 'oklch(0.5 0.15 250)',
    edge:  'oklch(0.4 0.15 250)',
    progress: 0,
    units: 7,
    completedUnits: 0,
    icon: 'planet',
  },
];

// Renaissance course units — for the unit map
const ALEX_UNITS = [
  { id: 'u1', title: 'Orígenes en Florencia', lessons: 5, status: 'done',    color: 'success', subtitle: 'Brunelleschi y la perspectiva' },
  { id: 'u2', title: 'Los maestros tempranos', lessons: 5, status: 'done',    color: 'success', subtitle: 'Masaccio, Donatello, Botticelli' },
  { id: 'u3', title: 'El Alto Renacimiento',   lessons: 6, status: 'current', color: 'primary', subtitle: 'Leonardo, Miguel Ángel, Rafael', currentLesson: 3 },
  { id: 'u4', title: 'Venecia y el color',     lessons: 5, status: 'locked',  color: 'mute',    subtitle: 'Tiziano, Tintoretto, Veronés' },
  { id: 'u5', title: 'Manierismo',             lessons: 4, status: 'locked',  color: 'mute',    subtitle: 'La crisis del clasicismo' },
  { id: 'u6', title: 'Norte de Europa',        lessons: 5, status: 'locked',  color: 'mute',    subtitle: 'Durero, Van Eyck, Brueghel' },
];

// Lessons inside Unit 3 — used by the unit map "vertical path"
const ALEX_UNIT3_LESSONS = [
  { id: 'l1', title: 'Leonardo: el genio', status: 'done',    type: 'lesson' },
  { id: 'l2', title: 'La Última Cena',      status: 'done',    type: 'lesson' },
  { id: 'l3', title: 'Miguel Ángel',         status: 'current', type: 'lesson' },
  { id: 'l4', title: 'Capilla Sixtina',      status: 'locked',  type: 'lesson' },
  { id: 'l5', title: 'Refuerzo: maestros',   status: 'locked',  type: 'practice' },
  { id: 'l6', title: 'Rafael y la Escuela',  status: 'locked',  type: 'lesson' },
];

// ──────────────────────────────────────────────────────────────
// LESSON STEPS — Miguel Ángel
// Types: 'concept' | 'multi' | 'tf' | 'fill'
// ──────────────────────────────────────────────────────────────
const ALEX_LESSON_STEPS = [
  {
    type: 'concept',
    title: 'Miguel Ángel Buonarroti',
    eyebrow: 'Concepto · 1475 — 1564',
    body: 'Escultor, pintor y arquitecto florentino. Para él, el escultor "libera" la figura que ya vive dentro del bloque de mármol — una idea que define todo el Alto Renacimiento.',
    image: 'busto · Miguel Ángel',
    fact: 'Pintó la bóveda de la Capilla Sixtina entre 1508 y 1512, mayormente de pie, no acostado.',
  },
  {
    type: 'multi',
    prompt: '¿Qué obra esculpió Miguel Ángel cuando solo tenía 24 años?',
    options: [
      { id: 'a', label: 'El David', correct: false, hint: 'El David vino después.' },
      { id: 'b', label: 'La Piedad', correct: true },
      { id: 'c', label: 'Moisés', correct: false },
      { id: 'd', label: 'Esclavos', correct: false },
    ],
    explain: 'La Piedad (1499), en San Pedro del Vaticano. Es la única obra que firmó.',
  },
  {
    type: 'tf',
    prompt: 'Miguel Ángel pintó la Capilla Sixtina acostado boca arriba sobre un andamio.',
    answer: false,
    explain: 'Mito popular. En realidad pintó de pie, con la cabeza inclinada hacia atrás — algo que le destrozó el cuello durante años.',
  },
  {
    type: 'fill',
    prompt: 'Completa la frase con las palabras correctas:',
    sentence: ['El', null, 'libera la figura que ya existe', 'dentro del bloque de', null, '.'],
    blanks: [
      { id: 'b1', correct: 'escultor' },
      { id: 'b2', correct: 'mármol' },
    ],
    bank: ['mármol', 'escultor', 'pintor', 'bronce', 'arquitecto'],
    explain: 'Esta es la idea central de Miguel Ángel sobre la escultura.',
  },
  {
    type: 'multi',
    prompt: '¿Cuál de estas obras se encuentra en la Galería de la Academia de Florencia?',
    options: [
      { id: 'a', label: 'La Piedad',    correct: false },
      { id: 'b', label: 'El David',      correct: true },
      { id: 'c', label: 'Moisés',        correct: false },
      { id: 'd', label: 'La Creación',   correct: false },
    ],
    explain: 'El David (1501–1504), 5.17 m de mármol. Originalmente estaba en la Piazza della Signoria.',
  },
  {
    type: 'fill',
    prompt: 'Completa con la fecha y el lugar:',
    sentence: ['La bóveda de la Capilla Sixtina se pintó entre', null, 'y 1512, en', null, '.'],
    blanks: [
      { id: 'b1', correct: '1508' },
      { id: 'b2', correct: 'Roma' },
    ],
    bank: ['1508', '1620', 'Roma', 'Florencia', '1450', 'Venecia'],
    explain: 'Cuatro años bajo el patrocinio del Papa Julio II.',
  },
];

const ALEX_USER = {
  name: 'Sofía Reyes',
  handle: '@sofia',
  joined: 'Marzo 2026',
  xp: 2840,
  streak: 12,
  longestStreak: 27,
  lessonsDone: 47,
  level: 8,
  goal: 30, // minutes/day
  goalDone: 18,
};

Object.assign(window, {
  ALEX_COURSES, ALEX_UNITS, ALEX_UNIT3_LESSONS, ALEX_LESSON_STEPS, ALEX_USER,
});
