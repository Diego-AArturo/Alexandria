// Alexandria — Lesson screen (concept, MC, T/F, fill-blank)
function LessonScreen({ course, unit, onExit, onComplete }) {
  // Build queue: concepts first, then questions; wrong-answered questions become refreshers at end
  const baseItems = SEED_LESSON;
  const concepts = baseItems.filter(i => i.type === 'concept');
  const questions = baseItems.filter(i => i.type !== 'concept');
  const [queue, setQueue] = React.useState([...concepts, ...questions]);
  const [idx, setIdx] = React.useState(0);
  const [answers, setAnswers] = React.useState({}); // idx -> { value, correct, revealed }
  const [refreshers, setRefreshers] = React.useState([]); // queued for end
  const [phase, setPhase] = React.useState('answer'); // answer | revealed
  const [exiting, setExiting] = React.useState(false);

  const item = queue[idx];
  const answered = answers[idx];
  const isLast = idx === queue.length - 1;

  // Counter label
  const counterLabel = React.useMemo(() => {
    if (item.type === 'concept') {
      const conceptIdx = queue.slice(0, idx+1).filter(q => q.type === 'concept').length;
      const totalConcepts = queue.filter(q => q.type === 'concept').length;
      return `Concept ${conceptIdx} of ${totalConcepts}`;
    }
    // Was this a refresher (added beyond original questions)?
    const originalCount = concepts.length + questions.length;
    if (idx >= originalCount) {
      const refIdx = idx - originalCount + 1;
      return `Refresher ${refIdx} of ${refreshers.length || 1}`;
    }
    const qIdx = queue.slice(0, idx+1).filter(q => q.type !== 'concept' && queue.indexOf(q) < originalCount).length;
    const totalQ = questions.length;
    return `Question ${qIdx} of ${totalQ}`;
  }, [idx, queue, refreshers]);

  const overall = ((idx + (phase === 'revealed' ? 0.5 : 0)) / queue.length) * 100;

  const setAnswer = (val) => {
    if (phase === 'revealed') return;
    setAnswers(a => ({ ...a, [idx]: { ...(a[idx]||{}), value: val } }));
  };

  const submit = () => {
    if (phase === 'answer') {
      const a = answers[idx] || {};
      let correct = false;
      if (item.type === 'mc') correct = a.value === item.answer;
      else if (item.type === 'tf') correct = a.value === item.answer;
      else if (item.type === 'fill') correct = JSON.stringify(a.value) === JSON.stringify(item.answer);
      setAnswers(prev => ({ ...prev, [idx]: { ...a, correct, revealed: true } }));
      if (!correct) setRefreshers(r => [...r, item]);
      setPhase('revealed');
    } else {
      // Advance
      if (isLast) {
        // Append refreshers if there are any new ones at end of queue
        // (Already added during reveal; check if more remain past current queue)
        if (refreshers.length > 0 && queue.length === concepts.length + questions.length) {
          setQueue(q => [...q, ...refreshers]);
          setRefreshers([]);
          setIdx(idx + 1);
          setPhase('answer');
        } else {
          setExiting(true);
          setTimeout(() => onComplete(course.id, unit.id), 400);
        }
      } else {
        setIdx(idx + 1);
        setPhase('answer');
      }
    }
  };

  const goBack = () => {
    if (idx === 0) return;
    setIdx(idx - 1);
    setPhase(answers[idx-1]?.revealed ? 'revealed' : 'answer');
  };

  const canSubmit = item.type === 'concept' || (answers[idx]?.value !== undefined && answers[idx]?.value !== null && (item.type !== 'fill' || (answers[idx].value || []).filter(Boolean).length === item.blanks));

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{ padding: '60px 16px 0', flexShrink: 0 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 12, marginBottom: 14 }}>
          <button onClick={onExit}
            style={{
              width: 40, height: 40, borderRadius: 12,
              background:'white', border:'2px solid var(--ink-100)',
              boxShadow:'0 3px 0 var(--ink-100)',
              display:'flex', alignItems:'center', justifyContent:'center',
              color:'var(--ink-700)',
            }}>{Icon.x('currentColor', 20)}</button>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--ink-500)',
                          textTransform: 'uppercase', letterSpacing: 1 }}>
              {counterLabel}
            </div>
            <div style={{ fontSize: 15, fontWeight: 900, color: 'var(--ink-900)', marginTop: 2 }}>
              {unit.title}
            </div>
          </div>
          <div style={{ width: 40 }}/>
        </div>
        <div className="progress thin" style={{ marginBottom: 0 }}>
          <div className="fill" style={{ width: `${overall}%` }}/>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow:'auto', padding: '24px 16px 20px' }}>
        <div key={idx} className="slide-up">
          {item.type === 'concept' && <ConceptCard item={item}/>}
          {item.type === 'mc' && (
            <MCCard item={item} value={answers[idx]?.value}
                    revealed={phase === 'revealed'}
                    correct={answers[idx]?.correct}
                    onPick={setAnswer}/>
          )}
          {item.type === 'tf' && (
            <TFCard item={item} value={answers[idx]?.value}
                    revealed={phase === 'revealed'}
                    correct={answers[idx]?.correct}
                    onPick={setAnswer}/>
          )}
          {item.type === 'fill' && (
            <FillCard item={item} value={answers[idx]?.value}
                      revealed={phase === 'revealed'}
                      correct={answers[idx]?.correct}
                      onChange={setAnswer}/>
          )}
        </div>
      </div>

      {/* Feedback row */}
      {phase === 'revealed' && item.type !== 'concept' && (
        <FeedbackBanner correct={answers[idx]?.correct} explanation={item.explanation}/>
      )}

      {/* Bottom controls */}
      <div style={{
        flexShrink: 0, padding: '14px 16px 28px',
        background: 'white',
        borderTop: '2px solid var(--ink-100)',
        display:'flex', gap: 10,
      }}>
        <button onClick={goBack} disabled={idx === 0}
          className="btn3d ghost"
          style={{ width: 56, padding: '14px 0', flexShrink: 0 }}>
          {Icon.chevL('currentColor', 22)}
        </button>
        <button onClick={submit} disabled={!canSubmit}
          className={`btn3d ${phase === 'revealed' && answers[idx]?.correct ? 'teal' : ''}`}
          style={{ flex: 1 }}>
          {item.type === 'concept'
            ? (isLast ? 'Finish' : 'Continue')
            : phase === 'answer'
              ? 'Submit Answer'
              : (isLast && refreshers.length === 0 ? 'Finish' : 'Continue')}
        </button>
      </div>
    </div>
  );
}

// ─── Concept card ───
function ConceptCard({ item }) {
  return (
    <div className="card" style={{ padding: 24 }}>
      <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 14 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: 'var(--violet-100)', color: 'var(--violet-700)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="9" cy="9" r="7" stroke="currentColor" strokeWidth="2.4"/>
            <path d="M9 5v4l2.5 2" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"/>
          </svg>
        </div>
        <div className="pill" style={{ background: 'var(--violet-100)', color:'var(--violet-700)' }}>
          Concept
        </div>
      </div>
      <div style={{ fontSize: 24, fontWeight: 900, color: 'var(--ink-900)',
                    lineHeight: 1.2, letterSpacing: -0.4, marginBottom: 14 }}>
        {item.title}
      </div>
      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--ink-700)', lineHeight: 1.5 }}>
        {item.body}
      </div>
      {item.bullets && (
        <ul style={{ marginTop: 14, paddingLeft: 0, listStyle:'none', display:'flex', flexDirection:'column', gap: 10 }}>
          {item.bullets.map((b, i) => (
            <li key={i} style={{ display:'flex', gap: 12, fontSize: 15, color: 'var(--ink-700)', fontWeight: 700, lineHeight: 1.4 }}>
              <div style={{
                width: 22, height: 22, borderRadius: 9999,
                background: 'var(--teal-100)', color:'var(--teal-700)',
                display:'flex', alignItems:'center', justifyContent:'center', flexShrink: 0,
                marginTop: 1,
              }}>
                {Icon.check('currentColor', 14)}
              </div>
              <span>{b}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ─── Multiple choice ───
function MCCard({ item, value, revealed, correct, onPick }) {
  return (
    <div>
      <div className="pill" style={{ background: 'var(--violet-100)', color:'var(--violet-700)', marginBottom: 14 }}>Select one</div>
      <div style={{ fontSize: 22, fontWeight: 900, color:'var(--ink-900)', lineHeight: 1.25, marginBottom: 18 }}>
        {item.stem}
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
        {item.options.map((opt, i) => {
          const selected = value === i;
          const isCorrectAnswer = i === item.answer;
          let bg = 'white', border = 'var(--ink-200)', shadow = 'var(--ink-100)', color = 'var(--ink-900)';
          if (revealed && isCorrectAnswer) { bg='var(--teal-100)'; border='var(--teal-500)'; shadow='var(--teal-300)'; color='var(--teal-700)'; }
          else if (revealed && selected && !isCorrectAnswer) { bg='var(--coral-100)'; border='var(--coral-500)'; shadow='#FFB5AE'; color='var(--coral-700)'; }
          else if (selected) { bg='var(--violet-50)'; border='var(--violet-500)'; shadow='var(--violet-200)'; color='var(--violet-700)'; }
          return (
            <button key={i} onClick={() => onPick(i)} disabled={revealed}
              style={{
                background: bg, border: `2px solid ${border}`,
                boxShadow: `0 3px 0 ${shadow}`,
                borderRadius: 16, padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 12,
                fontSize: 15, fontWeight: 800, color, textAlign: 'left',
                transition: 'all 0.15s ease',
                cursor: revealed ? 'default' : 'pointer',
              }}>
              <div style={{
                width: 24, height: 24, borderRadius: 9999, flexShrink: 0,
                border: `2.5px solid ${selected || (revealed && isCorrectAnswer) ? color : 'var(--ink-200)'}`,
                background: revealed && isCorrectAnswer ? 'var(--teal-500)' : (revealed && selected && !isCorrectAnswer ? 'var(--coral-500)' : 'transparent'),
                display:'flex', alignItems:'center', justifyContent:'center',
              }}>
                {selected && !revealed && <div style={{ width: 10, height: 10, borderRadius: 9999, background: 'var(--violet-600)' }}/>}
                {revealed && isCorrectAnswer && Icon.check('white', 14)}
                {revealed && selected && !isCorrectAnswer && Icon.x('white', 14)}
              </div>
              <span style={{ flex: 1 }}>{opt}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── True/False ───
function TFCard({ item, value, revealed, onPick }) {
  const opt = (val, label) => {
    const selected = value === val;
    const isCorrectAnswer = val === item.answer;
    let bg = 'white', border = 'var(--ink-200)', shadow = 'var(--ink-100)', color = 'var(--ink-900)';
    if (revealed && isCorrectAnswer) { bg='var(--teal-100)'; border='var(--teal-500)'; shadow='var(--teal-300)'; color='var(--teal-700)'; }
    else if (revealed && selected && !isCorrectAnswer) { bg='var(--coral-100)'; border='var(--coral-500)'; shadow='#FFB5AE'; color='var(--coral-700)'; }
    else if (selected) { bg='var(--violet-50)'; border='var(--violet-500)'; shadow='var(--violet-200)'; color='var(--violet-700)'; }
    return (
      <button onClick={() => onPick(val)} disabled={revealed}
        style={{
          flex: 1, height: 130, borderRadius: 22,
          background: bg, border: `3px solid ${border}`, boxShadow: `0 5px 0 ${shadow}`,
          display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap: 8,
          fontSize: 22, fontWeight: 900, color,
          transition: 'all 0.15s ease',
          cursor: revealed ? 'default' : 'pointer',
        }}>
        <div style={{
          width: 44, height: 44, borderRadius: 14,
          background: val ? 'var(--teal-100)' : 'var(--coral-100)',
          color: val ? 'var(--teal-700)' : 'var(--coral-700)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize: 22, fontWeight: 900,
        }}>{val ? '✓' : '✗'}</div>
        {label}
      </button>
    );
  };
  return (
    <div>
      <div className="pill" style={{ background: 'var(--violet-100)', color:'var(--violet-700)', marginBottom: 14 }}>True or False</div>
      <div style={{ fontSize: 22, fontWeight: 900, color:'var(--ink-900)', lineHeight: 1.25, marginBottom: 22 }}>
        {item.stem}
      </div>
      <div style={{ display:'flex', gap: 12 }}>
        {opt(true, 'True')}
        {opt(false, 'False')}
      </div>
    </div>
  );
}

// ─── Fill in blank ───
function FillCard({ item, value, revealed, correct, onChange }) {
  const filled = value || Array(item.blanks).fill(null);
  // Build slot/text segments from stem (split on '___')
  const parts = item.stem.split('___');

  const placeChip = (chip) => {
    if (revealed) return;
    const next = [...filled];
    const firstEmpty = next.findIndex(s => !s);
    if (firstEmpty === -1) return;
    next[firstEmpty] = chip;
    onChange(next);
  };

  const removeAt = (i) => {
    if (revealed) return;
    const next = [...filled];
    next[i] = null;
    onChange(next);
  };

  const usedCounts = filled.reduce((acc, c) => { if (c) acc[c] = (acc[c]||0)+1; return acc; }, {});
  const chipCounts = item.chips.reduce((acc, c) => { acc[c] = (acc[c]||0)+1; return acc; }, {});

  return (
    <div>
      <div className="pill" style={{ background: 'var(--violet-100)', color:'var(--violet-700)', marginBottom: 14 }}>Fill the Blanks</div>
      <div style={{ fontSize: 20, fontWeight: 800, color:'var(--ink-900)', lineHeight: 1.5, marginBottom: 24 }}>
        {parts.map((p, i) => (
          <React.Fragment key={i}>
            <span>{p}</span>
            {i < parts.length - 1 && (
              <span onClick={() => filled[i] && removeAt(i)}
                style={{
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  minWidth: 70, padding: '4px 12px', margin: '0 3px',
                  borderRadius: 10, verticalAlign: 'middle',
                  background: filled[i]
                    ? (revealed
                        ? (filled[i] === item.answer[i] ? 'var(--teal-500)' : 'var(--coral-500)')
                        : 'var(--violet-600)')
                    : 'transparent',
                  color: filled[i] ? 'white' : 'transparent',
                  border: filled[i] ? 'none' : '3px dashed var(--ink-200)',
                  fontWeight: 900, fontSize: 16,
                  cursor: filled[i] && !revealed ? 'pointer' : 'default',
                  animation: filled[i] ? 'pop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)' : 'none',
                  boxShadow: filled[i] && !revealed ? '0 2px 0 var(--violet-800)' : 'none',
                }}>
                {filled[i] || '·'}
              </span>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Choice chips */}
      <div style={{ display:'flex', flexWrap:'wrap', gap: 8, justifyContent:'center', padding: '12px 0' }}>
        {item.chips.map((chip, i) => {
          const used = (usedCounts[chip] || 0) >= (chipCounts[chip] || 0);
          return (
            <button key={i} onClick={() => placeChip(chip)} disabled={used || revealed}
              style={{
                padding: '10px 16px', borderRadius: 12,
                background: used ? 'var(--ink-100)' : 'white',
                color: used ? 'var(--ink-300)' : 'var(--ink-900)',
                border: `2px solid ${used ? 'var(--ink-100)' : 'var(--ink-200)'}`,
                boxShadow: used ? 'none' : '0 3px 0 var(--ink-200)',
                fontWeight: 800, fontSize: 15,
                cursor: used || revealed ? 'default' : 'pointer',
                transition: 'transform 0.08s, box-shadow 0.08s',
              }}>{chip}</button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Feedback banner ───
function FeedbackBanner({ correct, explanation }) {
  return (
    <div className="slide-up" style={{
      background: correct ? 'var(--teal-100)' : 'var(--coral-100)',
      borderTop: `3px solid ${correct ? 'var(--teal-500)' : 'var(--coral-500)'}`,
      padding: '16px 18px',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 6 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 9999,
          background: correct ? 'var(--teal-500)' : 'var(--coral-500)', color: 'white',
          display:'flex', alignItems:'center', justifyContent:'center',
          boxShadow: `0 2px 0 ${correct ? 'var(--teal-700)' : 'var(--coral-700)'}`,
        }}>
          {correct ? Icon.check('white', 18) : Icon.x('white', 18)}
        </div>
        <div style={{ fontSize: 17, fontWeight: 900,
                      color: correct ? 'var(--teal-700)' : 'var(--coral-700)' }}>
          {correct ? 'Nailed it!' : 'Not quite.'}
        </div>
      </div>
      <div style={{ fontSize: 14, fontWeight: 700,
                    color: correct ? 'var(--teal-700)' : 'var(--coral-700)',
                    lineHeight: 1.4, paddingLeft: 42 }}>
        {explanation}
      </div>
    </div>
  );
}

window.LessonScreen = LessonScreen;
