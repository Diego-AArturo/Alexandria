// Alexandria — Auth screen
function AuthScreen({ onAuth }) {
  const [mode, setMode] = React.useState('signin'); // signin | signup
  const [email, setEmail] = React.useState('');
  const [name, setName] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  const submit = () => {
    setError('');
    if (mode === 'signin') {
      if (!email || !password) { setError("Please fill in both fields to continue."); return; }
      if (password.length < 4) { setError("That password doesn't look right. Try again."); return; }
    } else {
      if (!email || !name || !password) { setError("All three fields are required."); return; }
      if (password.length < 6) { setError("Password needs at least 6 characters."); return; }
    }
    setLoading(true);
    setTimeout(() => { setLoading(false); onAuth({ email, name: name || email.split('@')[0] }); }, 700);
  };

  return (
    <div style={{
      minHeight: '100%', display: 'flex', flexDirection: 'column',
      padding: '70px 24px 32px', background: 'var(--bg)',
    }}>
      {/* Logo lockup */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, marginBottom: 28 }}>
        <Lex size={92} mood="wave" />
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 36, fontWeight: 900, color: 'var(--violet-700)', letterSpacing: -0.5 }}>
            Alexandria
          </div>
          <div style={{ fontSize: 15, color: 'var(--ink-500)', fontWeight: 700, marginTop: 4 }}>
            {mode === 'signin' ? 'Welcome back, scholar.' : 'Start your library today.'}
          </div>
        </div>
      </div>

      {/* Mode toggle */}
      <div style={{
        display: 'flex', background: 'var(--ink-100)', borderRadius: 14,
        padding: 4, marginBottom: 20,
      }}>
        {[['signin','Sign In'],['signup','Create Account']].map(([k,l]) => (
          <button key={k}
            onClick={() => { setMode(k); setError(''); }}
            style={{
              flex: 1, padding: '11px 0', borderRadius: 10,
              background: mode === k ? 'white' : 'transparent',
              boxShadow: mode === k ? '0 2px 6px rgba(91,43,227,0.12)' : 'none',
              color: mode === k ? 'var(--violet-700)' : 'var(--ink-500)',
              fontWeight: 800, fontSize: 14,
              transition: 'all 0.2s ease',
            }}>{l}</button>
        ))}
      </div>

      {/* Fields */}
      <div key={mode} className="slide-up" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 14 }}>
        <input className="field" placeholder={mode === 'signin' ? 'Email or username' : 'Email'}
               value={email} onChange={e => setEmail(e.target.value)} />
        {mode === 'signup' && (
          <input className="field" placeholder="Your name"
                 value={name} onChange={e => setName(e.target.value)} />
        )}
        <input className="field" type="password" placeholder="Password"
               value={password} onChange={e => setPassword(e.target.value)} />
      </div>

      {/* Inline error */}
      {error && (
        <div className="wiggle" style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '10px 14px', marginBottom: 10,
          background: 'var(--coral-100)', borderRadius: 12,
          color: 'var(--coral-700)', fontSize: 13, fontWeight: 800,
        }}>
          <div style={{
            width: 18, height: 18, borderRadius: 9999, background: 'var(--coral-500)',
            color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12, fontWeight: 900, flexShrink: 0,
          }}>!</div>
          {error}
        </div>
      )}

      {/* Primary CTA */}
      <button className="btn3d" disabled={loading} onClick={submit}>
        {loading ? <span className="spin" style={{ display:'inline-block', width:18, height:18, border:'2.5px solid rgba(255,255,255,0.4)', borderTopColor:'white', borderRadius:9999 }}/> : (mode === 'signin' ? 'Continue' : 'Create Account')}
      </button>

      {/* Divider */}
      <div style={{ display:'flex', alignItems:'center', gap:12, margin:'18px 0' }}>
        <div style={{ flex:1, height:2, background:'var(--ink-100)' }}/>
        <span style={{ fontSize:12, fontWeight:800, color:'var(--ink-300)', letterSpacing:1 }}>OR</span>
        <div style={{ flex:1, height:2, background:'var(--ink-100)' }}/>
      </div>

      <button className="btn3d ghost" onClick={() => onAuth({ email: 'you@gmail.com', name: 'Reader' })}
              style={{ display:'flex', alignItems:'center', gap:10 }}>
        {Icon.google(20)}
        <span>Continue with Google</span>
      </button>

      {/* Switch mode link */}
      <div style={{ textAlign:'center', marginTop: 'auto', paddingTop: 24 }}>
        <button onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(''); }}
                style={{ background:'none', color:'var(--ink-500)', fontWeight:700, fontSize:14, padding:8 }}>
          {mode === 'signin'
            ? <>New to Alexandria? <span style={{ color:'var(--violet-700)', fontWeight:900 }}>Create an account</span></>
            : <>Already have an account? <span style={{ color:'var(--violet-700)', fontWeight:900 }}>Sign in</span></>}
        </button>
      </div>
    </div>
  );
}

window.AuthScreen = AuthScreen;
