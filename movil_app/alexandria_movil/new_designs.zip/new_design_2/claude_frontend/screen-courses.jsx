// Alexandria — My Courses + Course Units screens
function CourseCard({ course, onTap, dim = false }) {
  return (
    <div className="card tappable" onClick={onTap}
      style={{
        opacity: dim ? 0.55 : 1,
        padding: 18, marginBottom: 12,
        animation: 'slideUp 0.35s ease both',
      }}>
      <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
        <div style={{
          width: 56, height: 56, borderRadius: 18,
          background: course.color, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 30, boxShadow: `inset 0 -4px 0 rgba(0,0,0,0.18)`,
        }}>{course.emoji}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 17, fontWeight: 900, color: 'var(--ink-900)', lineHeight: 1.2,
                        overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {course.title}
          </div>
          <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--ink-500)', marginTop: 4,
                        textTransform:'uppercase', letterSpacing: 0.6 }}>
            Unit {course.currentUnit} of {course.totalUnits} · {course.progressPct}%
          </div>
        </div>
        <div style={{ flexShrink: 0, color: 'var(--ink-300)' }}>
          {Icon.chevR('currentColor', 22)}
        </div>
      </div>
      <div className="progress" style={{ marginTop: 14 }}>
        <div className="fill" style={{ width: `${course.progressPct}%` }}/>
      </div>
    </div>
  );
}

function MyCoursesScreen({ courses, onOpenCourse, onCraftTab, showSnack }) {
  const empty = courses.length === 0;
  const [refreshing, setRefreshing] = React.useState(false);
  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1100);
  };

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)', padding: '70px 16px 110px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 6 }}>
        <div>
          <div style={{ fontSize: 32, fontWeight: 900, color: 'var(--ink-900)', letterSpacing: -0.5 }}>
            My Courses
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-500)' }}>
            {empty ? 'Your library is empty.' : `${courses.length} course${courses.length>1?'s':''} in your library`}
          </div>
        </div>
        <button onClick={refresh}
          style={{
            width: 44, height: 44, borderRadius: 14, background: 'white',
            border: '2px solid var(--ink-100)', boxShadow: '0 3px 0 var(--ink-100)',
            display:'flex', alignItems:'center', justifyContent:'center',
            color: 'var(--violet-600)',
          }}>
          <span className={refreshing ? 'spin' : ''} style={{ display:'inline-flex' }}>
            {Icon.refresh('currentColor', 20)}
          </span>
        </button>
      </div>

      {/* Streak banner */}
      {!empty && (
        <div className="card" style={{
          marginTop: 16, marginBottom: 16, padding: '14px 16px',
          background: 'linear-gradient(135deg, var(--violet-600), var(--violet-800))',
          border: 'none', boxShadow: '0 4px 0 var(--violet-900)',
          color: 'white',
          display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: 14,
            background: 'rgba(255,255,255,0.18)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span style={{ color: 'var(--gold-300)' }}>{Icon.fire('currentColor', 24)}</span>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 900 }}>4-day streak!</div>
            <div style={{ fontSize: 12, fontWeight: 700, opacity: 0.85 }}>Don't break the chain — pick up where you left off</div>
          </div>
        </div>
      )}

      {refreshing && <div className="ptr">Refreshing…</div>}

      {empty ? (
        <EmptyState onCraftTab={onCraftTab} showSnack={showSnack} />
      ) : (
        <div style={{ marginTop: 8 }}>
          {courses.map((c, i) => (
            <div key={c.id} style={{ animationDelay: `${i*60}ms` }}>
              <CourseCard course={c} onTap={() => onOpenCourse(c.id)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState({ onCraftTab, showSnack }) {
  const sample = {
    id: 'sample', title: 'Sample: How Bread Rises',
    emoji: '🥖', color: '#F5B53A',
    progressPct: 0, currentUnit: 1, totalUnits: 4,
  };
  const nudge = () => showSnack("Head to Craft Course to make your first one →");
  return (
    <div style={{ textAlign: 'center', marginTop: 28 }}>
      <div style={{ display:'flex', justifyContent:'center', marginBottom: 16 }}>
        <Lex size={92} mood="happy" />
      </div>
      <div style={{ fontSize: 22, fontWeight: 900, color: 'var(--ink-900)', marginBottom: 6 }}>
        Your library is empty
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-500)', maxWidth: 280, margin: '0 auto 22px' }}>
        Craft your very first course on anything you want to learn — bread, black holes, business law.
      </div>
      <div style={{ pointerEvents: 'auto' }} onClick={nudge}>
        <CourseCard course={sample} dim onTap={() => {}} />
      </div>
      <div style={{ marginTop: 12 }}>
        <button className="btn3d" onClick={onCraftTab}>
          <span style={{ display:'inline-flex', alignItems:'center', gap:8 }}>
            {Icon.craft('white', 20)}
            Craft a course
          </span>
        </button>
      </div>
    </div>
  );
}

// ─── Course Units screen ───
function CourseUnitsScreen({ course, onBack, onOpenLesson }) {
  const completed = course.units.filter(u => u.state === 'completed').length;
  return (
    <div style={{ minHeight:'100%', background:'var(--bg)', paddingBottom: 110 }}>
      {/* Header */}
      <div style={{
        background: course.color, color: 'white',
        padding: '70px 16px 24px',
        borderBottomLeftRadius: 28, borderBottomRightRadius: 28,
        position: 'relative',
      }}>
        <button onClick={onBack}
          style={{
            width: 40, height: 40, borderRadius: 12,
            background:'rgba(255,255,255,0.22)', backdropFilter:'blur(8px)',
            display:'flex', alignItems:'center', justifyContent:'center',
            color:'white', marginBottom: 14,
          }}>
          {Icon.chevL('white', 22)}
        </button>
        <div style={{ display:'flex', alignItems:'flex-start', gap: 14 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 18,
            background:'rgba(255,255,255,0.22)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize: 30, flexShrink: 0,
          }}>{course.emoji}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 24, fontWeight: 900, lineHeight: 1.15, letterSpacing: -0.4,
              display:'-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient:'vertical',
              overflow:'hidden',
            }}>{course.title}</div>
          </div>
        </div>
        {/* Progress pill */}
        <div style={{
          display:'inline-flex', alignItems:'center', gap: 10,
          background:'rgba(0,0,0,0.18)', borderRadius: 9999,
          padding: '8px 14px', marginTop: 14,
          fontSize: 13, fontWeight: 800,
        }}>
          <span style={{ color: 'var(--gold-300)' }}>{Icon.star('currentColor', 14)}</span>
          {completed} / {course.units.length} units · Unit {course.currentUnit} up next
        </div>
      </div>

      {/* Units list */}
      <div style={{ padding: '20px 16px 0', display:'flex', flexDirection:'column', gap: 12 }}>
        {course.units.map((u, i) => (
          <UnitCard key={u.id} unit={u} index={i+1}
            onTap={() => u.state !== 'locked' && onOpenLesson(course.id, u.id)} />
        ))}
      </div>
    </div>
  );
}

function UnitCard({ unit, index, onTap }) {
  const isLocked = unit.state === 'locked';
  const isCurrent = unit.state === 'current';
  const isDone = unit.state === 'completed';

  const bg = isDone ? 'white' : isCurrent ? 'white' : 'var(--bg-2)';
  const borderColor = isCurrent ? 'var(--violet-500)' : 'var(--ink-100)';
  const badgeBg = isDone ? 'var(--teal-500)' : isCurrent ? 'var(--violet-600)' : 'var(--ink-200)';
  const badgeShadow = isDone ? 'var(--teal-700)' : isCurrent ? 'var(--violet-800)' : 'var(--ink-300)';

  return (
    <div className={isLocked ? '' : 'tappable card'}
      onClick={isLocked ? undefined : onTap}
      style={{
        background: bg,
        borderRadius: 24,
        padding: 16,
        border: `2px solid ${borderColor}`,
        boxShadow: isCurrent ? '0 4px 0 var(--violet-200)' : '0 4px 0 var(--ink-100)',
        opacity: isLocked ? 0.65 : 1,
        cursor: isLocked ? 'not-allowed' : 'pointer',
        position: 'relative',
        animation: 'slideUp 0.3s ease both',
        transition: 'transform 0.08s, box-shadow 0.08s',
      }}>
      {isCurrent && (
        <div style={{
          position:'absolute', top: -10, right: 16,
          background:'var(--violet-600)', color:'white',
          padding: '4px 10px', borderRadius: 9999,
          fontSize: 11, fontWeight: 900, letterSpacing: 0.5,
          textTransform: 'uppercase',
          boxShadow: '0 2px 0 var(--violet-800)',
        }}>Up next</div>
      )}
      <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
        {/* Left badge */}
        <div style={{
          width: 52, height: 52, borderRadius: 16,
          background: badgeBg, color: 'white',
          boxShadow: `0 3px 0 ${badgeShadow}`,
          display:'flex', alignItems:'center', justifyContent:'center',
          flexShrink: 0,
          fontSize: isDone ? 0 : 18, fontWeight: 900,
        }}>
          {isDone ? Icon.check('white', 24)
            : isLocked ? Icon.lock('var(--ink-500)', 22)
            : index}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 15, fontWeight: 900,
            color: isLocked ? 'var(--ink-500)' : 'var(--ink-900)',
            lineHeight: 1.2,
          }}>{unit.title}</div>
          <div style={{
            fontSize: 12, fontWeight: 700,
            color: 'var(--ink-500)', marginTop: 4, lineHeight: 1.35,
          }}>{unit.desc}</div>
        </div>
        {/* Right status icon */}
        <div style={{ flexShrink: 0 }}>
          {isDone   && <span style={{ color:'var(--teal-500)' }}>{Icon.check('currentColor', 22)}</span>}
          {isCurrent && <span style={{ color:'var(--violet-600)' }}>{Icon.chevR('currentColor', 22)}</span>}
          {isLocked && <span style={{ color:'var(--ink-300)' }}>{Icon.lock('currentColor', 18)}</span>}
        </div>
      </div>
    </div>
  );
}

window.MyCoursesScreen = MyCoursesScreen;
window.CourseUnitsScreen = CourseUnitsScreen;
