// Alexandria — Main app shell + nav + state
const { useState, useEffect, useRef } = React;

function NavBar({ active, onChange }) {
  const tabs = [
    { id: 'courses', label: 'My Courses', icon: Icon.books },
    { id: 'craft',   label: 'Craft',      icon: Icon.craft },
    { id: 'profile', label: 'Profile',    icon: Icon.user  },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: 'white',
      borderTop: '2px solid var(--ink-100)',
      padding: '8px 12px 26px',
      display: 'flex', gap: 6,
      zIndex: 40,
    }}>
      {tabs.map(t => {
        const isActive = active === t.id;
        return (
          <button key={t.id} onClick={() => onChange(t.id)}
            style={{
              flex: 1, padding: '10px 6px',
              background: isActive ? 'var(--violet-50)' : 'transparent',
              borderRadius: 16,
              display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
              transition: 'all 0.18s ease',
              color: isActive ? 'var(--violet-700)' : 'var(--ink-500)',
            }}>
            <div style={{ transform: isActive ? 'scale(1.08)' : 'scale(1)', transition:'transform 0.2s' }}>
              {t.icon('currentColor', 26)}
            </div>
            <div style={{ fontSize: 11, fontWeight: 900, letterSpacing: 0.3 }}>{t.label}</div>
          </button>
        );
      })}
    </div>
  );
}

function ConfettiBurst() {
  const colors = ['#5B2BE3', '#14B8A6', '#F5B53A', '#FF7A8A', '#8B5BFF'];
  const pieces = Array.from({ length: 24 }, (_, i) => i);
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 99,
      overflow: 'hidden',
    }}>
      {pieces.map(i => (
        <div key={i} style={{
          position: 'absolute',
          left: `${10 + (i * 80) / pieces.length + (i % 3) * 4}%`,
          top: '40%',
          width: 8 + (i % 3) * 3, height: 12 + (i % 4) * 3,
          background: colors[i % colors.length],
          borderRadius: 2,
          animation: `confettiFall ${0.9 + (i%5)*0.18}s ease-out ${(i%6)*0.04}s both`,
        }}/>
      ))}
    </div>
  );
}

function CompletionScreen({ unitTitle, onContinue }) {
  return (
    <div style={{
      minHeight: '100%', background: 'linear-gradient(180deg, var(--violet-600), var(--violet-800))',
      color: 'white', display:'flex', flexDirection:'column',
      alignItems: 'center', justifyContent:'center', padding: '60px 24px 28px', textAlign: 'center',
    }}>
      <ConfettiBurst/>
      <div className="pop" style={{ marginBottom: 20 }}>
        <Lex size={140} mood="wave"/>
      </div>
      <div className="pop" style={{ fontSize: 36, fontWeight: 900, letterSpacing: -0.8, animationDelay: '0.1s' }}>
        Unit complete!
      </div>
      <div className="pop" style={{ fontSize: 16, fontWeight: 700, opacity: 0.85, marginTop: 8, animationDelay: '0.15s' }}>
        {unitTitle}
      </div>

      <div className="pop" style={{
        marginTop: 28, padding: '16px 22px', borderRadius: 22,
        background: 'rgba(255,255,255,0.15)', backdropFilter:'blur(10px)',
        display: 'flex', gap: 28,
        animationDelay: '0.25s',
      }}>
        <div style={{ textAlign:'center' }}>
          <div style={{ fontSize: 32, fontWeight: 900, color: 'var(--gold-300)', lineHeight: 1 }}>+50</div>
          <div style={{ fontSize: 11, fontWeight: 800, opacity: 0.85, marginTop: 4, textTransform:'uppercase', letterSpacing: 0.6 }}>XP</div>
        </div>
        <div style={{ width: 2, background: 'rgba(255,255,255,0.2)' }}/>
        <div style={{ textAlign:'center' }}>
          <div style={{ fontSize: 32, fontWeight: 900, color: 'var(--gold-300)', lineHeight: 1 }}>5🔥</div>
          <div style={{ fontSize: 11, fontWeight: 800, opacity: 0.85, marginTop: 4, textTransform:'uppercase', letterSpacing: 0.6 }}>Day Streak</div>
        </div>
      </div>

      <div className="pop" style={{ width: '100%', maxWidth: 320, marginTop: 32, animationDelay: '0.4s' }}>
        <button className="btn3d teal" onClick={onContinue} style={{ width: '100%' }}>
          Keep going
        </button>
      </div>
    </div>
  );
}

function App() {
  const [authed, setAuthed]   = useState(false);
  const [user, setUser]       = useState({ name: 'Reader', email: 'you@gmail.com', language: 'English' });
  const [tab, setTab]         = useState('courses');
  const [courses, setCourses] = useState(SEED_COURSES);
  const [route, setRoute]     = useState({ name: 'tabs' }); // tabs | units(courseId) | lesson(courseId, unitId) | done(unitTitle)
  const [snack, setSnack]     = useState(null);

  const showSnack = (msg) => {
    setSnack(msg);
    clearTimeout(showSnack._t);
    showSnack._t = setTimeout(() => setSnack(null), 2400);
  };

  // Auto-dismiss completion
  useEffect(() => {
    if (route.name === 'done') {
      const t = setTimeout(() => setRoute({ name: 'tabs' }), 5000);
      return () => clearTimeout(t);
    }
  }, [route]);

  const openCourse = (id) => setRoute({ name: 'units', courseId: id });
  const openLesson = (cid, uid) => setRoute({ name: 'lesson', courseId: cid, unitId: uid });
  const onLessonComplete = (cid, uid) => {
    // Mark unit completed; advance current; bump progress
    setCourses(cs => cs.map(c => {
      if (c.id !== cid) return c;
      const units = c.units.map((u, i, arr) => {
        if (u.id === uid) return { ...u, state: 'completed' };
        return u;
      });
      // Unlock next locked → current
      const firstLocked = units.findIndex(u => u.state === 'locked');
      if (firstLocked !== -1) units[firstLocked] = { ...units[firstLocked], state: 'current' };
      const completed = units.filter(u => u.state === 'completed').length;
      return {
        ...c, units,
        currentUnit: Math.min(completed + 1, c.totalUnits),
        progressPct: Math.round((completed / c.totalUnits) * 100),
      };
    }));
    const course = courses.find(c => c.id === cid);
    const unit = course?.units.find(u => u.id === uid);
    setRoute({ name: 'done', unitTitle: unit?.title || 'Unit', courseId: cid });
  };

  const handleCreated = ({ title, prompt }) => {
    const newCourse = {
      id: 'c' + Date.now(),
      title,
      emoji: '📚',
      color: '#8B5BFF',
      progressPct: 0,
      currentUnit: 1,
      totalUnits: 5,
      units: [
        { id: 'u1', title: 'Foundations', desc: 'The essential building blocks', state: 'current' },
        { id: 'u2', title: 'Core Concepts', desc: 'Going deeper into the fundamentals', state: 'locked' },
        { id: 'u3', title: 'Practical Applications', desc: 'Putting theory into practice', state: 'locked' },
        { id: 'u4', title: 'Advanced Patterns', desc: 'Where things get interesting', state: 'locked' },
        { id: 'u5', title: 'Mastery', desc: 'Pulling it all together', state: 'locked' },
      ],
    };
    setCourses(cs => [newCourse, ...cs]);
    showSnack('🎉 Course ready! Find it in My Courses.');
    setTab('courses');
  };

  // ─── Render ───
  if (!authed) {
    return <AuthScreen onAuth={(u) => { setUser({ ...user, ...u }); setAuthed(true); }} />;
  }

  // Lesson takes over (no nav bar)
  if (route.name === 'lesson') {
    const course = courses.find(c => c.id === route.courseId);
    const unit = course.units.find(u => u.id === route.unitId);
    return (
      <LessonScreen course={course} unit={unit}
        onExit={() => setRoute({ name: 'units', courseId: course.id })}
        onComplete={onLessonComplete}/>
    );
  }
  if (route.name === 'done') {
    return <CompletionScreen unitTitle={route.unitTitle}
              onContinue={() => setRoute({ name: 'units', courseId: route.courseId })}/>;
  }
  if (route.name === 'units') {
    const course = courses.find(c => c.id === route.courseId);
    return (
      <>
        <div data-screen-label="Units" style={{ minHeight:'100%' }}>
          <CourseUnitsScreen course={course}
            onBack={() => setRoute({ name: 'tabs' })}
            onOpenLesson={openLesson}/>
        </div>
        <NavBar active={tab} onChange={(t) => { setTab(t); setRoute({ name: 'tabs' }); }}/>
        {snack && <div className="snackbar">{snack}</div>}
      </>
    );
  }

  // Tab content
  return (
    <>
      <div data-screen-label={tab}>
        {tab === 'courses' && (
          <MyCoursesScreen courses={courses}
            onOpenCourse={openCourse}
            onCraftTab={() => setTab('craft')}
            showSnack={showSnack}/>
        )}
        {tab === 'craft' && (
          <CraftScreen courses={courses} onCreated={handleCreated} showSnack={showSnack}/>
        )}
        {tab === 'profile' && (
          <ProfileScreen user={user} courses={courses} onUpdateUser={setUser}/>
        )}
      </div>
      <NavBar active={tab} onChange={setTab}/>
      {snack && <div className="snackbar">{snack}</div>}
    </>
  );
}

// ─── Mount: device frame wrapping app ───
function Root() {
  // Scale device frame to viewport
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const W = 402, H = 874;
      const s = Math.min(window.innerWidth / (W + 60), window.innerHeight / (H + 60), 1);
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  return (
    <div style={{
      width: '100vw', height: '100vh',
      display: 'flex', alignItems:'center', justifyContent:'center',
      background: 'radial-gradient(ellipse at top, #2A0F7A, #0F0524)',
      overflow: 'hidden',
    }}>
      <div style={{ transform: `scale(${scale})`, transformOrigin: 'center' }}>
        <IOSDevice width={402} height={874}>
          <div style={{ position:'relative', height: '100%', overflow: 'hidden' }}>
            <App/>
          </div>
        </IOSDevice>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>);
