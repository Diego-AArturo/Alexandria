// Alexandria — original iconography. Bold, rounded strokes.
const Icon = {
  // Tab bar
  books: (c = 'currentColor', size = 28) => (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none">
      <path d="M5 6.5C5 5.4 5.9 4.5 7 4.5h4.5c1.1 0 2 0.9 2 2v15c0-1.1-0.9-2-2-2H7c-1.1 0-2 0.9-2 2v-15Z"
            stroke={c} strokeWidth="2.4" strokeLinejoin="round"/>
      <path d="M14.5 8.5c0-1.1 0.9-2 2-2H21c1.1 0 2 0.9 2 2v13c0-1.1-0.9-2-2-2h-4.5c-1.1 0-2 0.9-2 2v-13Z"
            stroke={c} strokeWidth="2.4" strokeLinejoin="round"/>
    </svg>
  ),
  craft: (c = 'currentColor', size = 28) => (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none">
      <path d="M14 4l2.4 5.5L22 11l-5.6 2.5L14 19l-2.4-5.5L6 11l5.6-1.5L14 4Z"
            stroke={c} strokeWidth="2.4" strokeLinejoin="round" fill="none"/>
      <circle cx="22" cy="20" r="1.6" fill={c}/>
      <circle cx="6.5" cy="22" r="1.2" fill={c}/>
    </svg>
  ),
  user: (c = 'currentColor', size = 28) => (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none">
      <circle cx="14" cy="10" r="4.5" stroke={c} strokeWidth="2.4"/>
      <path d="M5 23.5c0-4.5 4-7.5 9-7.5s9 3 9 7.5" stroke={c} strokeWidth="2.4" strokeLinecap="round"/>
    </svg>
  ),

  chevR: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M6 4l5 5-5 5" stroke={c} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  chevL: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M12 4L7 9l5 5" stroke={c} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  check: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M3.5 9l4 4 7-8" stroke={c} strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  x: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M4 4l10 10M14 4L4 14" stroke={c} strokeWidth="2.8" strokeLinecap="round"/>
    </svg>
  ),
  lock: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <rect x="3.5" y="8" width="11" height="7.5" rx="2" stroke={c} strokeWidth="2.2"/>
      <path d="M6 8V5.5a3 3 0 016 0V8" stroke={c} strokeWidth="2.2" strokeLinecap="round"/>
    </svg>
  ),
  star: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M9 1.5l2.3 4.7 5.2 0.7-3.8 3.6 0.9 5.2L9 13.3 4.4 15.7l0.9-5.2L1.5 6.9l5.2-0.7L9 1.5Z"
            fill={c} stroke={c} strokeWidth="1.5" strokeLinejoin="round"/>
    </svg>
  ),
  fire: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M9 1.5c1 2 2.5 3 2.5 5 1 0.5 2 2 2 4a4.5 4.5 0 11-9 0c0-1.5 0.7-2.7 1.5-3.5 0 1.5 1 2 1.5 1 0-2 0.5-4 1.5-6.5Z"
            fill={c}/>
    </svg>
  ),
  edit: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M3 13.5L3 15h1.5L13 6.5l-1.5-1.5L3 13.5Z" stroke={c} strokeWidth="2" strokeLinejoin="round"/>
      <path d="M11.5 5L13 6.5l1.5-1.5L13 3.5 11.5 5Z" stroke={c} strokeWidth="2" strokeLinejoin="round"/>
    </svg>
  ),
  google: (size = 20) => (
    <svg width={size} height={size} viewBox="0 0 20 20">
      <path d="M19.6 10.2c0-.7-.1-1.4-.2-2H10v3.8h5.4c-.2 1.3-.9 2.4-2 3.1v2.6h3.2c1.9-1.7 3-4.3 3-7.5z" fill="#4285F4"/>
      <path d="M10 20c2.7 0 5-.9 6.6-2.4l-3.2-2.6c-.9.6-2 1-3.4 1-2.6 0-4.8-1.7-5.6-4.1H1.1v2.6C2.7 17.7 6.1 20 10 20z" fill="#34A853"/>
      <path d="M4.4 11.9c-.2-.6-.3-1.2-.3-1.9s.1-1.3.3-1.9V5.5H1.1C.4 6.9 0 8.4 0 10s.4 3.1 1.1 4.5l3.3-2.6z" fill="#FBBC04"/>
      <path d="M10 4c1.5 0 2.8.5 3.8 1.5L16.7 2.7C15 1 12.7 0 10 0 6.1 0 2.7 2.3 1.1 5.5l3.3 2.6C5.2 5.7 7.4 4 10 4z" fill="#EA4335"/>
    </svg>
  ),

  refresh: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M14.5 9a5.5 5.5 0 11-1.6-3.9" stroke={c} strokeWidth="2.4" strokeLinecap="round"/>
      <path d="M14.5 3v3h-3" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  bell: (c = 'currentColor', size = 18) => (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none">
      <path d="M3.5 13.5h11l-1.5-2V8a4 4 0 00-8 0v3.5l-1.5 2Z" stroke={c} strokeWidth="2" strokeLinejoin="round"/>
      <path d="M7.5 15.5a1.5 1.5 0 003 0" stroke={c} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
};

// ─── Mascot: "Lex" — A-shaped book character. Original geometric design. ───
function Lex({ size = 80, mood = 'happy' }) {
  // mood: happy | wave | sad | wink
  const eyeShape = mood === 'sad'
    ? <><circle cx="32" cy="48" r="3" fill="#1A1235"/><circle cx="56" cy="48" r="3" fill="#1A1235"/></>
    : mood === 'wink'
    ? <><circle cx="32" cy="48" r="3.5" fill="#1A1235"/><path d="M52 48h8" stroke="#1A1235" strokeWidth="3" strokeLinecap="round"/></>
    : <><circle cx="32" cy="48" r="3.5" fill="#1A1235"/><circle cx="56" cy="48" r="3.5" fill="#1A1235"/></>;
  const mouth = mood === 'sad'
    ? <path d="M38 62 Q44 58 50 62" stroke="#1A1235" strokeWidth="3" fill="none" strokeLinecap="round"/>
    : <path d="M38 58 Q44 65 50 58" stroke="#1A1235" strokeWidth="3" fill="none" strokeLinecap="round"/>;
  return (
    <svg width={size} height={size} viewBox="0 0 88 88">
      {/* Body — rounded A shape (book) */}
      <path d="M44 8 L74 76 L14 76 Z"
            fill="#5B2BE3" stroke="#3F1AAD" strokeWidth="3" strokeLinejoin="round"/>
      {/* Inner page highlight — crossbar of A */}
      <rect x="26" y="54" width="36" height="6" rx="3" fill="#FAF7FF"/>
      {/* Cheeks */}
      <circle cx="22" cy="56" r="4" fill="#FF7A8A" opacity="0.75"/>
      <circle cx="66" cy="56" r="4" fill="#FF7A8A" opacity="0.75"/>
      {/* Face */}
      {eyeShape}
      {mouth}
      {/* Sparkle */}
      <path d="M76 18 L78 22 L82 24 L78 26 L76 30 L74 26 L70 24 L74 22 Z" fill="#14B8A6"/>
    </svg>
  );
}

window.Icon = Icon;
window.Lex = Lex;
