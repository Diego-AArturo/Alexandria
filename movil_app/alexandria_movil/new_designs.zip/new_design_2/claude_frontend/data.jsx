// Alexandria — sample data
const SEED_COURSES = [
  {
    id: 'c1',
    title: 'Spanish for Travelers',
    emoji: '🌮',
    color: '#FF7A8A',
    progressPct: 60,
    currentUnit: 3,
    totalUnits: 5,
    units: [
      { id: 'u1', title: 'Greetings & Goodbyes', desc: 'Hola, adiós, and the basics of polite conversation', state: 'completed' },
      { id: 'u2', title: 'Ordering Food', desc: 'Restaurants, menus, and asking for the bill', state: 'completed' },
      { id: 'u3', title: 'Getting Around', desc: 'Directions, transportation, and street smarts', state: 'current' },
      { id: 'u4', title: 'At the Hotel', desc: 'Check-in, room service, and travel hiccups', state: 'locked' },
      { id: 'u5', title: 'Emergencies', desc: 'Medical, police, and asking for help fast', state: 'locked' },
    ],
  },
  {
    id: 'c2',
    title: 'Intro to Astrophysics',
    emoji: '🌌',
    color: '#5B2BE3',
    progressPct: 25,
    currentUnit: 2,
    totalUnits: 8,
    units: [
      { id: 'u1', title: 'The Cosmic Scale', desc: 'Light-years, parsecs, and the size of everything', state: 'completed' },
      { id: 'u2', title: 'Stellar Lifecycles', desc: 'How stars are born, live, and die', state: 'current' },
      { id: 'u3', title: 'Black Holes', desc: 'Event horizons and gravitational singularities', state: 'locked' },
      { id: 'u4', title: 'Galaxies', desc: 'Spirals, ellipticals, and the Milky Way', state: 'locked' },
    ],
  },
  {
    id: 'c3',
    title: 'Sourdough Mastery',
    emoji: '🍞',
    color: '#F5B53A',
    progressPct: 100,
    currentUnit: 4,
    totalUnits: 4,
    units: [
      { id: 'u1', title: 'Building a Starter', desc: 'Flour, water, and patience', state: 'completed' },
      { id: 'u2', title: 'Autolyse & Mixing', desc: 'Hydration ratios and gluten development', state: 'completed' },
      { id: 'u3', title: 'Shape & Score', desc: 'Tension, ears, and beautiful crust', state: 'completed' },
      { id: 'u4', title: 'Bake & Cool', desc: 'Steam, temperature, and the perfect crumb', state: 'completed' },
    ],
  },
];

// Lesson items for demo (Stellar Lifecycles)
const SEED_LESSON = [
  {
    type: 'concept',
    title: 'What is a star, really?',
    body: 'A star is a luminous sphere of plasma held together by its own gravity. The pressure of gravity pulling inward is balanced by the energy of nuclear fusion pushing outward.',
    bullets: [
      'Most of a star is hydrogen and helium',
      'Fusion in the core produces light and heat',
      'When fuel runs out, the balance breaks'
    ],
  },
  {
    type: 'concept',
    title: 'The Main Sequence',
    body: 'Most stars spend the bulk of their lives on the "main sequence" — a long, stable phase where they fuse hydrogen into helium. Our Sun has been here for ~4.6 billion years.',
  },
  {
    type: 'concept',
    title: 'After the Main Sequence',
    body: 'Once the hydrogen runs low, a star swells into a red giant. What happens next depends almost entirely on one thing: mass.',
  },
  {
    type: 'mc',
    stem: 'What force pushes outward inside a star, balancing gravity?',
    options: [
      'Magnetic fields',
      'Nuclear fusion energy',
      'Stellar wind',
      'Centrifugal rotation',
    ],
    answer: 1,
    explanation: 'Fusion in the core releases enormous energy that pushes outward, exactly balancing gravity\'s inward pull.',
  },
  {
    type: 'tf',
    stem: 'A star\'s final fate is determined mainly by its temperature.',
    answer: false,
    explanation: 'It\'s mass, not temperature. Low-mass stars become white dwarfs; massive stars go supernova.',
  },
  {
    type: 'fill',
    stem: 'Most stars spend their lives on the ___ ___, fusing ___ into ___.',
    blanks: 4,
    chips: ['main', 'sequence', 'hydrogen', 'helium', 'gravity', 'plasma'],
    answer: ['main', 'sequence', 'hydrogen', 'helium'],
    explanation: 'The main sequence is the long, stable hydrogen-fusing phase that defines most of a star\'s life.',
  },
  {
    type: 'mc',
    stem: 'What does a low-mass star like our Sun become at the end of its life?',
    options: [
      'A black hole',
      'A neutron star',
      'A white dwarf',
      'A quasar',
    ],
    answer: 2,
    explanation: 'Stars like the Sun shed their outer layers and leave behind a dense, slowly cooling white dwarf core.',
  },
];

window.SEED_COURSES = SEED_COURSES;
window.SEED_LESSON = SEED_LESSON;
