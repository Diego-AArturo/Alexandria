// Alexandria — Craft Course + Profile screens
function CraftScreen({ courses, onCreated, showSnack }) {
  const [prompt, setPrompt] = React.useState('');
  const [job, setJob] = React.useState(null); // null | { stage, message }
  const stages = ['queued', 'generating', 'ready'];
  const stageMsgs = {
    queued: 'Queued…',
    generating: 'Generating course…',
    ready: 'Course ready!',
  };

  const submit = () => {
    if (!prompt.trim()) { showSnack("Tell us what you'd like to learn first."); return; }
    if (courses.length >= 3) { showSnack("Beta limit reached: 3 courses max."); return; }
    setJob({ stage: 'queued' });
    setTimeout(() => setJob({ stage: 'generating' }), 1200);
    setTimeout(() => setJob({ stage: 'ready' }), 3400);
    setTimeout(() => {
      onCreated({
        title: prompt.split('\n')[0].slice(0, 40) || 'New Course',
        prompt,
      });
      setJob(null);
      setPrompt('');
    }, 4400);
  };

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)', padding: '70px 16px 110px' }}>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 32, fontWeight: 900, color:'var(--ink-900)', letterSpacing: -0.5 }}>
          Craft a Course
        </div>
        <div style={{ fontSize: 14, fontWeight: 700, color:'var(--ink-500)', marginTop: 4 }}>
          Type any topic. Lex builds you a custom course in under a minute.
        </div>
      </div>

      {/* Mascot prompt */}
      <div className="card" style={{
        display:'flex', alignItems:'center', gap: 14,
        padding: 16, marginBottom: 16,
        background: 'var(--violet-50)', border: '2px solid var(--violet-100)',
        boxShadow: '0 4px 0 var(--violet-100)',
      }}>
        <Lex size={56} mood="wave"/>
        <div style={{ flex: 1, fontSize: 14, fontWeight: 800, color: 'var(--violet-800)', lineHeight: 1.35 }}>
          What do you want to learn today? Be specific — I love it.
        </div>
      </div>

      {/* Input */}
      <textarea
        value={prompt}
        onChange={e => setPrompt(e.target.value)}
        disabled={!!job}
        placeholder="e.g. The basics of perfume making — top notes, base notes, blending ratios, classic accords. I have no chemistry background."
        className="field"
        style={{
          minHeight: 140, resize: 'none',
          fontSize: 15, fontWeight: 700, lineHeight: 1.45,
          color: 'var(--ink-900)',
        }}/>

      {/* CTA */}
      <div style={{ marginTop: 14 }}>
        <button className="btn3d" disabled={!!job} onClick={submit}>
          {job ? (
            <span style={{ display:'inline-flex', alignItems:'center', gap: 10 }}>
              <span className="spin" style={{ display:'inline-block', width:18, height:18, border:'2.5px solid rgba(255,255,255,0.4)', borderTopColor:'white', borderRadius:9999 }}/>
              Building…
            </span>
          ) : (
            <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}>
              {Icon.craft('white', 20)}
              Create my course
            </span>
          )}
        </button>
      </div>

      {/* Job progress banner */}
      {job && (
        <div className="card slide-up" style={{
          marginTop: 14, padding: '14px 16px',
          background: 'white', border: '2px solid var(--violet-200)',
          boxShadow: '0 4px 0 var(--violet-100)',
        }}>
          <div style={{ display:'flex', alignItems:'center', gap: 12 }}>
            <div className="spin" style={{
              width: 28, height: 28, borderRadius: 9999,
              border: '3px solid var(--violet-100)',
              borderTopColor: 'var(--violet-600)',
            }}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 900, color: 'var(--violet-800)' }}>
                {stageMsgs[job.stage]}
              </div>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-500)', marginTop: 2 }}>
                We'll notify you when it's done — feel free to leave this screen.
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap: 6, marginTop: 12 }}>
            {stages.map((s, i) => (
              <div key={s} style={{
                flex: 1, height: 6, borderRadius: 9999,
                background: stages.indexOf(job.stage) >= i ? 'var(--violet-500)' : 'var(--ink-100)',
                transition: 'background 0.4s ease',
              }}/>
            ))}
          </div>
        </div>
      )}

      {/* Tips card */}
      <div className="card" style={{ marginTop: 18, background:'var(--bg-2)' }}>
        <div style={{ display:'flex', alignItems:'center', gap: 8, marginBottom: 12 }}>
          <span style={{ color: 'var(--gold-500)' }}>{Icon.star('currentColor', 18)}</span>
          <div style={{ fontSize: 13, fontWeight: 900, color: 'var(--ink-900)',
                        textTransform: 'uppercase', letterSpacing: 0.6 }}>
            Tips for great courses
          </div>
        </div>
        <ul style={{ margin: 0, paddingLeft: 0, listStyle:'none', display:'flex', flexDirection:'column', gap: 10 }}>
          {[
            'Be specific. "Roman empire 27 BC – 180 AD" beats "Roman history".',
            'Tell us your level — beginner, intermediate, or advanced.',
            'Include 1–2 things you most want to come away knowing.',
          ].map((t, i) => (
            <li key={i} style={{ display:'flex', gap: 10, fontSize: 13, color:'var(--ink-700)', fontWeight: 700, lineHeight: 1.4 }}>
              <div style={{
                width: 20, height: 20, borderRadius: 9999, flexShrink: 0,
                background: 'var(--violet-100)', color: 'var(--violet-700)',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize: 11, fontWeight: 900, marginTop: 1,
              }}>{i+1}</div>
              <span>{t}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// ─── Profile ───
function ProfileScreen({ user, courses, onUpdateUser }) {
  const [editing, setEditing] = React.useState(false);
  const [draft, setDraft] = React.useState({ ...user });
  const [saving, setSaving] = React.useState(false);
  const [langChanged, setLangChanged] = React.useState(false);

  const completed = courses.filter(c => c.progressPct === 100).length;
  const inProgress = courses.filter(c => c.progressPct > 0 && c.progressPct < 100).length;

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      const changed = draft.language !== user.language;
      onUpdateUser(draft);
      setEditing(false);
      setSaving(false);
      if (changed) setLangChanged(true);
    }, 700);
  };

  return (
    <div style={{ minHeight: '100%', background:'var(--bg)', padding: '70px 16px 110px' }}>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 32, fontWeight: 900, color:'var(--ink-900)', letterSpacing: -0.5 }}>
          My Profile
        </div>
      </div>

      {/* Card 1: Identity */}
      <div className="card" style={{ marginBottom: 14, padding: 18 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 9999,
            background: 'linear-gradient(135deg, var(--violet-400), var(--violet-700))',
            color: 'white', display:'flex', alignItems:'center', justifyContent:'center',
            fontSize: 26, fontWeight: 900,
            boxShadow: '0 3px 0 var(--violet-800)',
          }}>{user.name?.[0]?.toUpperCase() || 'A'}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 18, fontWeight: 900, color:'var(--ink-900)' }}>{user.name}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color:'var(--ink-500)',
                          overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {user.email}
            </div>
            <div style={{
              display:'inline-flex', alignItems:'center', gap: 6, marginTop: 6,
              padding: '3px 10px', borderRadius: 9999,
              background: 'var(--teal-100)', color:'var(--teal-700)',
              fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: 0.5,
            }}>
              🌍 {user.language}
            </div>
          </div>
          {!editing && (
            <button onClick={() => { setDraft({ ...user }); setEditing(true); }}
              style={{
                width: 40, height: 40, borderRadius: 12,
                background: 'var(--violet-50)', color: 'var(--violet-700)',
                border:'2px solid var(--violet-100)', boxShadow: '0 3px 0 var(--violet-100)',
                display:'flex', alignItems:'center', justifyContent:'center',
              }}>
              {Icon.edit('currentColor', 18)}
            </button>
          )}
        </div>

        {editing && (
          <div className="slide-up" style={{ marginTop: 16, display:'flex', flexDirection:'column', gap: 10 }}>
            <input className="field" placeholder="Username"
                   value={draft.name} onChange={e => setDraft(d => ({...d, name: e.target.value}))}/>
            <input className="field" type="password" placeholder="New password (optional)"
                   value={draft.password || ''} onChange={e => setDraft(d => ({...d, password: e.target.value}))}/>
            <div>
              <div style={{ fontSize: 11, fontWeight: 900, color:'var(--ink-500)',
                            textTransform:'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>
                Language
              </div>
              <div style={{ display:'flex', gap: 6, flexWrap:'wrap' }}>
                {['English','Español','Français','Deutsch','日本語'].map(l => (
                  <button key={l} onClick={() => setDraft(d => ({...d, language: l}))}
                    style={{
                      padding:'8px 14px', borderRadius: 9999,
                      background: draft.language === l ? 'var(--violet-600)' : 'white',
                      color: draft.language === l ? 'white' : 'var(--ink-700)',
                      border: `2px solid ${draft.language === l ? 'var(--violet-600)' : 'var(--ink-200)'}`,
                      boxShadow: draft.language === l ? '0 2px 0 var(--violet-800)' : '0 2px 0 var(--ink-100)',
                      fontWeight: 800, fontSize: 13,
                    }}>{l}</button>
                ))}
              </div>
            </div>
            {langChanged && (
              <div style={{
                background: 'var(--gold-300)', color: '#5C3F00',
                padding: '10px 14px', borderRadius: 12, fontSize: 13, fontWeight: 800,
              }}>
                Language updated. Restart Alexandria for it to fully apply.
              </div>
            )}
            <div style={{ display:'flex', gap: 8, marginTop: 4 }}>
              <button className="btn3d ghost" onClick={() => setEditing(false)} disabled={saving}>Cancel</button>
              <button className="btn3d" onClick={save} disabled={saving}>
                {saving ? <span className="spin" style={{ display:'inline-block', width:16, height:16, border:'2.5px solid rgba(255,255,255,0.4)', borderTopColor:'white', borderRadius:9999 }}/> : 'Save'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Card 2: Course Stats */}
      <div className="card" style={{ marginBottom: 14, padding: 0, overflow:'hidden' }}>
        <div style={{ display:'flex' }}>
          <div style={{ flex: 1, padding: '20px 18px', textAlign: 'center', borderRight: '2px solid var(--ink-100)' }}>
            <div style={{ fontSize: 11, fontWeight: 900, color:'var(--ink-500)',
                          textTransform:'uppercase', letterSpacing: 0.6, marginBottom: 6 }}>
              Total
            </div>
            <div style={{ fontSize: 34, fontWeight: 900, color:'var(--violet-700)', lineHeight: 1, letterSpacing: -1 }}>
              {courses.length}
            </div>
            <div style={{ fontSize: 12, fontWeight: 800, color:'var(--ink-500)', marginTop: 4 }}>
              courses
            </div>
          </div>
          <div style={{ flex: 1, padding: '20px 18px', textAlign: 'center' }}>
            <div style={{ fontSize: 11, fontWeight: 900, color:'var(--ink-500)',
                          textTransform:'uppercase', letterSpacing: 0.6, marginBottom: 6 }}>
              Completed
            </div>
            <div style={{ fontSize: 34, fontWeight: 900, color:'var(--teal-600)', lineHeight: 1, letterSpacing: -1 }}>
              {completed}
            </div>
            <div style={{ fontSize: 12, fontWeight: 800, color:'var(--ink-500)', marginTop: 4 }}>
              {completed === 1 ? 'masterpiece' : 'masterpieces'}
            </div>
          </div>
        </div>
      </div>

      {/* Card 3: In progress */}
      <div className="card" style={{
        marginBottom: 14, padding: 20, textAlign: 'center',
        background: 'linear-gradient(135deg, var(--gold-300), var(--gold-500))',
        border: 'none', boxShadow: '0 4px 0 #C8841F',
        color: '#5C3F00',
      }}>
        <div style={{ fontSize: 11, fontWeight: 900,
                      textTransform:'uppercase', letterSpacing: 0.6 }}>
          In progress
        </div>
        <div style={{ fontSize: 56, fontWeight: 900, lineHeight: 1, letterSpacing: -2, marginTop: 4 }}>
          {inProgress}
        </div>
        <div style={{ fontSize: 13, fontWeight: 800, marginTop: 6, opacity: 0.85 }}>
          {inProgress === 0 ? 'Time to start something new!' : `course${inProgress>1?'s':''} keeping you busy`}
        </div>
      </div>

      {/* Card 4: Account info */}
      <div className="card" style={{ padding: 18 }}>
        <div style={{ fontSize: 11, fontWeight: 900, color:'var(--ink-500)',
                      textTransform:'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>
          Account
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color:'var(--ink-500)' }}>Email</div>
          <div style={{ fontSize: 14, fontWeight: 800, color:'var(--ink-900)' }}>{user.email}</div>
        </div>
      </div>
    </div>
  );
}

window.CraftScreen = CraftScreen;
window.ProfileScreen = ProfileScreen;
